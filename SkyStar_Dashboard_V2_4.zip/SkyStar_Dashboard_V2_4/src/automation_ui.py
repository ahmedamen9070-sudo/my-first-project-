"""Local setup and processing controls; no credentials are stored in this UI."""
import json
from pathlib import Path
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk,messagebox
from datetime import date,datetime,timezone


def render(app,business_day,*_):
    from automation_worker import init_config,load_config,run_once
    from automation_services import whatsapp_config_status
    from gmail_service import gmail_config_status
    config_path=app.store.path.parent/'automation'/'config.json'
    app.heading(app.content,'Automation workspace',
                'Export Comsys reports into a daily folder, confirm readiness once, then process the whole day.')
    status=app.panel(app.content,pad=14)
    app.label(status,'COMSYS EXPORT  >  DAILY FOLDER  >  CHECKS & REPORT  >  DELIVERY QUEUE',10,True).pack(anchor='w')
    app.label(status,'Comsys export is still manual. AI, Gmail and WhatsApp require their own connection setup.',9,
              color='#758298',wraplength=850,justify='left').pack(anchor='w',pady=(7,0))
    controls=app.panel(app.content,pad=14)
    toolbar=tk.Frame(controls,bg='white');toolbar.pack(fill='x')
    app.button(toolbar,'Create local setup',lambda:initialize(),True).pack(side='left',padx=(0,8))
    app.button(toolbar,'Open day folder',lambda:open_day()).pack(side='left',padx=(0,8))
    app.button(toolbar,'Open output folder',lambda:open_output()).pack(side='left',padx=(0,8))
    app.button(toolbar,'Gmail settings',lambda:open_gmail_settings()).pack(side='left',padx=(0,8))
    app.button(toolbar,'Setup guide',lambda:open_guide()).pack(side='left')
    location=app.label(controls,'Setup file: '+str(config_path),8,color='#758298',wraplength=900,justify='left')
    location.pack(anchor='w',pady=(10,7))
    policy_labels={'review':'Manual review','auto_when_clean':'Automatic if clean'}
    policy_values={value:key for key,value in policy_labels.items()}
    policy=tk.StringVar(value='Manual review')
    row=tk.Frame(controls,bg='white');row.pack(fill='x',pady=5)
    app.label(row,'Approval policy:',9,True,bg='white').pack(side='left',padx=(0,10))
    ttk.Combobox(row,textvariable=policy,values=('Manual review','Automatic if clean'),state='readonly',width=22).pack(side='left')
    app.button(row,'Save policy',lambda:save_policy(),padx=12).pack(side='left',padx=8)
    app.label(controls,'Automatic approval applies only to complete, warning-free days after your Night Run confirmation.',
              8,color='#758298',wraplength=900,justify='left').pack(anchor='w',pady=(0,6))
    connection=app.label(controls,'',9,color='#758298',wraplength=900,justify='left');connection.pack(anchor='w')
    ready=app.panel(app.content,pad=14)
    app.colheader(ready,'SELECTED BUSINESS DATE: '+business_day)
    night=tk.BooleanVar(value=False);undated=tk.BooleanVar(value=False)
    tk.Checkbutton(ready,text='I confirm Comsys Night Run is complete for this business date.',variable=night,bg='white',
                   font=('Segoe UI' if os.name=='nt' else 'Helvetica',9),anchor='w').pack(anchor='w')
    tk.Checkbutton(ready,text='I verified any undated Night Report belongs to this same business date.',variable=undated,bg='white',
                   font=('Segoe UI' if os.name=='nt' else 'Helvetica',9),anchor='w').pack(anchor='w')
    actions=tk.Frame(ready,bg='white');actions.pack(fill='x',pady=(9,0))
    app.button(actions,'Mark day ready',lambda:mark_ready(),padx=14).pack(side='left',padx=(0,8))
    run_button=app.button(actions,'Process ready folders',lambda:process(),True,padx=14)
    run_button.pack(side='left')
    result_panel=app.panel(app.content,expand=True,pad=12)
    app.colheader(result_panel,'PROCESSING & DELIVERY STATUS')
    log=tk.Text(result_panel,height=8,wrap='word',font=('Segoe UI' if os.name=='nt' else 'Helvetica',9),relief='flat',bg='#F4F6FA',padx=12,pady=10)
    log.pack(fill='both',expand=True)
    log.insert('end','Create setup, export into the selected day folder, then mark it ready.\n'
               'Files must finish writing before processing. Email or WhatsApp delivery needs its connection configured first.\n')
    log.configure(state='disabled')
    results=queue.Queue()

    def add_log(value):
        if not log.winfo_exists():return
        log.configure(state='normal');log.insert('end',value+'\n');log.see('end');log.configure(state='disabled')
    def config():
        if not config_path.is_file():
            messagebox.showinfo('Create setup first','Click Create local setup before preparing folders.');return None
        try:return load_config(config_path)
        except Exception:
            messagebox.showerror('Automation setup needs correction','The local settings file cannot be read. Review the saved setup file; existing settings were preserved.')
            return None
    def refresh():
        if not config_path.is_file():
            connection.configure(text='AI: not connected. Delivery: not configured. Local summaries are available.');return
        try:current=load_config(config_path)
        except Exception:
            connection.configure(text='Local setup needs correction. Existing settings were preserved; review the setup file.')
            return
        policy.set(policy_labels[current.get('approval_mode','review')])
        ai=current.get('ai',{});ai_ready=bool(ai.get('enabled') and os.environ.get('SKYSTAR_AI_API_KEY') and (ai.get('model') or os.environ.get('SKYSTAR_AI_MODEL')))
        channel=current.get('delivery_channel','whatsapp')
        provider=gmail_config_status(current.get('email',{})) if channel=='email' else whatsapp_config_status(current.get('whatsapp',{}))
        name='Gmail' if channel=='email' else 'WhatsApp'
        connection.configure(text='AI: '+('configured; live connection not yet verified' if ai_ready else 'not connected; local summary available')+
                             '. '+name+': '+('configured; sending has not been verified' if provider['ready'] else 'not connected; open '+('Gmail settings' if channel=='email' else 'the Cloud API setup guide'))+'.')
    def initialize():
        try:
            init_config(config_path,overrides={'database':str(app.store.path.resolve())})
            refresh();add_log('Local setup is available. Database: '+str(app.store.path))
        except Exception as exc:messagebox.showerror('Automation setup',str(exc))
    def open_path(path):
        path=Path(path);path.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(path))
        else:subprocess.Popen(['xdg-open',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    def open_day():
        try:
            current=config()
            if current:open_path(Path(current['inbox'])/business_day)
        except Exception as exc:messagebox.showerror('Day folder',str(exc))
    def open_output():
        try:
            current=config()
            if current:open_path(current['outbox'])
        except Exception as exc:messagebox.showerror('Output folder',str(exc))
    def open_guide():
        guide=Path(__file__).resolve().parents[1]/'AUTOMATION_SETUP_AR.txt'
        try:
            if os.name=='nt':os.startfile(str(guide))
            else:subprocess.Popen(['xdg-open',str(guide)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except Exception as exc:messagebox.showerror('Connection setup guide',str(exc))
    def open_gmail_settings():
        current=config()
        if not current:return
        settings=current.get('email',{})
        dialog=tk.Toplevel(app);dialog.title('Gmail report delivery');dialog.transient(app)
        dialog.geometry('620x480');dialog.resizable(False,False)
        body=tk.Frame(dialog,bg='white',padx=22,pady=18);body.pack(fill='both',expand=True)
        app.label(body,'Send reports through your Gmail account',14,True,bg='white').pack(anchor='w')
        app.label(body,'Use a Google App Password after enabling 2-Step Verification.\nYour normal Google password is not required here.',
                  9,color='#758298',bg='white',justify='left').pack(anchor='w',pady=(8,12))
        form=tk.Frame(body,bg='white');form.pack(fill='x')
        sender=tk.StringVar(value=settings.get('sender',''));recipient=tk.StringVar(value=settings.get('recipient',''))
        password=tk.StringVar();enabled=tk.BooleanVar(value=settings.get('enabled',False) if current.get('delivery_channel')=='email' else True);excel=tk.BooleanVar(value=settings.get('attach_excel',True))
        for row,(label,variable,secret) in enumerate([('Sending Gmail address',sender,False),('Recipient address',recipient,False),('App Password (leave blank to keep)',password,True)]):
            app.label(form,label,9,bg='white').grid(row=row,column=0,sticky='w',pady=7,padx=(0,10))
            tk.Entry(form,textvariable=variable,show='*' if secret else '',width=33,relief='solid',bd=1).grid(row=row,column=1,sticky='ew',pady=7)
        form.columnconfigure(1,weight=1)
        tk.Checkbutton(body,text='Enable Gmail sending for prepared reports',variable=enabled,bg='white').pack(anchor='w',pady=(8,0))
        tk.Checkbutton(body,text='Attach Excel too when available',variable=excel,bg='white').pack(anchor='w')
        app.label(body,'The App Password is stored in Windows Credential Manager for this user.\nSaving settings does not send a message.',8,color='#758298',bg='white',justify='left').pack(anchor='w',pady=8)
        actions=tk.Frame(body,bg='white');actions.pack(fill='x')
        def save():
            try:
                candidate={**settings,'enabled':bool(enabled.get()),'sender':sender.get().strip(),
                           'recipient':recipient.get().strip(),'attach_excel':bool(excel.get())}
                check=gmail_config_status(candidate)
                invalid=[name for name in check['missing'] if name in ('email.sender','email.recipient','email.credential_source')]
                if invalid:
                    messagebox.showerror('Gmail settings','Enter valid sender and recipient addresses.',parent=dialog);return
                if password.get():
                    from local_credentials import save_gmail_password
                    save_gmail_password(candidate['sender'],password.get())
                    candidate['credential_source']='windows'
                    candidate['credential_revision']=datetime.now(timezone.utc).isoformat()
                raw=json.loads(config_path.read_text(encoding='utf-8'))
                raw['email']=candidate;raw['delivery_channel']='email'
                tmp=config_path.with_suffix('.tmp');tmp.write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(config_path)
                password.set('');dialog.destroy();refresh()
                add_log('Gmail settings saved locally. No message was sent. Use Process ready folders after connection setup.')
            except Exception:
                messagebox.showerror('Gmail settings not saved','Check the addresses and local credential setup. Passwords are never saved in the settings file.',parent=dialog)
        app.button(actions,'Save Gmail settings',save,True,padx=12).pack(side='right')
        def open_google():
            import webbrowser
            webbrowser.open('https://myaccount.google.com/apppasswords')
        app.button(actions,'Google App Passwords',open_google,padx=10).pack(side='left')
        dialog.grab_set()
        app.gmail_settings_ui={'dialog':dialog,'sender':sender,'recipient':recipient,'password':password,
                               'enabled':enabled,'attach_excel':excel,'save':save}

    def save_policy():
        try:
            current=config()
            if not current:return
            if policy_values[policy.get()]=='auto_when_clean' and not messagebox.askyesno('Automatic approval policy',
                'Allow a ready day to be approved automatically ONLY if all required sources and checks are complete, '
                'there are no warnings, and you confirmed Night Run?\n\nDays with issues remain for review.'):
                refresh();return
            raw=json.loads(config_path.read_text(encoding='utf-8'));raw['approval_mode']=policy_values[policy.get()]
            tmp=config_path.with_suffix('.tmp');tmp.write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(config_path)
            add_log('Approval policy saved: '+policy.get())
        except Exception as exc:messagebox.showerror('Approval policy',str(exc))
    def mark_ready():
        try:
            current=config()
            if not current:return
            date.fromisoformat(business_day)
            if not night.get():
                messagebox.showwarning('Night Run confirmation required','Confirm Night Run is complete for this exact business date first.');return
            folder=Path(current['inbox'])/business_day
            if not folder.is_dir() or not any(p.suffix.lower() in ('.xls','.xlsx','.zip') for p in folder.iterdir() if p.is_file()):
                messagebox.showwarning('Reports not found','Export the selected date reports into its day folder first.');return
            manifest={'business_date':business_day,'night_run_confirmed':True,'undated_night_date_confirmed':bool(undated.get()),
                      'confirmed_at':datetime.now(timezone.utc).isoformat()}
            tmp=folder/'READY.tmp';tmp.write_text(json.dumps(manifest,indent=2),encoding='utf-8');tmp.replace(folder/'READY.json')
            add_log('Day ready: '+business_day+'. This records your confirmation; processing still checks every report.')
        except Exception as exc:messagebox.showerror('Readiness confirmation',str(exc))
    def process():
        current=config()
        if not current:return
        run_button.configure(state='disabled');add_log('Processing ready folders…')
        def job():
            try:results.put(('ok',run_once(config_path,send=True)))
            except Exception as exc:results.put(('error',str(exc)))
        threading.Thread(target=job,daemon=True).start()
        app.after(150,poll)
    def poll():
        if not run_button.winfo_exists():return
        try:kind,payload=results.get_nowait()
        except queue.Empty:app.after(150,poll);return
        run_button.configure(state='normal')
        if kind=='error':add_log('Processing failed: '+payload)
        elif not payload:add_log('No stable ready day folders to process.')
        else:
            for item in payload:
                labels={'FINAL':'Final report ready','REVIEW':'Report requires review','WAITING':'Waiting for files to finish writing',
                        'SKIPPED':'Folder skipped','ERROR':'Processing needs attention'}
                delivery={'sent':'The sending service accepted this message','pending':'Not sent',
                          'awaiting_configuration':'The selected delivery connection is not configured',
                          'uncertain':'Delivery outcome is uncertain; check before retrying','failed':'Delivery was rejected'}
                add_log(str(item.get('business_date',''))+' — '+labels.get(item.get('status'),str(item.get('status',''))))
                channel='Gmail' if item.get('delivery_channel')=='email' else 'WhatsApp'
                add_log(channel+': '+delivery.get(item.get('delivery_status'),'No delivery attempted'))
                summary=item.get('summary',{})
                if summary.get('text'):add_log(('AI summary: ' if summary.get('mode')=='ai' else 'Local summary: ')+summary['text'])
                if item.get('output_dir'):add_log('Output folder: '+str(item['output_dir']))
                for issue in item.get('issues',[]):add_log('• '+str(issue.get('message','')))
                if item.get('reason'):add_log(str(item['reason']))
        refresh()
    refresh()
    # Hooks support meaningful GUI tests without triggering real providers.
    app.automation_ui={'config_path':config_path,'initialize':initialize,'mark_ready':mark_ready,
                       'night_confirmed':night,'undated_confirmed':undated,'refresh':refresh,'policy':policy,
                       'open_gmail_settings':open_gmail_settings}
