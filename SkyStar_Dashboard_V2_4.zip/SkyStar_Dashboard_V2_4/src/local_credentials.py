"""Optional, sender-scoped Gmail credentials in the current Windows user vault.

No password is written to a settings file. Environment credentials, if used by
callers, remain independent of this helper. The native API is never loaded on
non-Windows platforms.
"""
from __future__ import annotations

import ctypes
import os
import re

CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2  # Same Windows user on this computer.
ERROR_NOT_FOUND = 1168
_MAX_BLOB_BYTES = 2560
_TARGET_PREFIX = 'SkyStar/Gmail/'
_EMAIL = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+\Z")

# Explicit 32-bit integers keep the documented Windows structure layout even
# when unit tests execute on a platform where C unsigned long has another size.
DWORD = ctypes.c_uint32
BYTE = ctypes.c_ubyte
LPBYTE = ctypes.POINTER(BYTE)


class _FILETIME(ctypes.Structure):
    _fields_ = [('dwLowDateTime', DWORD), ('dwHighDateTime', DWORD)]


class _CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ('Flags', DWORD), ('Type', DWORD),
        ('TargetName', ctypes.c_wchar_p), ('Comment', ctypes.c_wchar_p),
        ('LastWritten', _FILETIME), ('CredentialBlobSize', DWORD),
        ('CredentialBlob', LPBYTE), ('Persist', DWORD),
        ('AttributeCount', DWORD), ('Attributes', ctypes.c_void_p),
        ('TargetAlias', ctypes.c_wchar_p), ('UserName', ctypes.c_wchar_p),
    ]


_PCREDENTIALW = ctypes.POINTER(_CREDENTIALW)


def _is_windows():
    return os.name == 'nt'


def _sender(value):
    if (not isinstance(value, str) or len(value) > 254
            or any(ord(char) < 32 or ord(char) == 127 for char in value)):
        raise ValueError('A valid Gmail sender address is required.')
    normalized = value.strip().lower()
    if not _EMAIL.fullmatch(normalized) or len(normalized.split('@', 1)[0]) > 64:
        raise ValueError('A valid Gmail sender address is required.')
    return normalized


def _password(value):
    if (not isinstance(value, str)
            or any(ord(char) < 32 or ord(char) == 127 for char in value)):
        raise ValueError('A valid Google App Password is required.')
    normalized = value.replace(' ', '')
    if (not normalized or not normalized.isascii() or len(normalized) > _MAX_BLOB_BYTES // 2):
        raise ValueError('A valid Google App Password is required.')
    return normalized


class _WinCred:
    """Small native adapter; injectable only so tests never access a real vault."""
    def __init__(self, dll=None, error_getter=None):
        if dll is None:
            dll = ctypes.WinDLL('Advapi32.dll', use_last_error=True)
        self.dll = dll
        self.error_getter = error_getter or ctypes.get_last_error
        dll.CredWriteW.argtypes = [ctypes.POINTER(_CREDENTIALW), DWORD]
        dll.CredWriteW.restype = ctypes.c_int
        dll.CredReadW.argtypes = [ctypes.c_wchar_p, DWORD, DWORD, ctypes.POINTER(_PCREDENTIALW)]
        dll.CredReadW.restype = ctypes.c_int
        dll.CredDeleteW.argtypes = [ctypes.c_wchar_p, DWORD, DWORD]
        dll.CredDeleteW.restype = ctypes.c_int
        dll.CredFree.argtypes = [ctypes.c_void_p]
        dll.CredFree.restype = None

    def write(self, sender, password):
        raw = password.encode('utf-16le')
        buffer = (BYTE * len(raw)).from_buffer_copy(raw)
        credential = _CREDENTIALW()
        credential.Type = CRED_TYPE_GENERIC
        credential.TargetName = _TARGET_PREFIX + sender
        credential.UserName = sender
        credential.Comment = 'SkyStar Gmail App Password'
        credential.Persist = CRED_PERSIST_LOCAL_MACHINE
        credential.CredentialBlobSize = len(raw)
        credential.CredentialBlob = ctypes.cast(buffer, LPBYTE)
        try:
            if not self.dll.CredWriteW(ctypes.byref(credential), 0):
                raise RuntimeError('Windows could not save the Gmail credential.')
        finally:
            ctypes.memset(ctypes.addressof(buffer), 0, len(raw))

    def read(self, sender):
        credential = _PCREDENTIALW()
        if not self.dll.CredReadW(_TARGET_PREFIX + sender, CRED_TYPE_GENERIC, 0, ctypes.byref(credential)):
            if self.error_getter() == ERROR_NOT_FOUND:
                return None
            raise RuntimeError('Windows could not read the Gmail credential.')
        try:
            if not credential:
                raise RuntimeError('The stored Gmail credential is not usable.')
            item = credential.contents
            size = item.CredentialBlobSize
            if (item.Type != CRED_TYPE_GENERIC or item.TargetName != _TARGET_PREFIX + sender
                    or (item.UserName or '').lower() != sender
                    or not item.CredentialBlob or not 0 < size <= _MAX_BLOB_BYTES or size % 2):
                raise RuntimeError('The stored Gmail credential is not usable for this account.')
            try:
                value = ctypes.string_at(item.CredentialBlob, size).decode('utf-16le')
                return _password(value)
            except (UnicodeError, ValueError):
                raise RuntimeError('The stored Gmail credential is not usable.') from None
        finally:
            self.dll.CredFree(ctypes.cast(credential, ctypes.c_void_p))

    def delete(self, sender):
        if self.dll.CredDeleteW(_TARGET_PREFIX + sender, CRED_TYPE_GENERIC, 0):
            return True
        if self.error_getter() == ERROR_NOT_FOUND:
            return False
        raise RuntimeError('Windows could not remove the Gmail credential.')


def _backend():
    try:
        return _WinCred()
    except Exception:
        raise RuntimeError('Windows Credential Manager is unavailable.') from None


def save_gmail_password(sender, password):
    """Save an App Password for this sender and current Windows user only."""
    if not _is_windows():
        raise RuntimeError('Saving credentials requires Windows Credential Manager.')
    address = _sender(sender)
    secret = _password(password)
    _backend().write(address, secret)


def load_gmail_password(sender):
    """Return this sender's password, or None if absent/non-Windows."""
    if not _is_windows():
        return None
    address = _sender(sender)
    return _backend().read(address)


def delete_gmail_password(sender):
    """Remove this sender's saved credential; return False if already absent."""
    if not _is_windows():
        raise RuntimeError('Removing credentials requires Windows Credential Manager.')
    address = _sender(sender)
    return _backend().delete(address)
