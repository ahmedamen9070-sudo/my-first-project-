"""Uncalibrated Windows Comsys export robot; no Night Run or report approval.

A profile must be calibrated against the actual installed Comsys controls. This
module does not contain guessed selectors, credentials, or a built-in workflow.
Only an explicit --run operates controls; validation works without Windows.
"""
from __future__ import annotations

import argparse
from datetime import date, datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import string
import sys
import tempfile
import time

from engine import TYPE_NAMES, parse_source

KINDS = frozenset(TYPE_NAMES.values())
KEYS = {'ENTER': '{ENTER}', 'TAB': '{TAB}', 'ESC': '{ESC}',
        'UP': '{UP}', 'DOWN': '{DOWN}', 'LEFT': '{LEFT}', 'RIGHT': '{RIGHT}',
        'HOME': '{HOME}', 'END': '{END}', 'SPACE': '{SPACE}', 'CTRL+A': '^a'}
TOKENS = {'business_date_dmy', 'business_date_iso', 'output_path'}
SELECTOR_KEYS = {'title', 'auto_id', 'control_type', 'class_name', 'found_index', 'scope'}


class RobotError(ValueError):
    """Profile, export, or calibration failed; a batch must not be released."""


def _fields(item, allowed, required, label):
    if not isinstance(item, dict) or set(item) - allowed or required - set(item):
        raise RobotError(f'Invalid {label} fields.')


def _text(value, label, maximum=500):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or '\x00' in value:
        raise RobotError(f'Invalid {label}.')
    return value


def _root_pattern(value):
    value = _text(value, 'Comsys window title expression', 200)
    try:
        pattern = re.compile(value)
    except re.error as exc:
        raise RobotError('Invalid Comsys window title expression.') from exc
    # Require some literal app identification, rather than a wildcard desktop root.
    if (not re.search(r'[A-Za-z\u0600-\u06ff]{3}', re.sub(r'\\[A-Za-z]', '', value))
            or any(pattern.search(sample) for sample in ('', 'Unrelated Window 129857', 'Notepad'))):
        raise RobotError('Use a specific Comsys window title expression, not a wildcard.')
    return value


def _selector(value):
    _fields(value, SELECTOR_KEYS, set(), 'selector')
    identity = set(value) & {'title', 'auto_id', 'control_type', 'class_name'}
    if not identity:
        raise RobotError('Each action needs an explicit control selector.')
    for key in identity:
        _text(value[key], f'selector {key}')
    if value.get('scope', 'main') not in ('main', 'desktop'):
        raise RobotError('Selector scope must be main or desktop in the Comsys process.')
    index = value.get('found_index', 0)
    if type(index) is not int or not 0 <= index <= 1000:
        raise RobotError('Invalid control found_index.')
    if re.search(r'\bnight[\s_-]*run\b', value.get('title', ''), re.I):
        raise RobotError('Night Run controls are outside the export robot scope.')


def _template(value):
    _text(value, 'action value', 2000)
    try:
        for _, field, spec, conversion in string.Formatter().parse(value):
            if field is not None and (field not in TOKENS or spec or conversion):
                raise RobotError('Only business_date_dmy, business_date_iso and output_path placeholders are allowed.')
    except ValueError as exc:
        raise RobotError('Invalid action value template.') from exc


def validate_profile(profile):
    """Validate the complete version-1 JSON schema without importing pywinauto."""
    _fields(profile, {'version', 'app', 'date_format', 'reports'},
            {'version', 'app', 'date_format', 'reports'}, 'profile')
    if type(profile['version']) is not int or profile['version'] != 1:
        raise RobotError('Only profile version 1 is supported.')
    app = profile['app']
    _fields(app, {'title_re', 'backend'}, {'title_re', 'backend'}, 'app')
    _root_pattern(app['title_re'])
    if app['backend'] not in ('uia', 'win32'):
        raise RobotError('UI backend must be uia or win32.')
    if profile['date_format'] not in ('%d/%m/%Y', '%Y-%m-%d'):
        raise RobotError('date_format must be %d/%m/%Y or %Y-%m-%d.')
    reports = profile['reports']
    if not isinstance(reports, list) or not 1 <= len(reports) <= len(KINDS):
        raise RobotError('A profile needs between 1 and 16 report definitions.')
    kinds, filenames = set(), set()
    for report in reports:
        _fields(report, {'kind', 'filename', 'steps'}, {'kind', 'filename', 'steps'}, 'report')
        kind = report['kind']
        if not isinstance(kind, str) or kind not in KINDS or kind in kinds:
            raise RobotError('Report kinds must be unique canonical Comsys report names.')
        kinds.add(kind)
        name = _text(report['filename'], 'report filename', 120)
        stem = name.split('.', 1)[0].upper()
        if (not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _.-]*\.(?:xls|xlsx)', name, re.I)
                or '..' in name or stem in {'CON', 'PRN', 'AUX', 'NUL'}
                or re.fullmatch(r'(?:COM|LPT)[1-9]', stem) or name.casefold() in filenames):
            raise RobotError('Use a unique safe basename ending in .xls or .xlsx.')
        filenames.add(name.casefold())
        steps = report['steps']
        if not isinstance(steps, list) or not 1 <= len(steps) <= 100:
            raise RobotError('Each report needs 1 to 100 calibrated export steps.')
        has_output = False
        for step in steps:
            if not isinstance(step, dict):
                raise RobotError('Invalid export step.')
            action = step.get('action')
            if action == 'wait':
                _fields(step, {'action', 'seconds'}, {'action', 'seconds'}, 'wait step')
                seconds = step['seconds']
                if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 0 <= seconds <= 10:
                    raise RobotError('Wait steps must be between 0 and 10 seconds.')
                continue
            if action not in ('click', 'set_text', 'select', 'menu', 'keys'):
                raise RobotError('Only click, set_text, select, menu, keys and wait actions are supported.')
            fields = {'action', 'selector'} | ({'value'} if action != 'click' else set())
            _fields(step, fields, fields, 'action')
            _selector(step['selector'])
            if action != 'click':
                value = step['value']
                if action == 'keys':
                    if not isinstance(value, str) or value not in KEYS:
                        raise RobotError('Unsupported key; arbitrary key sequences are prohibited.')
                else:
                    _template(value)
                    if action == 'menu' and re.search(r'\bnight[\s_-]*run\b', value, re.I):
                        raise RobotError('Night Run commands are outside the export robot scope.')
                    has_output |= '{output_path}' in value
        if not has_output:
            raise RobotError('Each report must explicitly save to {output_path}.')
    return profile


class WindowsBackend:
    """Connect only to one existing calibrated Comsys process; never launch/login."""
    def __init__(self, app):
        if sys.platform != 'win32':
            raise RobotError('Live Comsys automation requires its Windows machine; use --validate-profile here.')
        try:
            from pywinauto import Desktop
        except ImportError as exc:
            raise RobotError('Install pywinauto in the Windows Python environment to calibrate Comsys.') from exc
        self.desktop = Desktop(backend=app['backend'])
        windows = self.desktop.windows(title_re=_root_pattern(app['title_re']), visible_only=True)
        if len(windows) != 1:
            raise RobotError(f'Expected one Comsys main window, found {len(windows)}. Calibrate title_re.')
        self.root = windows[0]
        self.pid = self.root.process_id()

    def resolve(self, selector):
        _selector(selector)
        roots = [self.root] if selector.get('scope', 'main') == 'main' else self.desktop.windows(process=self.pid, visible_only=True)
        controls, seen = [], set()
        for root in roots:
            for control in [root, *root.descendants()]:
                if control.process_id() != self.pid:
                    continue
                info = control.element_info
                identity = (getattr(info, 'runtime_id', None), getattr(info, 'handle', None))
                # UIA runtime_id can be a list; handles alone are not unique for UIA.
                identity = str(identity)
                if identity in seen:
                    continue
                seen.add(identity)
                attributes = {'title': control.window_text(), 'auto_id': getattr(info, 'automation_id', ''),
                              'control_type': getattr(info, 'control_type', ''), 'class_name': getattr(info, 'class_name', '')}
                if all(attributes[key] == value for key, value in selector.items() if key in attributes):
                    controls.append(control)
        if not controls:
            raise RobotError('Calibrated control not found in the Comsys process.')
        if 'found_index' not in selector and len(controls) != 1:
            raise RobotError('Ambiguous control selector; calibrate an explicit unique selector.')
        index = selector.get('found_index', 0)
        if index >= len(controls):
            raise RobotError('Calibrated control index is unavailable.')
        return controls[index]

    def perform(self, step, context):
        control = self.resolve(step['selector'])
        value = step.get('value', '').format_map(context)
        action = step['action']
        if action == 'click':
            control.click_input()
        elif action == 'set_text':
            control.set_edit_text(value)
        elif action == 'select':
            control.select(value)
        elif action == 'menu':
            control.menu_select(value)
        elif action == 'keys':
            control.set_focus()
            control.type_keys(KEYS[step['value']], pause=0.05)

    def inspect(self):
        """Return control metadata, suppressing all text/edit/table/guest values."""
        items = []
        for control in [self.root, *self.root.descendants()]:
            if control.process_id() != self.pid:
                continue
            info = control.element_info
            control_type = getattr(info, 'control_type', '')
            # Even a window title may include a guest/account. Only action labels
            # of buttons/tabs/menu controls are useful for offline calibration.
            items.append({'title': control.window_text() if control_type in ('Button', 'MenuItem', 'TabItem') else '',
                          'auto_id': getattr(info, 'automation_id', ''),
                          'control_type': control_type, 'class_name': getattr(info, 'class_name', '')})
        return items


def _stable_file(path, timeout, clock, wait):
    deadline, previous, stable_since = clock() + timeout, None, None
    while True:
        if path.is_symlink():
            raise RobotError('Export output must be a regular file, not a symbolic link.')
        try:
            stat = path.stat()
            signature = (stat.st_size, stat.st_mtime_ns)
            if not path.is_file() or stat.st_size > 32 * 1024 * 1024:
                raise RobotError('Export output is not a supported regular workbook.')
            if stat.st_size and signature == previous:
                if stable_since is not None and clock() - stable_since >= 0.5:
                    return
            else:
                previous, stable_since = signature, clock()
        except FileNotFoundError:
            previous, stable_since = None, None
        if clock() >= deadline:
            raise RobotError('Timed out waiting for a complete exported workbook.')
        wait(0.2)


def run_profile(profile, day, output_dir, backend=None, *, confirm_night_run=False,
                confirm_undated_night_date=False, timeout=30, clock=time.monotonic, wait=time.sleep):
    """Export fresh files, verify workbook identity/date, then release a manifest.

    backend.perform(step, context) is injectable for offline tests. Explicit human
    Night Run confirmation is required for READY; exports alone never imply it.
    Existing output files/markers are refused. This does not approve the day.
    """
    validate_profile(profile)
    try:
        selected = date.fromisoformat(day)
        if selected.isoformat() != day:
            raise ValueError()
    except (TypeError, ValueError) as exc:
        raise RobotError('Business date must be YYYY-MM-DD.') from exc
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0.5 <= timeout <= 120:
        raise RobotError('File completion timeout must be between 0.5 and 120 seconds.')
    if type(confirm_night_run) is not bool or type(confirm_undated_night_date) is not bool:
        raise RobotError('Manual confirmations must be explicit boolean values.')
    if confirm_night_run and {r['kind'] for r in profile['reports']} != KINDS:
        raise RobotError('READY requires all 16 report kinds and explicit Night Run confirmation.')
    output = Path(output_dir).absolute()
    if output.is_symlink():
        raise RobotError('Output must be a real directory, not a symbolic link.')
    output.mkdir(parents=True, exist_ok=True)
    # An empty batch directory prevents stale reports and markers being reused.
    if any(output.iterdir()):
        raise RobotError('Output directory must be empty; existing reports or markers will not be overwritten.')
    robot = backend if backend is not None else WindowsBackend(profile['app'])
    results = []
    promoted = []
    with tempfile.TemporaryDirectory(prefix='.comsys-export-', dir=output) as temporary:
        staging = Path(temporary)
        try:
            for report in profile['reports']:
                path = staging / report['filename']
                context = {'business_date_iso': day, 'business_date_dmy': selected.strftime('%d/%m/%Y'),
                           'output_path': str(path)}
                for index, step in enumerate(report['steps'], 1):
                    try:
                        if step['action'] == 'wait':
                            wait(step['seconds'])
                        else:
                            robot.perform(step, context)
                    except Exception as exc:
                        raise RobotError(f'{report["kind"]}: export step {index} failed; calibrate the actual Comsys control.') from exc
                _stable_file(path, timeout, clock, wait)
                try:
                    parsed = parse_source(path)
                except Exception as exc:
                    if (report['kind'] != 'Night Report' or not confirm_undated_night_date
                            or not isinstance(exc, ValueError) or 'No readable business date' not in str(exc)):
                        raise RobotError(f'{report["kind"]}: exported workbook cannot be validated: {exc}') from exc
                    try:
                        parsed = parse_source(path, date_override=day)
                    except Exception as invalid:
                        raise RobotError('The manually dated Night Report cannot be validated.') from invalid
                if parsed['kind'] != report['kind'] or parsed['date'] != day:
                    raise RobotError(f'{report["kind"]}: workbook report kind or business date does not match.')
                results.append({'kind': parsed['kind'], 'filename': report['filename'],
                                'sha256': parsed['sha256'], 'date_origin': parsed.get('date_origin', 'report_header')})
            # Publish nothing until every configured report is validated.
            for report in results:
                target = output / report['filename']
                with target.open('xb') as destination:
                    promoted.append(target)
                    destination.write((staging / report['filename']).read_bytes())
            manifest = {'version': 1, 'business_date': day, 'reports': results,
                        'all_16_reports': {r['kind'] for r in results} == KINDS,
                        'completed_at': datetime.now(timezone.utc).isoformat()}
            marker = output / 'EXPORT_COMPLETE.json'
            with marker.open('x', encoding='utf-8') as stream:
                promoted.append(marker)
                json.dump(manifest, stream, indent=2)
            if confirm_night_run:
                ready = output / 'READY.json'
                with ready.open('x', encoding='utf-8') as stream:
                    promoted.append(ready)
                    json.dump({'business_date': day, 'night_run_confirmed': True,
                               'undated_night_date_confirmed': bool(confirm_undated_night_date),
                               'confirmed_at': datetime.now(timezone.utc).isoformat()}, stream, indent=2)
            return manifest
        except Exception:
            for path in reversed(promoted):
                path.unlink(missing_ok=True)
            raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--validate-profile', action='store_true', help='Validate JSON offline; does not operate controls.')
    mode.add_argument('--inspect', action='store_true', help='List safe control metadata on the Comsys Windows machine.')
    mode.add_argument('--run', action='store_true', help='Explicitly run a calibrated export profile.')
    parser.add_argument('--profile', type=Path)
    parser.add_argument('--day')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--title-re')
    parser.add_argument('--backend', choices=('uia', 'win32'), default='uia')
    parser.add_argument('--confirm-night-run', action='store_true', help='Manually confirm this business date has completed Night Run; never runs Night Run.')
    parser.add_argument('--confirm-undated-night-date', action='store_true', help='Manually certify this date for an undated Night Report only.')
    args = parser.parse_args(argv)
    try:
        if args.inspect:
            if not args.title_re:
                raise RobotError('--inspect requires the specific actual Comsys --title-re expression.')
            result = WindowsBackend({'title_re': args.title_re, 'backend': args.backend}).inspect()
        else:
            if not args.profile:
                raise RobotError('A calibrated --profile is required. Inspect controls on the Comsys Windows machine first.')
            profile = validate_profile(json.loads(args.profile.read_text(encoding='utf-8')))
            if args.validate_profile:
                result = {'valid': True, 'reports': len(profile['reports']), 'calibration': 'Requires real Comsys device validation.'}
            else:
                if not args.day or not args.output:
                    raise RobotError('--run requires --day YYYY-MM-DD and --output EMPTY_DAY_DIRECTORY.')
                result = run_profile(profile, args.day, args.output, confirm_night_run=args.confirm_night_run,
                                     confirm_undated_night_date=args.confirm_undated_night_date)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, RuntimeError) as exc:
        print(f'Comsys export stopped: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
