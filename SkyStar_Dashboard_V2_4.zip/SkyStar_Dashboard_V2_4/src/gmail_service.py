"""Optional Gmail SMTP delivery; configured credentials remain local.

Uses Google's fixed implicit-TLS SMTP endpoint. A successful response means
SMTP accepted the message, not that the recipient received or read it.
"""
from __future__ import annotations

from datetime import date
from email.message import EmailMessage
from email.policy import SMTP
from email.utils import formatdate, make_msgid
import os
import io
import zipfile
from pathlib import Path
import re
import smtplib
import ssl

from automation_services import (
    ServiceConfigurationError, ServiceRejected, ServiceError, DeliveryUncertain,
)

SMTP_HOST='smtp.gmail.com'
SMTP_PORT=465
TIMEOUT_SECONDS=30
MAX_TOTAL_ATTACHMENT_BYTES=15*1024*1024
_PASSWORD_ENV='SKYSTAR_GMAIL_APP_PASSWORD'
_ADDRESS=re.compile(r"[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}")


def _section(config):
    if not isinstance(config,dict):return {}
    candidate=config.get('email')
    return candidate if isinstance(candidate,dict) else config


def _address(value):
    if not isinstance(value,str) or len(value)>320 or any(c in value for c in '\r\n\x00'):
        return None
    value=value.strip()
    return value if _ADDRESS.fullmatch(value) else None


def _password(config):
    value=os.environ.get(_PASSWORD_ENV,'') if config.get('credential_source','auto')!='windows' else ''
    if not value:
        sender=_address(config.get('sender'))
        if sender:
            try:
                from local_credentials import load_gmail_password
                value=load_gmail_password(sender) or ''
            except (ImportError,RuntimeError,OSError):
                value=''
    if not isinstance(value,str) or any(ord(c)<32 or ord(c)==127 for c in value):return None
    # Google's app-password display groups characters with spaces. Those spaces
    # are not part of the authentication password.
    value=value.replace(' ','')
    return value if 8<=len(value)<=512 else None


def gmail_config_status(config):
    """Report requirement names only; never return credential values."""
    cfg=_section(config);missing=[]
    if cfg.get('enabled') is not True:missing.append('email.enabled')
    if not _address(cfg.get('sender')):missing.append('email.sender')
    if not _address(cfg.get('recipient')):missing.append('email.recipient')
    if type(cfg.get('attach_excel',True)) is not bool:missing.append('email.attach_excel')
    if cfg.get('credential_source','auto') not in ('auto','windows'):missing.append('email.credential_source')
    if not _password(cfg):missing.append(_PASSWORD_ENV)
    return {'ready':not missing,'missing':missing}


def _read_attachment(path,extension,remaining):
    try:
        item=Path(path)
        if item.suffix.lower()!=extension or not item.is_file() or item.stat().st_size>remaining:
            raise ValueError()
        with item.open('rb') as stream:data=stream.read(remaining+1)
        if not data or len(data)>remaining:raise ValueError()
        if extension=='.pdf' and not data.startswith(b'%PDF-'):raise ValueError()
        if extension=='.xlsx':
            with zipfile.ZipFile(io.BytesIO(data)) as workbook:
                if not {'[Content_Types].xml','xl/workbook.xml'}.issubset(workbook.namelist()):raise ValueError()
    except (OSError,TypeError,ValueError,zipfile.BadZipFile):
        raise ServiceConfigurationError('A readable PDF and optional Excel report within the attachment limit are required.') from None
    name=re.sub(r'[^A-Za-z0-9_.-]','_',item.name)[:150]
    if not name:name='daily-sales'+extension
    return item.resolve(),name,data


def _smtp_code(error):
    code=getattr(error,'smtp_code',None)
    return code if isinstance(code,int) and not isinstance(code,bool) and 100<=code<=599 else None


def send_gmail_report(path,business_date,status,summary,config,attachments=None,smtp_factory=None):
    """Send one PDF and optional generated XLSX via configured Gmail SMTP.

    All SMTP interactions can be replaced by ``smtp_factory`` in tests. It must
    accept the same arguments as smtplib.SMTP_SSL. Never retries a message here.
    Ambiguity after message submission requires caller/operator review.
    """
    cfg=_section(config);setup=gmail_config_status(cfg)
    if not setup['ready']:
        raise ServiceConfigurationError('Gmail SMTP is not configured: '+', '.join(setup['missing']))
    try:
        selected=date.fromisoformat(business_date).isoformat()
        if selected!=business_date:raise ValueError()
    except (TypeError,ValueError):
        raise ServiceConfigurationError('A valid business date is required.') from None
    if status not in {'FINAL','REVIEW'}:
        raise ServiceConfigurationError('The report must be marked FINAL or REVIEW.')
    if attachments is not None and not isinstance(attachments,(list,tuple)):
        raise ServiceConfigurationError('Optional Excel reports must be supplied as a list.')
    sender=_address(cfg['sender']);recipient=_address(cfg['recipient']);secret=_password(cfg)
    if not secret:raise ServiceConfigurationError('The local Gmail app password is not available.')
    primary,name,data=_read_attachment(path,'.pdf',MAX_TOTAL_ATTACHMENT_BYTES)
    documents=[(name,data,'application','pdf')];seen={primary};total=len(data)
    if cfg.get('attach_excel',True):
        for extra in attachments or ():
            try:resolved=Path(extra).resolve()
            except (TypeError,ValueError,OSError):
                raise ServiceConfigurationError('An optional Excel report path is invalid.') from None
            if resolved in seen:continue
            resolved,filename,content=_read_attachment(extra,'.xlsx',MAX_TOTAL_ATTACHMENT_BYTES-total)
            seen.add(resolved);total+=len(content)
            documents.append((filename,content,'application','vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
    message=EmailMessage(policy=SMTP)
    message['From']=sender;message['To']=recipient
    message['Subject']=f'[SkyStar][{status}] Daily Sales - {selected}'
    message['Date']=formatdate(localtime=False,usegmt=True)
    message_id=make_msgid(domain=sender.rsplit('@',1)[1]);message['Message-ID']=message_id
    text=str(summary or '')[:10000]
    # The worker supplies only aggregate summaries, but do not accidentally echo
    # the locally configured password if a caller supplied it in the text.
    text=text.replace(secret,'[redacted]')
    formatted=os.environ.get(_PASSWORD_ENV,'')
    if len(formatted)>=8:text=text.replace(formatted,'[redacted]')
    label='تقرير نهائي' if status=='FINAL' else 'نسخة للمراجعة — غير معتمدة'
    message.set_content(f'SkyStar Daily Sales\nBusiness date: {selected}\nStatus: {status}\n{label}\n\n{text}\n',charset='utf-8')
    for filename,content,main,sub in documents:
        message.add_attachment(content,maintype=main,subtype=sub,filename=filename)
    factory=smtp_factory or smtplib.SMTP_SSL
    client=None
    try:
        try:
            client=factory(SMTP_HOST,SMTP_PORT,timeout=TIMEOUT_SECONDS,context=ssl.create_default_context())
        except Exception:
            raise ServiceError('Gmail SMTP connection failed; no message was submitted.') from None
        try:
            client.login(sender,secret)
        except smtplib.SMTPAuthenticationError as error:
            raise ServiceRejected('Gmail authentication was rejected. Review the local app password and account policy.',_smtp_code(error)) from None
        except Exception:
            raise ServiceError('Gmail authentication could not complete; no message was submitted.') from None
        try:
            refused=client.send_message(message,from_addr=sender,to_addrs=[recipient])
        except (smtplib.SMTPRecipientsRefused,smtplib.SMTPSenderRefused,smtplib.SMTPDataError) as error:
            raise ServiceRejected('Gmail explicitly rejected the report message.',_smtp_code(error)) from None
        except smtplib.SMTPNotSupportedError:
            raise ServiceRejected('Gmail SMTP does not support the required message operation.') from None
        except Exception:
            raise DeliveryUncertain('Gmail message outcome is uncertain. Check the sending account before retrying.') from None
        if not isinstance(refused,dict):
            raise DeliveryUncertain('Gmail SMTP did not return a verifiable acceptance result. Review delivery before retrying.')
        if refused:
            if set(refused)=={recipient}:
                raise ServiceRejected('Gmail rejected the report recipient.')
            raise DeliveryUncertain('Gmail recipient acceptance could not be verified. Review delivery before retrying.')
        return {'message_id':message_id,'accepted':True,'provider':'gmail'}
    finally:
        if client is not None:
            # DATA acceptance remains valid even if a subsequent QUIT fails.
            try:client.quit()
            except Exception:pass
            try:client.close()
            except Exception:pass
