param(
    [string]$ConfigPath = (Join-Path $env:USERPROFILE '.sky_star_daily_sales_v8_3\automation\config.json'),
    [ValidatePattern('^$|^(?:[01][0-9]|2[0-3]):[0-5][0-9]$')]
    [string]$DailyAt = ''
)
$ErrorActionPreference = 'Stop'
$workerPath = Join-Path $PSScriptRoot 'src\automation_worker.py'
if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    throw 'Run SETUP_AUTOMATION_WINDOWS.bat first.'
}
$pythonCommand = Get-Command py -ErrorAction SilentlyContinue
$pythonPrefix = '-3 '
if (-not $pythonCommand) {
    $pythonCommand = Get-Command python -ErrorAction Stop
    $pythonPrefix = ''
}
$scheduleText = if ($DailyAt) { 'daily at ' + $DailyAt + ' (Windows local time)' } else { 'every 5 minutes' }
$confirm = Read-Host ('Install a task to process READY folders ' + $scheduleText + ' while you are logged in? Type YES')
if ($confirm -cne 'YES') { Write-Host 'No scheduled task was installed.'; exit 0 }
$arguments = $pythonPrefix + '-X utf8 "' + $workerPath + '" --run --send --config "' + $ConfigPath + '"'
$action = New-ScheduledTaskAction -Execute $pythonCommand.Source -Argument $arguments -WorkingDirectory $PSScriptRoot
if ($DailyAt) {
    $at = [datetime]::ParseExact($DailyAt, 'HH:mm', [System.Globalization.CultureInfo]::InvariantCulture)
    $trigger = New-ScheduledTaskTrigger -Daily -At $at
} else {
    $trigger = New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(1)) -RepetitionInterval (New-TimeSpan -Minutes 5)
}
$principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName 'SkyStarDailySalesAutomation' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Processes confirmed Comsys report folders; optional configured provider delivery.' -Force | Out-Null
Write-Host 'Task installed for the current logged-in user. The computer must be available; Gmail, WhatsApp and AI still require configured accounts; Comsys export is not automated by this task.'
