"""Offline robot contract tests using synthetic real XLSX and a fake UI adapter."""
import copy
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from comsys_robot import KINDS, RobotError, WindowsBackend, main, run_profile, validate_profile
from engine import TYPE_NAMES
from test_daily_sales_workflow import DAY, synthetic_reports, write_xlsx


class Clock:
    def __init__(self): self.now = 0
    def __call__(self): return self.now
    def wait(self, seconds): self.now += seconds


def profile(full=True):
    definitions = []
    for sheet in synthetic_reports():
        definitions.append({'kind': TYPE_NAMES[sheet], 'filename': sheet + '.xlsx', 'steps': [
            {'action': 'set_text', 'selector': {'auto_id': 'FAKE_TEST_ONLY'}, 'value': '{output_path}'},
        ]})
    return {'version': 1, 'app': {'title_re': '^FAKE Comsys QA$', 'backend': 'uia'},
            'date_format': '%d/%m/%Y', 'reports': definitions if full else definitions[:1]}


class FakeBackend:
    def __init__(self, day=DAY, wrong_kind=False, missing=False, undated=False):
        self.day, self.wrong_kind, self.missing, self.undated = day, wrong_kind, missing, undated
        self.calls = []
    def perform(self, step, context):
        self.calls.append((step, context.copy()))
        if self.missing: return
        path = Path(context['output_path'])
        sheet = 'Daily_Sales' if self.wrong_kind else path.stem
        rows = synthetic_reports(self.day)[sheet]
        if self.undated and sheet == 'Night_Report':
            rows[0] = {0: 'SYNTHETIC QA ONLY'}
        write_xlsx(path, sheet, rows)


class ComsysRobotTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.output = Path(self.tmp.name) / DAY
        self.clock = Clock()
    def tearDown(self): self.tmp.cleanup()
    def run_robot(self, value=None, backend=None, **kwargs):
        return run_profile(value or profile(), DAY, self.output, backend=backend or FakeBackend(),
                           clock=self.clock, wait=self.clock.wait, timeout=1, **kwargs)
    def assert_unreleased(self):
        self.assertFalse((self.output / 'READY.json').exists())
        self.assertFalse((self.output / 'EXPORT_COMPLETE.json').exists())
        self.assertFalse(list(self.output.glob('*.xlsx')) if self.output.exists() else [])
    def test_all_16_real_workbooks_verified_without_inferred_night_run(self):
        result = self.run_robot()
        self.assertEqual(len(result['reports']), 16)
        self.assertEqual({r['kind'] for r in result['reports']}, KINDS)
        self.assertTrue(result['all_16_reports'])
        self.assertTrue(all(len(r['sha256']) == 64 for r in result['reports']))
        self.assertEqual(json.loads((self.output / 'EXPORT_COMPLETE.json').read_text()), result)
        self.assertFalse((self.output / 'READY.json').exists())
    def test_ready_requires_explicit_manual_confirmation(self):
        self.run_robot(confirm_night_run=True)
        marker = json.loads((self.output / 'READY.json').read_text())
        self.assertEqual(marker['business_date'], DAY)
        self.assertIs(marker['night_run_confirmed'], True)
        self.assertIs(marker['undated_night_date_confirmed'], False)
    def test_partial_profile_has_export_manifest_but_cannot_release_ready(self):
        result = self.run_robot(profile(False))
        self.assertFalse(result['all_16_reports'])
        self.assertFalse((self.output / 'READY.json').exists())
        other = Path(self.tmp.name) / 'partial'
        with self.assertRaisesRegex(RobotError, 'all 16'):
            run_profile(profile(False), DAY, other, backend=FakeBackend(), confirm_night_run=True)
        self.assertFalse(other.exists())
    def test_wrong_business_date_stops_entire_batch(self):
        with self.assertRaisesRegex(RobotError, 'business date'):
            self.run_robot(backend=FakeBackend(day='2026-11-02'), confirm_night_run=True)
        self.assert_unreleased()
    def test_wrong_report_kind_stops_entire_batch(self):
        with self.assertRaisesRegex(RobotError, 'report kind'):
            self.run_robot(backend=FakeBackend(wrong_kind=True))
        self.assert_unreleased()
    def test_missing_file_times_out_without_real_sleep_or_ready(self):
        with self.assertRaisesRegex(RobotError, 'Timed out'):
            self.run_robot(backend=FakeBackend(missing=True), confirm_night_run=True)
        self.assert_unreleased()
    def test_undated_night_requires_separate_manual_date_certification(self):
        with self.assertRaisesRegex(RobotError, 'No readable business date'):
            self.run_robot(backend=FakeBackend(undated=True), confirm_night_run=True)
        self.assert_unreleased()
        result = self.run_robot(backend=FakeBackend(undated=True), confirm_night_run=True,
                                confirm_undated_night_date=True)
        night = next(r for r in result['reports'] if r['kind'] == 'Night Report')
        self.assertEqual(night['date_origin'], 'manually_verified')
    def test_existing_report_is_not_overwritten_or_accepted_as_fresh(self):
        self.output.mkdir()
        existing = self.output / profile()['reports'][0]['filename']
        existing.write_bytes(b'KEEP EXISTING')
        fake = FakeBackend()
        with self.assertRaisesRegex(RobotError, 'empty'):
            self.run_robot(backend=fake)
        self.assertEqual(existing.read_bytes(), b'KEEP EXISTING')
        self.assertEqual(fake.calls, [])
        self.assertFalse((self.output / 'READY.json').exists())
    def test_stale_ready_marker_is_not_reused(self):
        self.output.mkdir()
        marker = self.output / 'READY.json'
        marker.write_text('{}')
        with self.assertRaisesRegex(RobotError, 'empty'):
            self.run_robot()
        self.assertEqual(marker.read_text(), '{}')
    def test_bad_headers_do_not_publish(self):
        class BadWorkbook:
            def perform(self, step, context):
                Path(context['output_path']).write_bytes(b'not an Excel report')
        with self.assertRaises(ValueError):
            self.run_robot(backend=BadWorkbook())
        self.assert_unreleased()
    def test_profile_rejects_unsafe_or_uncalibrated_actions(self):
        mutations = [
            lambda p: p['app'].update(title_re='.*'),
            lambda p: p['reports'][0].update(filename='../source.xlsx'),
            lambda p: p['reports'][0].update(filename='C:\\source.xlsx'),
            lambda p: p['reports'][0].update(filename='CON.xlsx'),
            lambda p: p['reports'][0]['steps'][0].update(action='exec'),
            lambda p: p['reports'][0]['steps'][0].update(selector={}),
            lambda p: p['reports'][0]['steps'][0].update(selector={'scope': 'desktop'}),
            lambda p: p['reports'][0]['steps'][0].update(value='{password}'),
            lambda p: p['reports'][0]['steps'][0].update(value='{output_path.__class__}'),
            lambda p: p['reports'][0]['steps'].append({'action': 'keys', 'selector': {'title': 'Fake'}, 'value': '%{F4}'}),
            lambda p: p['reports'][0]['steps'].append({'action': 'click', 'selector': {'title': 'Night Run'}}),
            lambda p: p['reports'][0]['steps'].append({'action': 'wait', 'seconds': float('inf')}),
            lambda p: p['reports'].append(copy.deepcopy(p['reports'][0])),
        ]
        for mutate in mutations:
            value = profile()
            mutate(value)
            with self.subTest(mutation=mutate), self.assertRaises(RobotError):
                validate_profile(value)
    def test_symbolic_output_directory_rejected(self):
        target = Path(self.tmp.name) / 'target'
        target.mkdir()
        self.output.symlink_to(target, target_is_directory=True)
        with self.assertRaisesRegex(RobotError, 'symbolic'):
            self.run_robot()
        self.assertEqual(list(target.iterdir()), [])
    def test_validation_cli_is_offline(self):
        path = Path(self.tmp.name) / 'profile.json'
        path.write_text(json.dumps(profile()), encoding='utf-8')
        with patch('comsys_robot.WindowsBackend', side_effect=AssertionError('No UI access')):
            with patch('builtins.print'):
                self.assertEqual(main(['--validate-profile', '--profile', str(path)]), 0)
    def test_no_builtin_profile_or_live_execution_on_linux(self):
        with patch('builtins.print'):
            self.assertEqual(main(['--run', '--day', DAY, '--output', str(self.output)]), 1)
        with patch('comsys_robot.sys.platform', 'linux'):
            with self.assertRaisesRegex(RobotError, 'Windows'):
                WindowsBackend(profile()['app'])
    def test_backend_failure_never_publishes(self):
        class Broken:
            def perform(self, step, context): raise RuntimeError('simulated UI mismatch')
        with self.assertRaisesRegex(RobotError, 'calibrate'):
            self.run_robot(backend=Broken(), confirm_night_run=True)
        self.assert_unreleased()
    def test_native_selector_rejects_ambiguity_and_cross_process_controls(self):
        class Control:
            def __init__(self, handle, pid=123, name='Export', children=()):
                self.element_info = SimpleNamespace(handle=handle, runtime_id=[handle],
                    automation_id='export', class_name='Button', control_type='Button')
                self.pid, self.name, self.children = pid, name, children
            def process_id(self): return self.pid
            def window_text(self): return self.name
            def descendants(self): return list(self.children)
        first, second, foreign = Control(2), Control(3), Control(4, pid=999)
        robot = object.__new__(WindowsBackend)
        robot.root = Control(1, name='Main', children=(first, second, foreign))
        robot.pid = 123
        robot.desktop = SimpleNamespace(windows=lambda **kwargs: [robot.root, foreign])
        with self.assertRaisesRegex(RobotError, 'Ambiguous'):
            robot.resolve({'title': 'Export', 'scope': 'desktop'})
        self.assertIs(robot.resolve({'title': 'Export', 'scope': 'desktop', 'found_index': 1}), second)
        with self.assertRaisesRegex(RobotError, 'unavailable'):
            robot.resolve({'title': 'Export', 'scope': 'desktop', 'found_index': 2})


if __name__ == '__main__': unittest.main()
