"""Windows vault contract using fake native calls, never a real credential store."""
import ctypes
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import local_credentials as vault


class Function:
    def __init__(self, callback):
        self.callback = callback
    def __call__(self, *args):
        return self.callback(*args)


class FakeWinCred:
    def __init__(self):
        self.entries = {}
        self.references = []
        self.freed = []
        self.error = vault.ERROR_NOT_FOUND
        self.write_ok = True
        self.CredWriteW = Function(self.write)
        self.CredReadW = Function(self.read)
        self.CredDeleteW = Function(self.delete)
        self.CredFree = Function(self.free)
    def write(self, pointer, flags):
        item = ctypes.cast(pointer, ctypes.POINTER(vault._CREDENTIALW)).contents
        if not self.write_ok:
            return 0
        self.entries[item.TargetName] = {
            'type': item.Type, 'username': item.UserName,
            'blob': ctypes.string_at(item.CredentialBlob, item.CredentialBlobSize),
            'persist': item.Persist,
        }
        return 1
    def read(self, target, kind, flags, result):
        value = self.entries.get(target)
        if value is None:
            self.error = vault.ERROR_NOT_FOUND
            return 0
        blob = (vault.BYTE * len(value['blob'])).from_buffer_copy(value['blob'])
        item = vault._CREDENTIALW()
        item.Type = value['type'];item.TargetName = target;item.UserName = value['username']
        item.CredentialBlob = ctypes.cast(blob, vault.LPBYTE)
        item.CredentialBlobSize = len(value['blob'])
        pointer = ctypes.pointer(item)
        self.references.append((blob, item, pointer))
        ctypes.cast(result, ctypes.POINTER(vault._PCREDENTIALW))[0] = pointer
        return 1
    def delete(self, target, kind, flags):
        if target not in self.entries:
            self.error = vault.ERROR_NOT_FOUND
            return 0
        del self.entries[target]
        return 1
    def free(self, pointer):
        self.freed.append(pointer.value)


class LocalCredentialTests(unittest.TestCase):
    def setUp(self):
        self.native = FakeWinCred()
        self.backend = vault._WinCred(self.native, lambda: self.native.error)
        self.platform = patch.object(vault, '_is_windows', return_value=True)
        self.factory = patch.object(vault, '_backend', return_value=self.backend)
        self.platform.start();self.factory.start()
    def tearDown(self):
        self.factory.stop();self.platform.stop()
    def test_save_load_is_sender_scoped_and_normalizes_app_password_groups(self):
        with patch('builtins.open', side_effect=AssertionError('No plaintext files allowed')):
            vault.save_gmail_password('Owner@Gmail.com', 'abcd efgh ijkl mnop')
            self.assertEqual(vault.load_gmail_password('owner@gmail.com'), 'abcdefghijklmnop')
            self.assertIsNone(vault.load_gmail_password('different@gmail.com'))
        saved = self.native.entries['SkyStar/Gmail/owner@gmail.com']
        self.assertEqual(saved['type'], vault.CRED_TYPE_GENERIC)
        self.assertEqual(saved['persist'], vault.CRED_PERSIST_LOCAL_MACHINE)
        self.assertEqual(saved['username'], 'owner@gmail.com')
        self.assertEqual(len(self.native.freed), 1)
    def test_delete_targets_only_selected_sender(self):
        vault.save_gmail_password('one@gmail.com', 'one-test-password')
        vault.save_gmail_password('two@gmail.com', 'two-test-password')
        self.assertTrue(vault.delete_gmail_password('one@gmail.com'))
        self.assertFalse(vault.delete_gmail_password('one@gmail.com'))
        self.assertIsNone(vault.load_gmail_password('one@gmail.com'))
        self.assertEqual(vault.load_gmail_password('two@gmail.com'), 'two-test-password')
    def test_non_windows_load_is_inert_and_writes_are_unsupported(self):
        with patch.object(vault, '_is_windows', return_value=False), patch.object(vault, '_backend') as backend:
            self.assertIsNone(vault.load_gmail_password('owner@gmail.com'))
            with self.assertRaises(RuntimeError):vault.save_gmail_password('owner@gmail.com', 'test')
            with self.assertRaises(RuntimeError):vault.delete_gmail_password('owner@gmail.com')
            backend.assert_not_called()
    def test_header_injection_and_empty_or_control_password_rejected(self):
        for sender in ['owner@gmail.com\r\nBcc: other@gmail.com', 'Display <owner@gmail.com>', 'not-an-email', 'a@b']:
            with self.subTest(sender=sender), self.assertRaises(ValueError):
                vault.save_gmail_password(sender, 'not-a-real-password')
        for password in ['', '   ', 'password\r\n', 'password\0hidden', 'password\ttab', 'invalid-\ud800-surrogate', 'non-ascii-كلمة']:
            with self.subTest(password=password), self.assertRaises(ValueError):
                vault.save_gmail_password('owner@gmail.com', password)
        self.assertEqual(self.native.entries, {})
    def test_missing_credential_is_not_a_failure(self):
        self.assertIsNone(vault.load_gmail_password('owner@gmail.com'))
        self.assertEqual(self.native.freed, [])
    def test_corrupt_or_wrong_account_blob_is_freed_and_never_returned(self):
        vault.save_gmail_password('owner@gmail.com', 'not-a-real-test-password')
        target = 'SkyStar/Gmail/owner@gmail.com'
        self.native.entries[target]['username'] = 'different@gmail.com'
        with self.assertRaisesRegex(RuntimeError, 'not usable'):
            vault.load_gmail_password('owner@gmail.com')
        self.assertEqual(len(self.native.freed), 1)
        self.native.entries[target]['username'] = 'owner@gmail.com'
        self.native.entries[target]['blob'] = b'\x00'
        with self.assertRaisesRegex(RuntimeError, 'not usable'):
            vault.load_gmail_password('owner@gmail.com')
        self.assertEqual(len(self.native.freed), 2)
    def test_native_write_failure_is_sanitized(self):
        self.native.write_ok = False
        secret = 'do-not-expose-this-value'
        with self.assertRaises(RuntimeError) as caught:
            vault.save_gmail_password('owner@gmail.com', secret)
        self.assertNotIn(secret, str(caught.exception))
        self.assertNotIn('owner@gmail.com', str(caught.exception))
    def test_non_missing_native_read_delete_failures_are_sanitized(self):
        self.native.CredReadW = Function(lambda *args: 0)
        self.native.CredDeleteW = Function(lambda *args: 0)
        self.native.error = 5
        with self.assertRaisesRegex(RuntimeError, 'could not read'):
            vault.load_gmail_password('owner@gmail.com')
        with self.assertRaisesRegex(RuntimeError, 'could not remove'):
            vault.delete_gmail_password('owner@gmail.com')
    def test_windows_layout_uses_fixed_width_dwords(self):
        self.assertEqual(ctypes.sizeof(vault.DWORD), 4)
        self.assertEqual(ctypes.sizeof(vault._FILETIME), 8)
        self.assertEqual(ctypes.sizeof(vault._CREDENTIALW), 80 if ctypes.sizeof(ctypes.c_void_p) == 8 else 52)


if __name__ == '__main__':unittest.main()
