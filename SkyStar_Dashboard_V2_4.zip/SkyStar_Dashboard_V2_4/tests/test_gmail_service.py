"""Gmail SMTP MIME and failure handling with fake clients only."""
import io
import os
from pathlib import Path
import smtplib
import ssl
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import zipfile

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from gmail_service import gmail_config_status,send_gmail_report,MAX_TOTAL_ATTACHMENT_BYTES
from automation_services import ServiceConfigurationError,ServiceRejected,ServiceError,DeliveryUncertain

PASSWORD='abcdefghijklmnop'  # Non-working test fixture, not a credential.

class FakeSMTP:
    def __init__(self):
        self.login_calls=[];self.messages=[];self.closed=False;self.quit_calls=0
        self.auth_error=None;self.send_error=None;self.refused={};self.quit_error=None
    def login(self,sender,password):
        self.login_calls.append((sender,password))
        if self.auth_error:raise self.auth_error
    def send_message(self,message,from_addr,to_addrs):
        self.messages.append((message,from_addr,to_addrs))
        if self.send_error:raise self.send_error
        return self.refused
    def quit(self):
        self.quit_calls+=1
        if self.quit_error:raise self.quit_error
    def close(self):self.closed=True

class GmailService(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.pdf=self.root/'daily.pdf';self.pdf.write_bytes(b'%PDF-1.7\nSynthetic test only\n')
        self.xlsx=self.root/'daily.xlsx'
        with zipfile.ZipFile(self.xlsx,'w') as z:
            z.writestr('[Content_Types].xml','<Types/>');z.writestr('xl/workbook.xml','<workbook/>')
        self.config={'enabled':True,'sender':'unit.test+sender@gmail.com','recipient':'unit.test.recipient@gmail.com','attach_excel':True}
        self.client=FakeSMTP();self.factory_calls=[]
        def factory(*args,**kwargs):
            self.factory_calls.append((args,kwargs));return self.client
        self.factory=factory
        self.environment=patch.dict(os.environ,{'SKYSTAR_GMAIL_APP_PASSWORD':PASSWORD})
        self.environment.start()
        # Tests do not access a real Windows credential store on any host.
        self.vault_loader=lambda sender:None
        self.vault=types.SimpleNamespace(load_gmail_password=lambda sender:self.vault_loader(sender))
        self.module_patch=patch.dict(sys.modules,{'local_credentials':self.vault});self.module_patch.start()
    def tearDown(self):
        self.module_patch.stop();self.environment.stop();self.tmp.cleanup()
    def send(self,**kwargs):
        values={'path':self.pdf,'business_date':'2026-11-01','status':'FINAL','summary':'ملخص عربي تجريبي: الإيراد 1,275.00.','config':self.config,'smtp_factory':self.factory}
        values.update(kwargs);return send_gmail_report(**values)
    def test_disabled_or_missing_credentials_never_connect(self):
        self.config['enabled']=False
        with self.assertRaises(ServiceConfigurationError):self.send()
        self.assertEqual(self.factory_calls,[])
        self.config['enabled']=True
        with patch.dict(os.environ,{'SKYSTAR_GMAIL_APP_PASSWORD':''}):
            status=gmail_config_status(self.config)
            self.assertFalse(status['ready']);self.assertIn('SKYSTAR_GMAIL_APP_PASSWORD',status['missing'])
            with self.assertRaises(ServiceConfigurationError):self.send()
        self.assertEqual(self.factory_calls,[])
    def test_verified_tls_sender_single_recipient_and_utf8_mime(self):
        result=self.send(attachments=[self.xlsx])
        args,kwargs=self.factory_calls[0]
        self.assertEqual(args,('smtp.gmail.com',465));self.assertEqual(kwargs['timeout'],30)
        context=kwargs['context'];self.assertIsInstance(context,ssl.SSLContext)
        self.assertTrue(context.check_hostname);self.assertEqual(context.verify_mode,ssl.CERT_REQUIRED)
        self.assertEqual(self.client.login_calls,[(self.config['sender'],PASSWORD)])
        message,sender,recipients=self.client.messages[0]
        self.assertEqual(sender,self.config['sender']);self.assertEqual(recipients,[self.config['recipient']])
        self.assertEqual(str(message['From']),sender);self.assertEqual(str(message['To']),self.config['recipient'])
        self.assertIn('[FINAL]',message['Subject']);self.assertIn('2026-11-01',message['Subject'])
        self.assertIn('ملخص عربي',message.get_body(preferencelist=('plain',)).get_content())
        parts=list(message.iter_attachments())
        self.assertEqual([p.get_content_type() for p in parts],['application/pdf','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
        self.assertEqual(parts[0].get_payload(decode=True),self.pdf.read_bytes())
        self.assertEqual(parts[1].get_payload(decode=True),self.xlsx.read_bytes())
        self.assertTrue(result['accepted']);self.assertEqual(result['provider'],'gmail')
        self.assertEqual(result['message_id'],message['Message-ID']);self.assertTrue(self.client.closed)
    def test_review_subject_body_and_password_redaction(self):
        result=self.send(status='REVIEW',summary='Confidential accidental fixture '+PASSWORD)
        message=self.client.messages[0][0]
        self.assertIn('[REVIEW]',message['Subject'])
        body=message.get_body(preferencelist=('plain',)).get_content()
        self.assertIn('نسخة للمراجعة',body);self.assertIn('غير معتمدة',body)
        self.assertNotIn(PASSWORD,body);self.assertTrue(result['accepted'])
    def test_google_grouped_password_is_normalized(self):
        with patch.dict(os.environ,{'SKYSTAR_GMAIL_APP_PASSWORD':'abcd efgh ijkl mnop'}):self.send()
        self.assertEqual(self.client.login_calls[0][1],PASSWORD)
    def test_header_injection_and_multiple_recipients_rejected(self):
        for field,value in [('sender','unit@gmail.com\r\nBcc: other@example.com'),('recipient','unit@gmail.com\nBcc: other@example.com'),
                            ('recipient','first@gmail.com,second@gmail.com'),('sender','Display Name <unit@gmail.com>')]:
            with self.subTest(field=field,value=value):
                cfg={**self.config,field:value}
                with self.assertRaises(ServiceConfigurationError):self.send(config=cfg)
        self.assertEqual(self.factory_calls,[])
    def test_workspace_address_allowed_and_outer_config_supported(self):
        cfg={**self.config,'sender':'account@hotel.example','recipient':'owner@gmail.com'}
        self.assertTrue(gmail_config_status({'email':cfg})['ready'])
        self.send(config={'email':cfg})
        self.assertEqual(self.client.login_calls[0][0],'account@hotel.example')
    def test_wrong_day_status_or_attachment_type_never_connects(self):
        database=self.root/'private.sqlite';database.write_bytes(b'SQLite format 3\x00')
        for values in [{'business_date':'2026-02-30'},{'business_date':'2026-11-01\nInjected'},{'status':'APPROVED\nOTHER'},
                       {'path':database},{'attachments':[database]},{'path':None}]:
            with self.subTest(values=values):
                with self.assertRaises(ServiceConfigurationError):self.send(**values)
        self.assertEqual(self.factory_calls,[])
    def test_attachments_can_be_disabled_and_duplicates_deduplicated(self):
        self.send(attachments=[self.xlsx,self.xlsx])
        self.assertEqual(len(list(self.client.messages[-1][0].iter_attachments())),2)
        self.send(config={**self.config,'attach_excel':False},attachments=[self.xlsx])
        self.assertEqual(len(list(self.client.messages[-1][0].iter_attachments())),1)
    def test_attachment_limit_and_invalid_xlsx_rejected(self):
        oversized=self.root/'oversized.pdf'
        with oversized.open('wb') as f:f.write(b'%PDF-');f.truncate(MAX_TOTAL_ATTACHMENT_BYTES+1)
        with self.assertRaises(ServiceConfigurationError):self.send(path=oversized)
        invalid=self.root/'bad.xlsx';invalid.write_bytes(b'PK\x03\x04 not a workbook')
        with self.assertRaises(ServiceConfigurationError):self.send(attachments=[invalid])
        self.assertEqual(self.factory_calls,[])
    def test_authentication_rejection_is_sanitized_and_no_message_submitted(self):
        self.client.auth_error=smtplib.SMTPAuthenticationError(535,('echo '+PASSWORD).encode())
        with self.assertRaises(ServiceRejected) as result:self.send()
        self.assertNotIn(PASSWORD,str(result.exception));self.assertEqual(result.exception.http_status,535)
        self.assertEqual(self.client.messages,[]);self.assertTrue(self.client.closed)
    def test_connection_failure_is_definitive_and_sanitized(self):
        def failed(*args,**kwargs):raise TimeoutError('echo '+PASSWORD)
        with self.assertRaises(ServiceError) as result:self.send(smtp_factory=failed)
        self.assertNotIsInstance(result.exception,DeliveryUncertain);self.assertNotIn(PASSWORD,str(result.exception))
    def test_recipient_and_data_rejection_are_definitive(self):
        for error in [smtplib.SMTPRecipientsRefused({self.config['recipient']:(550,b'rejected')}),
                      smtplib.SMTPSenderRefused(550,b'rejected',self.config['sender']),smtplib.SMTPDataError(552,b'rejected')]:
            with self.subTest(error=type(error).__name__):
                self.client.send_error=error
                with self.assertRaises(ServiceRejected):self.send()
    def test_uncertain_message_timeout_or_malformed_acceptance_is_not_success(self):
        for error in [TimeoutError('echo '+PASSWORD),smtplib.SMTPServerDisconnected('echo '+PASSWORD)]:
            with self.subTest(error=type(error).__name__):
                self.client.send_error=error
                with self.assertRaises(DeliveryUncertain) as result:self.send()
                self.assertNotIn(PASSWORD,str(result.exception))
        self.client.send_error=None;self.client.refused=None
        with self.assertRaises(DeliveryUncertain):self.send()
    def test_successful_acceptance_survives_quit_failure(self):
        self.client.quit_error=smtplib.SMTPServerDisconnected('after DATA acceptance')
        self.assertTrue(self.send()['accepted']);self.assertEqual(self.client.quit_calls,1);self.assertTrue(self.client.closed)
    def test_vault_fallback_and_environment_priority(self):
        self.vault_loader=lambda sender:'vaultpasswordvalue'
        with patch.dict(os.environ,{'SKYSTAR_GMAIL_APP_PASSWORD':''}):
            self.assertTrue(gmail_config_status(self.config)['ready']);self.send()
            self.assertEqual(self.client.login_calls[-1][1],'vaultpasswordvalue')
        self.send();self.assertEqual(self.client.login_calls[-1][1],PASSWORD)
    def test_windows_credential_source_overrides_environment_without_fallback(self):
        cfg={**self.config,'credential_source':'windows'}
        self.vault_loader=lambda sender:'vaultpasswordvalue'
        self.send(config=cfg);self.assertEqual(self.client.login_calls[-1][1],'vaultpasswordvalue')
        self.vault_loader=lambda sender:None
        self.assertFalse(gmail_config_status(cfg)['ready'])
        with self.assertRaises(ServiceConfigurationError):self.send(config=cfg)
    def test_invalid_options_are_configuration_errors(self):
        for patch_values in [{'credential_source':'file'},{'attach_excel':'yes'},{'recipient':'nobody@localhost'}]:
            with self.subTest(values=patch_values):
                with self.assertRaises(ServiceConfigurationError):self.send(config={**self.config,**patch_values})
        self.assertEqual(self.factory_calls,[])

if __name__=='__main__':unittest.main()
