"""Real raw input automation with isolated databases; no provider network calls."""
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from automation_worker import init_config,load_config,run_once
from engine import Store
from test_daily_sales_workflow import DAY,synthetic_reports,write_xlsx


class AutomationWorker(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.config_path=self.root/'config.json'
        self.config=init_config(self.config_path,{'database':str(self.root/'production.sqlite'),'stable_seconds':0})
    def tearDown(self):self.tmp.cleanup()
    def setting(self,**changes):
        raw=json.loads(self.config_path.read_text());raw.update(changes)
        self.config_path.write_text(json.dumps(raw));self.config=load_config(self.config_path)
    def folder(self,day=DAY,omit=(),undated=False,night=True,certify=False):
        folder=Path(self.config['inbox'])/day;folder.mkdir(parents=True,exist_ok=True)
        data=synthetic_reports(day)
        for name,rows in data.items():
            if name in omit:continue
            if undated and name=='Night_Report':rows={r:v for r,v in rows.items() if r!=0}
            write_xlsx(folder/(name+'.xlsx'),name,rows)
        (folder/'READY.json').write_text(json.dumps({'business_date':day,'night_run_confirmed':night,'undated_night_date_confirmed':certify}))
        return folder
    def run_worker(self,**kwargs):
        return run_once(self.config_path,ai_summarizer=lambda facts,config:{'text':'Local test summary','mode':'local'},**kwargs)
    def test_config_init_never_overwrites_existing(self):
        before=self.config_path.read_bytes()
        init_config(self.config_path,{'database':'DO NOT REPLACE'})
        self.assertEqual(self.config_path.read_bytes(),before)
    def test_review_default_imports_raw_files_without_approving(self):
        self.folder();result=self.run_worker()[0]
        self.assertEqual(result['status'],'REVIEW')
        self.assertEqual(result['facts']['metrics']['revenue'],1275)
        self.assertTrue(Path(result['files']['review_pdf']).is_file())
        self.assertIn('ملخص محلي تلقائي',Path(result['files']['summary']).read_text())
        self.assertNotIn('excel',result['files'])
        with StoreContext(self.config['database']) as store:
            self.assertEqual(len(store.day(DAY)),16);self.assertEqual(store.status(DAY),'Pending Review')
    def test_auto_clean_requires_confirmed_night_run_and_produces_final_outputs(self):
        self.setting(approval_mode='auto_when_clean');self.folder(night=False)
        first=self.run_worker()[0];self.assertEqual(first['status'],'REVIEW')
        self.folder(night=True)
        result=self.run_worker()[0];self.assertEqual(result['status'],'FINAL')
        self.assertTrue(Path(result['files']['pdf']).read_bytes().startswith(b'%PDF-'))
        with zipfile.ZipFile(result['files']['excel']) as z:self.assertIsNone(z.testzip())
        with StoreContext(self.config['database']) as store:self.assertEqual(store.status(DAY),'Closed')
    def test_missing_source_stays_review_and_lists_all_missing(self):
        self.setting(approval_mode='auto_when_clean');self.folder(omit=('F____B_Report','Daily_Sales'))
        result=self.run_worker()[0]
        self.assertEqual(result['status'],'REVIEW')
        missing=[i['message'] for i in result['issues'] if i['code']=='MISSING_REPORT']
        self.assertTrue(any('F&B Report' in s for s in missing));self.assertTrue(any('Daily Sales' in s for s in missing))
    def test_all_or_nothing_wrong_day(self):
        folder=self.folder();write_xlsx(folder/'Daily_Sales.xlsx','Daily_Sales',synthetic_reports('2026-11-02')['Daily_Sales'])
        result=self.run_worker()[0];self.assertEqual(result['status'],'REVIEW')
        self.assertIn('IMPORT_REJECTED',[i['code'] for i in result['issues']])
        with StoreContext(self.config['database']) as store:self.assertEqual(store.day(DAY),{})
    def test_undated_night_requires_explicit_date_certification(self):
        self.folder(undated=True)
        first=self.run_worker()[0]
        self.assertIn('IMPORT_REJECTED',[i['code'] for i in first['issues']])
        self.folder(undated=True,certify=True)
        second=self.run_worker()[0]
        self.assertNotIn('IMPORT_REJECTED',[i['code'] for i in second['issues']])
        with StoreContext(self.config['database']) as store:self.assertEqual(len(store.day(DAY)),16)
    def test_date_certification_never_applies_to_other_report_kinds(self):
        folder=self.folder(certify=True)
        rows=synthetic_reports()['Daily_Sales'];rows.pop(0)
        write_xlsx(folder/'Daily_Sales.xlsx','Daily_Sales',rows)
        result=self.run_worker()[0]
        self.assertIn('IMPORT_REJECTED',[i['code'] for i in result['issues']])
        with StoreContext(self.config['database']) as store:self.assertEqual(store.day(DAY),{})
    def test_closed_day_changes_require_review_preserving_sources(self):
        self.setting(approval_mode='auto_when_clean');folder=self.folder();self.run_worker()
        with StoreContext(self.config['database']) as store:before=store.day(DAY)
        changed=synthetic_reports()['Daily_Sales'];changed[4][1]=5000
        write_xlsx(folder/'Daily_Sales.xlsx','Daily_Sales',changed)
        result=self.run_worker()[0]
        self.assertEqual(result['status'],'REVIEW');self.assertIn('CLOSED_SOURCE_CHANGE',[i['code'] for i in result['issues']])
        with StoreContext(self.config['database']) as store:self.assertEqual(store.day(DAY),before)
    def test_stability_and_ready_marker_required(self):
        folder=self.folder();(folder/'READY.json').unlink()
        self.assertEqual(self.run_worker(),[])
        self.folder();self.setting(stable_seconds=3600)
        self.assertEqual(self.run_worker()[0]['status'],'WAITING')
        with StoreContext(self.config['database']) as store:self.assertEqual(store.day(DAY),{})
    def test_delivery_is_explicit_and_idempotent(self):
        self.setting(whatsapp={'enabled':True});self.folder();calls=[]
        def send(*args):calls.append(args);return {'message_id':'test-confirmed-id'}
        first=self.run_worker(transport=send)
        self.assertEqual(calls,[])
        second=self.run_worker(send=True,transport=send)[0]
        self.assertEqual(second['delivery_status'],'sent')
        self.assertEqual(self.run_worker(send=True,transport=send)[0]['delivery_status'],'sent')
        self.assertEqual(len(calls),1)
        self.assertEqual(first[0]['job_key'],second['job_key'])
    def test_ambiguous_delivery_is_not_retried(self):
        self.setting(whatsapp={'enabled':True});self.folder();calls=[]
        def send(*args):calls.append(args);raise TimeoutError('provider might have accepted')
        self.assertEqual(self.run_worker(send=True,transport=send)[0]['delivery_status'],'uncertain')
        self.assertEqual(self.run_worker(send=True,transport=send)[0]['delivery_status'],'uncertain')
        self.assertEqual(len(calls),1)
    def test_disabled_whatsapp_keeps_outputs_awaiting_configuration(self):
        self.folder();result=self.run_worker(send=True)[0]
        self.assertEqual(result['delivery_status'],'awaiting_configuration')
        self.assertTrue(Path(result['files']['review_pdf']).is_file())
    def test_reconfirming_ready_timestamp_does_not_resend(self):
        self.setting(whatsapp={'enabled':True});folder=self.folder();calls=[]
        def send(*args):calls.append(args);return {'message_id':'confirmed-id'}
        first=self.run_worker(send=True,transport=send)[0]
        marker=folder/'READY.json';data=json.loads(marker.read_text());data['confirmed_at']='2099-01-01T00:00:00'
        marker.write_text(json.dumps(data))
        second=self.run_worker(send=True,transport=send)[0]
        self.assertEqual(first['job_key'],second['job_key']);self.assertEqual(len(calls),1)
    def test_interrupted_send_is_persistently_uncertain(self):
        self.setting(whatsapp={'enabled':True});self.folder();result=self.run_worker()[0]
        with sqlite3.connect(self.config['state']) as state:
            state.execute("UPDATE deliveries SET delivery_status='sending' WHERE job_key=? AND channel='whatsapp'",(result['job_key'],))
        calls=[]
        result=self.run_worker(send=True,transport=lambda *args:calls.append(args))[0]
        self.assertEqual(result['delivery_status'],'uncertain');self.assertEqual(calls,[])
        with sqlite3.connect(self.config['state']) as state:
            self.assertEqual(state.execute('SELECT delivery_status FROM jobs WHERE job_key=?',(result['job_key'],)).fetchone()[0],'uncertain')
    def test_pdf_capacity_fallback_is_sent_as_review_not_final(self):
        self.setting(approval_mode='auto_when_clean',whatsapp={'enabled':True});self.folder();calls=[]
        def send(*args):calls.append(args);return {'message_id':'confirmed-id'}
        with patch('release_gate.company_mix',return_value={'rows':[{}]*16}):
            result=self.run_worker(send=True,transport=send)[0]
        self.assertEqual(result['status'],'REVIEW')
        self.assertIn('excel',result['files']);self.assertIn('review_pdf',result['files']);self.assertNotIn('pdf',result['files'])
        self.assertEqual(result['facts']['status'],'REVIEW')
        self.assertEqual(calls[0][2],'REVIEW');self.assertIn('Review',calls[0][0].name)
    def test_warning_day_is_not_automatically_signed_off(self):
        self.setting(approval_mode='auto_when_clean');folder=self.folder()
        night=synthetic_reports()['Night_Report'];night[4][1]=9
        write_xlsx(folder/'Night_Report.xlsx','Night_Report',night)
        result=self.run_worker()[0];self.assertEqual(result['status'],'REVIEW')
        with StoreContext(self.config['database']) as store:
            self.assertNotEqual(store.status(DAY),'Closed');self.assertEqual(store.notes(DAY)[1],'')
    def test_invalid_ready_day_never_imports(self):
        folder=self.folder();(folder/'READY.json').write_text(json.dumps({'business_date':'2026-11-02','night_run_confirmed':True,'undated_night_date_confirmed':False}))
        result=self.run_worker()[0]
        self.assertIn('READY_INVALID',[i['code'] for i in result['issues']])
        with StoreContext(self.config['database']) as store:self.assertEqual(store.day(DAY),{})
    def test_renaming_or_adding_redundant_zip_does_not_resend(self):
        self.setting(whatsapp={'enabled':True});folder=self.folder();calls=[]
        def send(*args):calls.append(args);return {'message_id':'confirmed-id'}
        first=self.run_worker(send=True,transport=send)[0]
        (folder/'Daily_Sales.xlsx').rename(folder/'Renamed.xlsx')
        second=self.run_worker(send=True,transport=send)[0]
        self.assertEqual(first['job_key'],second['job_key'])
        with zipfile.ZipFile(folder/'duplicate.zip','w',zipfile.ZIP_DEFLATED) as z:
            for p in folder.glob('*.xlsx'):z.write(p,p.name)
        third=self.run_worker(send=True,transport=send)[0]
        self.assertEqual(first['job_key'],third['job_key']);self.assertEqual(len(calls),1)
    def test_awaiting_configuration_is_persisted(self):
        self.folder();result=self.run_worker(send=True)[0]
        disk=json.loads(Path(result['files']['json']).read_text())
        self.assertEqual(disk['delivery_status'],'awaiting_configuration')
        with sqlite3.connect(self.config['state']) as state:
            self.assertEqual(state.execute('SELECT delivery_status FROM jobs WHERE job_key=?',(result['job_key'],)).fetchone()[0],'awaiting_configuration')
    def test_changed_delivery_configuration_resets_definitive_failure_budget(self):
        from automation_services import ServiceRejected
        self.setting(whatsapp={'enabled':True,'recipient':'111'});self.folder();calls=[]
        def rejected(*args):calls.append(args);raise ServiceRejected('Request rejected')
        first=self.run_worker(send=True,transport=rejected)[0]
        with sqlite3.connect(self.config['state']) as state:
            state.execute("UPDATE deliveries SET attempts=3,next_retry=0 WHERE job_key=? AND channel='whatsapp'",(first['job_key'],))
        self.assertEqual(self.run_worker(send=True,transport=rejected)[0]['delivery_status'],'failed')
        self.setting(whatsapp={'enabled':True,'recipient':'222'})
        second=self.run_worker(send=True,transport=lambda *args:{'message_id':'retry-confirmed'})[0]
        self.assertEqual(first['job_key'],second['job_key']);self.assertEqual(second['delivery_status'],'sent')
    def test_fresh_marker_does_not_delay_already_stable_exports(self):
        folder=self.folder();self.setting(stable_seconds=60)
        import time
        old=time.time()-120
        for p in folder.glob('*.xlsx'):os.utime(p,(old,old))
        self.assertEqual(self.run_worker()[0]['status'],'REVIEW')
    def test_mutating_file_during_parse_never_saves_batch(self):
        folder=self.folder()
        import automation_worker
        original=automation_worker._read_reports
        def change(*args):
            result=original(*args)
            (folder/'Daily_Sales.xlsx').write_bytes(b'changed while validating')
            return result
        with patch('automation_worker._read_reports',side_effect=change):
            result=self.run_worker()[0]
        self.assertEqual(result['status'],'WAITING')
        with StoreContext(self.config['database']) as store:self.assertEqual(store.day(DAY),{})
    def test_unconfirmed_new_batch_never_labels_saved_closed_data_final(self):
        self.setting(approval_mode='auto_when_clean');self.folder()
        self.assertEqual(self.run_worker()[0]['status'],'FINAL')
        self.folder(night=False)
        result=self.run_worker()[0]
        self.assertEqual(result['status'],'REVIEW');self.assertGreater(result['facts']['blocker_count'],0)
        with StoreContext(self.config['database']) as store:self.assertEqual(store.status(DAY),'Closed')
    def test_ai_facts_have_no_messages_payload_or_private_note(self):
        self.folder(omit=('F____B_Report',));self.run_worker()
        with StoreContext(self.config['database']) as store:
            store.set_report_unavailable(DAY,'F&B Report','TOP SECRET REVIEWER REASON ONLY')
            store.save_notes(DAY,auditor_note='PRIVATE HUMAN SIGNOFF NOTE')
        captured=[]
        result=run_once(self.config_path,ai_summarizer=lambda facts,cfg:captured.append(facts) or {'text':'Test summary','mode':'local'})[0]
        serialized=json.dumps(captured)
        self.assertNotIn('TOP SECRET',serialized);self.assertNotIn('PRIVATE HUMAN',serialized)
        self.assertNotIn('message',serialized);self.assertNotIn('Synthetic QA',serialized)
        self.assertEqual(captured[0]['metrics']['revenue'],1275)


class StoreContext:
    def __init__(self,path):self.path=path
    def __enter__(self):self.store=Store(self.path);return self.store
    def __exit__(self,*args):self.store.close()

if __name__=='__main__':unittest.main()
