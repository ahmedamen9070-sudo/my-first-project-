"""Local Gmail setup flow: no credentials persisted as plaintext or emails sent."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))

@unittest.skipUnless(os.environ.get('DISPLAY') or os.name=='nt','A Tk display is required')
class GmailSettingsUi(unittest.TestCase):
    def setUp(self):
        from app import App
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.app=App(self.root/'demo.sqlite',demo=True);self.app.withdraw();self.app.show('Automation');self.app.update()
        self.app.automation_ui['initialize']();self.path=self.app.automation_ui['config_path']
        self.app.automation_ui['open_gmail_settings']();self.app.update();self.hooks=self.app.gmail_settings_ui
    def tearDown(self):self.app.quit_app();self.tmp.cleanup()
    def fields(self):
        self.hooks['sender'].set('sender@gmail.com');self.hooks['recipient'].set('recipient@gmail.com')
    def test_password_is_never_prefilled_and_save_controls_fit(self):
        self.assertEqual(self.hooks['password'].get(),'')
        dialog=self.hooks['dialog'];self.app.deiconify();dialog.deiconify();self.app.update()
        self.assertGreaterEqual(dialog.winfo_height(),dialog.winfo_reqheight())
        self.assertTrue(self.hooks['enabled'].get())
    def test_save_gmail_without_password_never_sends(self):
        self.fields()
        with patch('gmail_service.send_gmail_report') as send:
            self.hooks['save']();send.assert_not_called()
        cfg=json.loads(self.path.read_text())
        self.assertEqual(cfg['delivery_channel'],'email');self.assertTrue(cfg['email']['enabled'])
        self.assertEqual(cfg['email']['recipient'],'recipient@gmail.com')
        self.assertNotIn('password',cfg['email'])
    def test_password_saved_only_to_local_vault_and_cleared_from_ui(self):
        self.fields();secret='unit-test-local-secret-only';self.hooks['password'].set(secret)
        with patch('local_credentials.save_gmail_password') as store:
            self.hooks['save']();store.assert_called_once_with('sender@gmail.com',secret)
        raw=self.path.read_text();self.assertNotIn(secret,raw)
        cfg=json.loads(raw)
        self.assertEqual(cfg['email']['credential_source'],'windows')
        self.assertTrue(cfg['email']['credential_revision'])
        self.assertEqual(self.hooks['password'].get(),'')
    def test_invalid_recipient_cannot_save_or_store_secret(self):
        self.fields();self.hooks['recipient'].set('recipient@gmail.com\nBcc: somebody@example.com')
        self.hooks['password'].set('unit-test-placeholder')
        before=self.path.read_bytes()
        with patch('automation_ui.messagebox.showerror') as error,patch('local_credentials.save_gmail_password') as store:
            self.hooks['save']();error.assert_called_once();store.assert_not_called()
        self.assertEqual(self.path.read_bytes(),before)
    def test_vault_failure_keeps_existing_setup(self):
        self.fields();self.hooks['password'].set('unit-test-placeholder');before=self.path.read_bytes()
        with patch('local_credentials.save_gmail_password',side_effect=RuntimeError('Storage unavailable')),patch('automation_ui.messagebox.showerror') as error:
            self.hooks['save']();error.assert_called_once()
        self.assertEqual(self.path.read_bytes(),before)

if __name__=='__main__':unittest.main()
