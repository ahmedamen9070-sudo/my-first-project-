"""Selectable Gmail delivery and per-channel deduplication; no real providers."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from automation_worker import init_config,load_config,run_once
from automation_windows import mark_ready
from automation_services import ServiceRejected
from test_daily_sales_workflow import DAY,make_bundle


class EmailDelivery(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.path=self.root/'config.json'
        self.cfg=init_config(self.path,{'database':str(self.root/'test.sqlite'),
                            'approval_mode':'auto_when_clean','stable_seconds':0})
        self.email={'enabled':True,'sender':'sender@example.com','recipient':'owner@example.com','attach_excel':True}
        folder=Path(self.cfg['inbox'])/DAY;make_bundle(folder)
        for p in folder.glob('*.xlsx'):p.unlink()
        mark_ready(self.path,DAY,night_confirmed=True,undated_confirmed=True)
    def tearDown(self):self.tmp.cleanup()
    def setting(self,**changes):
        raw=json.loads(self.path.read_text());raw.update(changes)
        self.path.write_text(json.dumps(raw));self.cfg=load_config(self.path)
    def run_worker(self,**kwargs):
        return run_once(self.path,ai_summarizer=lambda *_:{'mode':'local','text':'Local test summary'},**kwargs)[0]
    def test_new_defaults_keep_legacy_channel_and_disable_email(self):
        self.assertEqual(self.cfg['delivery_channel'],'whatsapp')
        self.assertFalse(self.cfg['email']['enabled'])
        self.assertEqual(self.cfg['email']['sender'],'')
    def test_unknown_channel_is_rejected_without_silent_fallback(self):
        self.setting(delivery_channel='email')
        raw=json.loads(self.path.read_text());raw['delivery_channel']='unknown';self.path.write_text(json.dumps(raw))
        with self.assertRaises(ValueError):load_config(self.path)
    def test_disabled_email_status_is_durable_and_no_message_claimed(self):
        self.setting(delivery_channel='email')
        result=self.run_worker(send=True)
        self.assertEqual(result['delivery_status'],'awaiting_configuration')
        self.assertEqual(result['delivery_channel'],'email')
        self.assertNotIn('message_id',result)
        saved=json.loads(Path(result['files']['json']).read_text())
        self.assertEqual(saved['delivery_channel'],'email')
        self.assertEqual(saved['delivery_status'],'awaiting_configuration')
        with sqlite3.connect(self.cfg['state']) as db:
            self.assertEqual(db.execute('SELECT channel,delivery_status FROM deliveries').fetchall(),[('email','awaiting_configuration')])
    def test_switching_channel_sends_once_each_and_back_does_not_resend(self):
        self.setting(whatsapp={'enabled':True},email=self.email,delivery_channel='whatsapp')
        calls=[]
        def wa(*args):calls.append('wa');return {'message_id':'wa-confirmed'}
        first=self.run_worker(send=True,transport=wa)
        self.setting(delivery_channel='email')
        def mail(*args):calls.append('email');return {'message_id':'<email-confirmed@example.com>'}
        second=self.run_worker(send=True,transport=mail)
        self.assertEqual(first['job_key'],second['job_key'])
        self.assertEqual(second['message_id'],'<email-confirmed@example.com>')
        self.assertEqual(second['deliveries']['whatsapp']['status'],'sent')
        self.assertEqual(second['deliveries']['email']['status'],'sent')
        self.assertEqual(self.run_worker(send=True,transport=mail)['message_id'],second['message_id'])
        self.setting(delivery_channel='whatsapp')
        self.assertEqual(self.run_worker(send=True,transport=wa)['message_id'],'wa-confirmed')
        self.assertEqual(calls,['wa','email'])
    def test_email_uncertain_is_never_retried_after_config_change(self):
        self.setting(delivery_channel='email',email=self.email)
        calls=[]
        def timeout(*args):calls.append(args);raise TimeoutError('accepted or not unknown')
        first=self.run_worker(send=True,transport=timeout)
        self.assertEqual(first['delivery_status'],'uncertain')
        self.setting(email={**self.email,'recipient':'corrected@example.com','credential_revision':'new'})
        second=self.run_worker(send=True,transport=timeout)
        self.assertEqual(second['delivery_status'],'uncertain');self.assertEqual(len(calls),1)
        self.assertEqual(first['job_key'],second['job_key'])
    def test_email_failure_budget_resets_only_after_configuration_change(self):
        self.setting(delivery_channel='email',email=self.email)
        def reject(*args):raise ServiceRejected('rejected')
        first=self.run_worker(send=True,transport=reject)
        with sqlite3.connect(self.cfg['state']) as db:
            db.execute("UPDATE deliveries SET attempts=3,next_retry=0 WHERE channel='email'")
        self.assertEqual(self.run_worker(send=True,transport=reject)['delivery_status'],'failed')
        self.setting(email={**self.email,'credential_revision':'updated-local-password'})
        second=self.run_worker(send=True,transport=lambda *_:{'message_id':'<retry-confirmed@example.com>'})
        self.assertEqual(second['delivery_status'],'sent')
        self.assertEqual(first['job_key'],second['job_key'])
    def test_live_adapter_receives_only_generated_pdf_and_optional_excel(self):
        self.setting(delivery_channel='email',email=self.email)
        with patch('gmail_service.gmail_config_status',return_value={'ready':True,'missing':[]}),\
             patch('gmail_service.send_gmail_report',return_value={'message_id':'<accepted@example.com>'}) as sender:
            result=self.run_worker(send=True)
        self.assertEqual(result['delivery_status'],'sent')
        args,kwargs=sender.call_args
        self.assertEqual(args[0],Path(result['files']['pdf']))
        self.assertEqual(args[1:3],(DAY,'FINAL'))
        self.assertEqual(kwargs['attachments'],[Path(result['files']['excel'])])
        self.assertFalse(any(p.suffix in ('.sqlite','.db') for p in kwargs['attachments']))
    def test_review_email_is_labelled_review_without_stale_excel(self):
        self.setting(delivery_channel='email',email=self.email,approval_mode='review')
        with patch('gmail_service.gmail_config_status',return_value={'ready':True,'missing':[]}),\
             patch('gmail_service.send_gmail_report',return_value={'message_id':'<review@example.com>'}) as sender:
            result=self.run_worker(send=True)
        args,kwargs=sender.call_args
        self.assertEqual(result['status'],'REVIEW');self.assertEqual(args[2],'REVIEW')
        self.assertIn('Review',args[0].name);self.assertIsNone(kwargs['attachments'])
    def test_excel_can_be_disabled(self):
        self.setting(delivery_channel='email',email={**self.email,'attach_excel':False})
        with patch('gmail_service.gmail_config_status',return_value={'ready':True,'missing':[]}),\
             patch('gmail_service.send_gmail_report',return_value={'message_id':'<pdf-only@example.com>'}) as sender:
            self.run_worker(send=True)
        self.assertIsNone(sender.call_args.kwargs['attachments'])
    def test_raw_folder_to_gmail_mime_with_fake_smtp_only(self):
        self.setting(delivery_channel='email',email=self.email)
        captured=[];constructed=[]
        class FakeSmtp:
            def __init__(self,host,port,timeout,context):
                constructed.append((host,port,context.check_hostname,context.verify_mode))
            def login(self,sender,password):
                self.sender=sender
            def send_message(self,message,from_addr,to_addrs):
                captured.append((message,from_addr,to_addrs));return {}
            def quit(self):pass
            def close(self):pass
        with patch.dict('os.environ',{'SKYSTAR_GMAIL_APP_PASSWORD':'unit-test-placeholder-only'}),\
             patch('gmail_service.smtplib.SMTP_SSL',FakeSmtp):
            first=self.run_worker(send=True)
            second=self.run_worker(send=True)
        self.assertEqual(first['delivery_status'],'sent')
        self.assertEqual(first['message_id'],second['message_id'])
        self.assertEqual(len(captured),1);self.assertEqual(len(constructed),1)
        self.assertEqual(constructed[0][:3],('smtp.gmail.com',465,True))
        message,from_addr,recipients=captured[0]
        self.assertEqual(from_addr,self.email['sender']);self.assertEqual(recipients,[self.email['recipient']])
        self.assertIn('[FINAL]',message['Subject']);self.assertIn(DAY,message['Subject'])
        self.assertEqual({p.get_content_subtype() for p in message.iter_attachments()},
                         {'pdf','vnd.openxmlformats-officedocument.spreadsheetml.sheet'})
        self.assertNotIn('unit-test-placeholder',message.as_string())

    def test_legacy_whatsapp_sent_record_migrates_once_and_does_not_block_email(self):
        self.setting(whatsapp={'enabled':True},email=self.email)
        result=self.run_worker()
        # Simulate an on-disk queue written before per-channel email support.
        with sqlite3.connect(self.cfg['state']) as db:
            db.execute('DROP TABLE deliveries')
            db.execute("UPDATE jobs SET delivery_status='sent',message_id='legacy-wa-confirmed' WHERE job_key=?",(result['job_key'],))
        calls=[]
        recovered=self.run_worker(send=True,transport=lambda *_:calls.append('unexpected'))
        self.assertEqual(recovered['message_id'],'legacy-wa-confirmed');self.assertEqual(calls,[])
        self.setting(delivery_channel='email')
        email=self.run_worker(send=True,transport=lambda *_:calls.append('email') or {'message_id':'<new-email@example.com>'})
        self.assertEqual(email['delivery_status'],'sent')
        self.setting(delivery_channel='whatsapp')
        self.assertEqual(self.run_worker(send=True,transport=lambda *_:calls.append('bad'))['message_id'],'legacy-wa-confirmed')
        self.assertEqual(calls,['email'])
    def test_legacy_interrupted_whatsapp_does_not_retry_while_email_can_send(self):
        self.setting(whatsapp={'enabled':True},email=self.email)
        result=self.run_worker()
        with sqlite3.connect(self.cfg['state']) as db:
            db.execute('DROP TABLE deliveries')
            db.execute("UPDATE jobs SET delivery_status='sending' WHERE job_key=?",(result['job_key'],))
        calls=[]
        result=self.run_worker(send=True,transport=lambda *_:calls.append('bad'))
        self.assertEqual(result['delivery_status'],'uncertain');self.assertEqual(calls,[])
        self.setting(delivery_channel='email')
        result=self.run_worker(send=True,transport=lambda *_:calls.append('email') or {'message_id':'<email@example.com>'})
        self.assertEqual(result['delivery_status'],'sent');self.assertEqual(calls,['email'])

if __name__=='__main__':unittest.main()
