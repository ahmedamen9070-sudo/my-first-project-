"""Month-to-date across *approved closed* business dates only.

Cumulative revenue/settlements are SUMs. Room occupancy and ADR are ratios of
cumulative room-nights/revenue; ledger and physical capacity are snapshots.
Meal plan counts are daily entitlements summed as room-nights / person-nights,
not unique guests and not actual meals consumed.
"""
from collections import defaultdict
from datetime import timedelta
from engine import metrics,normal_date,normalize_meal_pattern,money

D_KEYS=('rooms','food','beverage','other','revenue','adjustment','transportation','net_revenue',
        'taxes','cash','card','city_ledger','total_settlements','grand_total')
ROOM_KEYS=('ooo_in_rooms','available_for_sale','revenue_occupied','vacant','comp','house_use')
CO_KEYS=('rooms','single','double','triple','quad','other_type','suite','room_revenue','fnb_revenue','other_revenue','total_revenue')

def values_for_fnb(fb):
    out=defaultdict(lambda:{'rooms':0,'pax':0})
    for raw,n in fb.get('patterns',{}).items():
        code=normalize_meal_pattern(raw)
        out[code]['rooms']+=int(n)
        out[code]['pax']+=int(fb.get('adults',{}).get(raw,0))+int(fb.get('children',{}).get(raw,0))
    return dict(out)

def detail(store,d):
    dt=normal_date(d); cursor=store.reporting_start(d);expected=(dt-cursor).days+1
    days=[(cursor+timedelta(days=i)).isoformat() for i in range(expected)]
    closed=[day for day in days if store.status(day)=='Closed']
    by_kind={k:[] for k in ('Department Summary','Rooms Situation','F&B Report','Company Revenue','Cashier Summary','Guest In House')}
    for day in closed:
        data=store.day(day)
        for kind in by_kind:
            if kind in data:by_kind[kind].append((day,data))
    result={'expected':expected,'closed_days':len(closed),'all_dates':days,'closed_dates':closed,
            'missing_dates':[day for day in days if day not in closed],
            'coverage':{k:len(v) for k,v in by_kind.items()},
            'coverage_complete':{k:len(v)==expected for k,v in by_kind.items()}}
    fin=defaultdict(float)
    for _,s in by_kind['Department Summary']:
        m=metrics(s)
        for key in D_KEYS:fin[key]+=m.get(key,0) or 0
    result['financial']={key:money(fin.get(key,0)) for key in D_KEYS}
    codes=defaultdict(float)
    for _,s in by_kind['Department Summary']:
        for entry in s['Department Summary'].get('codes',[]):
            codes[int(entry['code'])]+=entry.get('today',0) or 0
    result['department_codes']={k:money(v) for k,v in codes.items()}
    room=defaultdict(float);last_physical=None;last_ledger=None
    matched_room_revenue=0
    for day,s in by_kind['Rooms Situation']:
        m=metrics(s)
        for key in ROOM_KEYS:room[key]+=m.get(key,0) or 0
        last_physical=m.get('physical_count')
        if 'Department Summary' in s:matched_room_revenue+=m.get('rooms',0) or 0
    room['occupancy']=round(100*room['revenue_occupied']/room['available_for_sale'],2) if room['available_for_sale'] else None
    room['adr']=round(matched_room_revenue/room['revenue_occupied'],2) if room['revenue_occupied'] and len(by_kind['Rooms Situation'])==len([1 for day,s in by_kind['Department Summary'] if 'Rooms Situation' in s]) else None
    room['revpar']=round(matched_room_revenue/room['available_for_sale'],2) if room['available_for_sale'] and len(by_kind['Rooms Situation'])==len([1 for day,s in by_kind['Department Summary'] if 'Rooms Situation' in s]) else None
    room['physical_count']=last_physical
    result['rooms']={k:round(v,2) if isinstance(v,float) else v for k,v in room.items()}
    for _,s in by_kind['Department Summary']:
        ledger=s['Department Summary'].get('ledger',{})
        if ledger.get('closing_balance') is not None:last_ledger=ledger['closing_balance']
    result['guest_ledger_last_balance']=last_ledger
    company=defaultdict(lambda:defaultdict(float))
    company_pax=defaultdict(lambda:[0,0,0])
    for _,s in by_kind['Company Revenue']:
        for c in s['Company Revenue']['companies']:
            name=c['company']
            portions=str(c.get('pax','0/0/0')).split('/')
            for k in range(3):
                try:company_pax[name][k]+=int(portions[k])
                except (ValueError,IndexError):pass
            for key in CO_KEYS:company[name][key]+=c.get(key,0) or 0
    result['companies']={name:{**{k:money(v) for k,v in vals.items()},
                            'pax':'/'.join(str(x) for x in company_pax[name])} for name,vals in company.items()}
    meal=defaultdict(lambda:defaultdict(int));meal_total=defaultdict(int);services=defaultdict(int)
    for _,s in by_kind['F&B Report']:
        fb=s['F&B Report']
        for code,vals in values_for_fnb(fb).items():
            meal[code]['rooms']+=vals['rooms'];meal[code]['pax']+=vals['pax']
        meal_total['rooms']+=int(fb.get('rooms_listed',0));meal_total['pax']+=int(fb.get('pax',0))
        for code,n in fb.get('services_rooms',{}).items():services[code]+=int(n)
    result['meal_plans']={k:dict(v) for k,v in meal.items()}
    result['meal_total']=dict(meal_total)
    result['meal_services']=dict(services)
    return result
