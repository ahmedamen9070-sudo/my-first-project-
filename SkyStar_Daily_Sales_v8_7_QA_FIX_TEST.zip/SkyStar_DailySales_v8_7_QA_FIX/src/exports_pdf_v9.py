"""Sky Star Daily Sales v8.5: management A4 landscape vector-PDF.

Approved modern visual: KPI strip, three-column report cards, and one-row-per-company
Today | MTD grid. Uses the existing v7.8 audited data engine and source-bound
month-to-date computation; nothing in this module is a hardcoded sales figure.
"""
from __future__ import annotations
from datetime import date as date_class, timedelta
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from engine import metrics
from mtd_detail import detail, values_for_fnb
from company_mix import company_mix
from inhouse_company import complete_guest_payload
from exports_pdf_v7 import pdf_export as fallback_export

W,H=landscape(A4)
NAVY='#0B314A'
DEEP='#082C43'
AQUA='#009A99'  # single approved MTD teal, matches the Companies MTD group
ROW='#F6F9FB'
PAL='#DDF1F1'
GRID='#E2EBEF'
WHITE='#FFFFFF'
INK='#18374E'
GRAY='#667C8F'
BG='#F9FCFD'


def rect(c,x,y,w,h,color):
    c.setFillColor(HexColor(color));c.rect(x,y,w,h,stroke=0,fill=1)

def text(c,x,y,value,size=6.8,bold=False,color=INK,align='left',max_width=None,font=None):
    value=str(value)
    font=font or ('Helvetica-Bold' if bold else 'Helvetica')
    if max_width and stringWidth(value,font,size)>max_width:
        while len(value)>1 and stringWidth(value+'...',font,size)>max_width:
            value=value[:-1]
        value+='...'
    c.setFont(font,size);c.setFillColor(HexColor(color))
    {'left':c.drawString,'right':c.drawRightString,'center':c.drawCentredString}[align](x,y,value)

def fmt(n,kind='cash'):
    if n is None:return '—'
    if kind=='int':return f'{n:,.0f}'
    if kind=='percent':return f'{n:,.2f}%'
    return f'{n:,.2f}'

def card(c,x,bottom,w,top,title):
    # Quiet drop-shadow and fine border; large, centered white heading.
    c.setFillColor(HexColor('#E7EFF2'))
    c.roundRect(x+1,bottom-1.4,w,top-bottom,3.8,fill=1,stroke=0)
    c.setFillColor(HexColor(WHITE))
    c.roundRect(x,bottom,w,top-bottom,3.8,fill=1,stroke=0)
    c.setStrokeColor(HexColor('#CADAE2'));c.setLineWidth(.55)
    c.roundRect(x,bottom,w,top-bottom,3.8,fill=0,stroke=1)
    rect(c,x,top-19,w,19,NAVY)
    text(c,x+w/2,top-12.9,title,size=9.0,bold=True,color=WHITE,align='center')

def colheads(c,x,top,w,lab='Category',lcolor=INK):
    # narrow colored MTD column distinguished from Today (but figures use neutral ink).
    rect(c,x+.7,top-32.0,w-1.4,13,'#E8F1F5')
    text(c,x+7,top-28,lab,6.4,True,lcolor)
    text(c,x+w-76,top-28,'Today',6.6,True,INK,align='right')
    text(c,x+w-7,top-28,'MTD',6.6,True,AQUA,align='right')

def two_row(c,x,y,w,label,a,b,i,kind='cash',emph=False,strong=False,rowheight=10.1,small=6.7):
    if strong:rect(c,x+1.5,y-2.6,w-3,rowheight+1.8,DEEP)
    elif emph:rect(c,x+1.5,y-2.5,w-3,rowheight,PAL)
    elif i%2==0:rect(c,x+1.5,y-2.5,w-3,rowheight,ROW)
    color=WHITE if strong else INK
    text(c,x+9,y,label,size=small,bold=(emph or strong),color=color,max_width=w-101)
    text(c,x+w-76,y,fmt(a,kind),size=small+.05,bold=emph or strong,color=color,align='right')
    text(c,x+w-7,y,fmt(b,kind),size=small+.05,bold=emph or strong,color=color if strong else GRAY,align='right')


def entitled(fb,service):
    if not fb:return None
    rules={'BFST':('BB','HB','FB','AN','HAN'),
           'LNCH':('FB','AN','HAN'),
           'DNNR':('HB','FB','AN','HAN'),
           'ANB':('AN','HAN')}
    meal=values_for_fnb(fb)
    expected=sum(meal.get(p,{}).get('rooms',0) for p in rules[service])
    actual=fb.get('services_rooms',{}).get(service)
    if actual is None or actual!=expected:return None
    return sum(meal.get(p,{}).get('pax',0) for p in rules[service])



def adult_categories(sources):
    """Adult occupancy by certified room status. None means insufficient source coverage.

    Guest In House may explicitly exclude complementary and/or House Use records,
    which must be supplied by those certified reports; never assume missing=zero.
    """
    guest=sources.get('Guest In House')
    if not guest:
        return None
    if guest.get('excludes_complimentary') and 'Complimentary Report' not in sources:
        return None
    if guest.get('excludes_house_use') and 'House Use Report' not in sources:
        return None
    records=complete_guest_payload(sources).get('guests',[])
    return {kind:sum(int(z.get('adults') or 0) for z in records
                     if z.get('kind','paid')==kind) for kind in ('paid','comp','hu')}


def approved_adults_mtd(store,business_date):
    """Sum paid/complimentary/H.U. adult-person-nights for ALL approved dates."""
    first=store.reporting_start(business_date)
    last=date_class.fromisoformat(business_date)
    total={'paid':0,'comp':0,'hu':0}
    for offset in range((last-first).days+1):
        target=(first+timedelta(days=offset)).isoformat()
        if store.status(target)!='Closed':
            return None
        day_data=adult_categories(store.day(target))
        if day_data is None:
            return None
        for kind in total:
            total[kind]+=day_data[kind]
    return total


def draw_icon(c,key,x,y):
    """Small vector pictograms: no external fonts/images needed."""
    c.saveState();c.setLineWidth(1.5)
    c.setStrokeColor(HexColor('#C0DDE9'))
    if key=='coins':
        for dx,dy in ((1,1),(8,7)):
            c.ellipse(x+dx,y+dy+5,x+dx+13,y+dy+11,stroke=1,fill=0)
            c.line(x+dx,y+dy+8,x+dx,y+dy);c.line(x+dx+13,y+dy+8,x+dx+13,y+dy)
            c.arc(x+dx,y+dy-3,x+dx+13,y+dy+3,180,180)
    elif key=='bed':
        c.line(x,y+2,x+25,y+2);c.line(x,y+2,x,y+16);c.line(x+25,y+2,x+25,y+12)
        c.rect(x+2,y+4,21,7,fill=0,stroke=1);c.rect(x+3,y+13,7,6,fill=0,stroke=1)
    elif key=='guests':
        c.circle(x+9,y+15,4.5,stroke=1,fill=0);c.circle(x+21,y+15,4,stroke=1,fill=0)
        c.arc(x,y-6,x+19,y+15,0,180);c.arc(x+13,y-6,x+29,y+14,0,180)
    else:
        c.roundRect(x,y+2,27,17,2,fill=0,stroke=1)
        c.line(x+2,y+13,x+25,y+13);c.rect(x+3,y+5,9,2,stroke=1,fill=0)
    c.restoreState()


def pdf_export(store,date,path,mode='management'):
    if mode!='management':return fallback_export(store,date,path,mode=mode)
    src=store.day(date)
    if not src:raise ValueError('No imported Comsys reports for this business date')
    m=metrics(src);mt=detail(store,date);cov=mt['coverage']
    has_dep='Department Summary' in src
    has_room='Rooms Situation' in src
    has_co='Company Revenue' in src
    has_fb='F&B Report' in src
    has_guest='Guest In House' in src
    full_guest=complete_guest_payload(src) if has_guest else {}
    money_mtd=cov['Department Summary']>0
    rooms_mtd=cov['Rooms Situation']>0
    co_mtd=cov['Company Revenue']>0
    fb_mtd=cov['F&B Report']>0
    inhouse=company_mix(store,date)
    if len(inhouse['rows'])>15:
        raise ValueError('Company rows exceed the approved one-page A4 layout capacity. '
                         'Review company grouping privately before releasing the report; do not clip any rows.')
    md=mt['financial'];rm=mt['rooms']
    today_codes={int(z['code']):float(z['today']) for z in src.get('Department Summary',{}).get('codes',[])}
    month_codes=mt['department_codes']
    def day(code):return today_codes.get(code,0) if has_dep else None
    def mon(code):return month_codes.get(code,0) if money_mtd else None
    def d(key):return m.get(key) if has_dep else None
    def mm(key):return md.get(key) if money_mtd else None
    def rd(key):return m.get(key) if has_room else None
    def rmon(key):return rm.get(key) if rooms_mtd else None
    val=lambda v: v if v is not None else None

    c=canvas.Canvas(str(path),pagesize=(W,H),pageCompression=1)
    c.setTitle('Sky Star Daily Sales | '+date+' | Modern Management Report')
    rect(c,0,0,W,H,BG)
    # Brand: slim light masthead, not a second full-height banner.
    text(c,15,H-23,'Sky Star',19,True,NAVY,font='Times-Bold')
    c.setStrokeColor(HexColor('#A5BBC5'));c.setLineWidth(.85);c.line(110,H-9,110,H-30)
    text(c,121,H-23,'Daily Sales',18,False,NAVY,font='Times-Roman')
    text(c,17,H-34,'H O T E L   &   R E S O R T',5.6,True,GRAY)
    # Review statuses and incomplete-coverage alerts are visible only inside the app.
    text(c,W-17,H-23,'BUSINESS DATE  '+date,7,True,NAVY,align='right')
    c.setStrokeColor(HexColor('#C5D9E1'));c.line(14,H-41,W-14,H-41)
    # KPI strip, four equal cards.
    total_people=None
    if has_guest:
        g=full_guest;total_people=g.get('adults',0)+g.get('children',0) if {'Complimentary Report','House Use Report'}.issubset(src) else None
    elif has_co:
        adults=children=0
        for co in src['Company Revenue'].get('companies',[]):
            try:
                p=[int(float(x)) for x in str(co.get('pax','0/0/0')).split('/')[:2]]
                adults+=p[0];children+=p[1]
            except (ValueError,IndexError):continue
        total_people=adults+children
    kpis=[('TOTAL HOTEL REVENUE',d('revenue'),mm('revenue'),'coins','cash'),
          ('ROOMS OCCUPIED',rd('revenue_occupied'),rmon('revenue_occupied'),'bed','int'),
          ('TOTAL GUESTS',total_people,None,'guests','int'),
          ('TOTAL SETTLEMENTS',d('total_settlements'),mm('total_settlements'),'card','cash')]
    x0=13;kw=(W-26)/4;ky=H-99;kh=52
    for i,(name,value,monthly,icon,kind) in enumerate(kpis):
        x=x0+i*kw
        rect(c,x,ky,kw-.8,kh,NAVY if i in (0,3) else '#0B4058')
        draw_icon(c,icon,x+17,ky+14)
        text(c,x+54,ky+36,name,7.0,True,'#D3EDF1')
        result=fmt(value,kind)
        if kind=='cash' and value is not None:result='D '+result
        text(c,x+54,ky+17,result,16.0,True,WHITE,font='Times-Bold')
        if i==1:
            text(c,x+54,ky+6,'OCCUPANCY  '+fmt(rd('occupancy'),'percent'),6.15,True,'#D7E9EF')
        elif i==2:
            breakdown=adult_categories(src)
            people_text=(f'OCC {breakdown["paid"]}   COMP {breakdown["comp"]}   H/U {breakdown["hu"]}   CHILD {full_guest.get("children",0)}') if breakdown else 'GUEST MIX PENDING'
            text(c,x+54,ky+6,people_text,5.55,False,'#D7E9EF')
        else:
            text(c,x+54,ky+6,'MTD',7.0,True,AQUA)
            text(c,x+78,ky+6,fmt(monthly,kind),6.6,False,WHITE)

    # Three-column card grid; all content is vector text and shapes.
    tops=H-107;bodybottom=166
    lx,lw=13,291
    cx,cw=312,211
    rx,rw=531,W-544
    card(c,lx,bodybottom,lw,tops,'REVENUE SUMMARY')
    card(c,cx,bodybottom,cw,tops,'OCCUPANCY DETAILS')
    card(c,rx,361,rw,tops,'MEAL PLAN')
    card(c,rx,277,rw,354,'PAYMENT')
    card(c,rx,bodybottom,rw,270,'PACKAGE AVERAGES')
    colheads(c,lx,tops,lw)
    y=tops-43
    revenue_rows=[
        ('Individual Rate',day(101),mon(101),False,False),
        ('Group Rate',day(102),mon(102),False,False),
        ('TOTAL ROOMS',d('rooms'),mm('rooms'),True,False),
        ('Main Restaurant',day(205),mon(205),False,False),
        ('Breakfast Package',day(250),mon(250),False,False),
        ('Dinner Package',day(251),mon(251),False,False),
        ('Lunch Package',day(252),mon(252),False,False),
        ('TOTAL FOOD',d('food'),mm('food'),True,False),
        ('All Inclusive Beverage',day(253),mon(253),False,False),
        ('Pool Bar Beverage',day(301),mon(301),False,False),
        ('Main Restaurant Beverage',day(305),mon(305),False,False),
        ('TOTAL BEVERAGE',d('beverage'),mm('beverage'),True,False),
        ('Laundry',day(501),mon(501),False,False),
        ('Miscellaneous',day(503),mon(503),False,False),
        ('Tips',day(550),mon(550),False,False),
        ('TOTAL OTHER',d('other'),mm('other'),True,False),
        ('TOTAL HOTEL REVENUE',d('revenue'),mm('revenue'),True,True),
        ('Other Income Adjustment (599)',d('adjustment'),mm('adjustment'),False,False),
        ('Transportation (904)',d('transportation'),mm('transportation'),False,False),
        ('14% Sales Tax',day(702),mon(702),False,False),
        ('12% Service Charge',day(701),mon(701),False,False),
        ('1% Municipality Tax',day(703),mon(703),False,False),
    ]
    # Tax bucket 704/705 is included in the total: never silently hide it if
    # Comsys posts additional charges on a later date.
    if any(abs(z or 0)>0.001 for z in (day(704),day(705),mon(704),mon(705))):
        revenue_rows.append(('Other Taxes / Charges',
                             (day(704)+day(705)) if has_dep else None,
                             (mon(704)+mon(705)) if money_mtd else None,False,False))
    revenue_rows.append(('TOTAL SERVICE + TAXES',d('taxes'),mm('taxes'),True,False))
    for i,(label,a,b,emph,strong) in enumerate(revenue_rows):
        two_row(c,lx,y,lw,label,a,b,i,emph=emph,strong=strong,rowheight=9.7,small=6.45)
        y-=11.65

    # Room statistics / occupancy: include the user-approved Comsys labels.
    colheads(c,cx,tops,cw,lab='Item')
    y=tops-43
    certified_today=inhouse['rows'][-1].get('today') or {}
    certified_mtd=inhouse['rows'][-1].get('mtd') or {}
    buckets=('single','double','triple','quad')
    sums_day={key:certified_today.get(key) for key in buckets}
    sums_m={key:certified_mtd.get(key) for key in buckets}
    b_d=certified_today.get('rooms');b_m=certified_mtd.get('rooms')
    # Above-four-adult occupancy is a private review blocker, not a fabricated room count.
    sums_day.update(other_type=0,suite=0);sums_m.update(other_type=0,suite=0)
    def mix(key,den,num):return num[key]*100/den if den and num.get(key) is not None else None
    categories=adult_categories(src)
    month_categories=approved_adults_mtd(store,date)
    total_children=full_guest.get('children') if categories is not None else None
    month_children=month_infants=None
    if month_categories is not None:
        month_children=month_infants=0
        first=store.reporting_start(date)
        for offset in range((date_class.fromisoformat(date)-first).days+1):
            current=(first+timedelta(days=offset)).isoformat()
            children_data=complete_guest_payload(store.day(current))
            month_children+=children_data['children']
            month_infants+=children_data['infants']
    # Guest In House paid-only people for rates; do not divide room revenue by comp / H/U persons.
    paid_adults=categories['paid'] if categories else None
    mtd_people=month_categories['paid'] if month_categories else None
    occ_rows=[
        ('Physical Rooms',rd('physical_count'),rmon('physical_count'),'int',False),
        ('O.O.O.',rd('ooo_in_rooms'),rmon('ooo_in_rooms'),'int',False),
        ('Rooms Available',rd('available_for_sale'),rmon('available_for_sale'),'int',False),
        ('Rooms Vacant',rd('vacant'),rmon('vacant'),'int',False),
        ('House Use',rd('house_use'),rmon('house_use'),'int',False),
        ('Rooms Comp.',rd('comp'),rmon('comp'),'int',False),
        ('Rooms Occupied',rd('revenue_occupied'),rmon('revenue_occupied'),'int',True),
    ]
    for key,label in (('single','Rooms Single'),('double','Rooms Double'),('triple','Rooms Triple'),('quad','Rooms Quadruple'),('other_type','Rooms Above 4 Pax'),('suite','Suites')):
        occ_rows.append((label,sums_day[key] if has_guest else None,sums_m[key] if inhouse['mtd_complete'] else None,'int',False))
    for key,label in (('single','% Rooms Single'),('double','% Rooms Double'),
                      ('triple','% Rooms Triple'),('quad','% Rooms Quadruple')):
        occ_rows.append((label,mix(key,b_d,sums_day) if has_guest else None,
                         mix(key,b_m,sums_m) if inhouse['mtd_complete'] else None,'percent',False))
    occ_rows.append(('% Occupancy',rd('occupancy'),rmon('occupancy'),'percent',True))
    for label,keys in (('% Occupied + Comp',('revenue_occupied','comp')),
                       ('% Occupied + H/U',('revenue_occupied','house_use')),
                       ('% Occ + Comp + H/U',('revenue_occupied','comp','house_use'))):
        da=sum(rd(key) for key in keys)*100/rd('available_for_sale') if has_room and rd('available_for_sale') else None
        mo=sum(rmon(key) for key in keys)*100/rmon('available_for_sale') if rooms_mtd and rmon('available_for_sale') else None
        occ_rows.append((label,da,mo,'percent',False))
    occ_rows += [
        ('Adult Occupied',categories['paid'] if categories else None,
         month_categories['paid'] if month_categories else None,'int',False),
        ('Adult Comp',categories['comp'] if categories else None,
         month_categories['comp'] if month_categories else None,'int',False),
        ('Adult House Use',categories['hu'] if categories else None,
         month_categories['hu'] if month_categories else None,'int',False),
        ('Children',total_children,month_children,'int',False),
        ('Infants',full_guest.get('infants') if categories is not None else None,month_infants,'int',False),
        ('Avr. Room Rate',rd('adr'),rmon('adr'),'cash',False),
        ('RevPAR',rd('revpar'),rmon('revpar'),'cash',False),
        ('Room Revenue / Adult Pax',d('rooms')/paid_adults if has_dep and paid_adults else None,
         mm('rooms')/mtd_people if money_mtd and month_categories and cov['Department Summary']==mt['expected'] and mtd_people else None,'cash',False),
    ]
    rowstep=9.05
    for i,(label,a,b,kind,emph) in enumerate(occ_rows):
        two_row(c,cx,y,cw,label,a,b,i,kind,emph,rowheight=8.3,small=5.85)
        y-=rowstep

    # Meal Plan: Today's rooms and pax next to each other, then MTD; no Included column.
    heady=tops-31
    rect(c,rx+1,heady-2,rw-2,13,'#E8F1F5')
    mealwidth=[84,52,52,55,rw-243]
    xedges=[rx]
    for width in mealwidth:xedges.append(xedges[-1]+width)
    meal_header=['Plan','Rooms Today','Pax Today','Rooms MTD','Pax MTD']
    for i,lab in enumerate(meal_header):
        xpos=xedges[i]+6 if i==0 else xedges[i+1]-5
        text(c,xpos,heady+2,lab,6.15,True,AQUA if i>=3 else INK,align='left' if i==0 else 'right')
    plans=values_for_fnb(src.get('F&B Report',{})) if has_fb else {}
    mplans=mt['meal_plans']
    py=heady-13
    for i,code in enumerate(('BB','HB','FB','AN','HAN','BED')):
        if i%2==0:rect(c,rx+1,py-2.5,rw-2,11,ROW)
        zv=plans.get(code,{})
        zm=mplans.get(code,{})
        label={'AN':'Soft All Inc','HAN':'Hard All Inc'}.get(code,code)
        dat=[label,fmt(zv.get('rooms',0) if has_fb else None,'int'),fmt(zv.get('pax',0) if has_fb else None,'int'),
             fmt(zm.get('rooms',0) if fb_mtd else None,'int'),fmt(zm.get('pax',0) if fb_mtd else None,'int')]
        for j,value in enumerate(dat):
            text(c,xedges[j]+6 if j==0 else xedges[j+1]-5,py,value,6.6,j==0,INK if j<3 else GRAY,align='left' if j==0 else 'right')
        py-=12.2
    rect(c,rx+1,py-3,rw-2,12.5,PAL)
    totals=['TOTAL MEAL PLANS',
        fmt(sum(v.get('rooms',0) for v in plans.values()) if has_fb else None,'int'),
        fmt(sum(v.get('pax',0) for v in plans.values()) if has_fb else None,'int'),
        fmt(sum(v.get('rooms',0) for v in mplans.values()) if fb_mtd else None,'int'),
        fmt(sum(v.get('pax',0) for v in mplans.values()) if fb_mtd else None,'int')]
    for j,v in enumerate(totals):
        text(c,xedges[j]+6 if j==0 else xedges[j+1]-5,py,v,6.1,True,NAVY,align='left' if j==0 else 'right',max_width=mealwidth[j]-7 if j==0 else None)

    # Collections and city ledger are settlement categories, NOT additional sales.
    colheads(c,rx,354,rw,lab='Type')
    sy=354-41
    for i,(label,key) in enumerate((('Cash','cash'),('Credit Cards','card'),('City Ledger','city_ledger'),('TOTAL SETTLEMENTS','total_settlements'))):
        two_row(c,rx,sy,rw,label,d(key),mm(key),i,emph=i==3,rowheight=9.4,small=6.9)
        sy-=10.7

    # Verified package average: revenue / entitled pax for each same-day service.
    px=[rx+7,rx+140,rx+188,rx+241,rx+rw-6]
    heady=270-32
    rect(c,rx+1,heady-3,rw-2,14,'#E8F1F5')
    for j,(val,at) in enumerate(zip(('Package','Revenue','Avg/Pax','Revenue MTD','Avg/Pax MTD'),px)):
        text(c,at,heady+1,val,5.7,True,AQUA if j>=3 else INK,align='left' if j==0 else 'right')
    start=store.reporting_start(date)
    monthpairs=[]
    for i in range((date_class.fromisoformat(date)-start).days+1):
        this=(start+timedelta(days=i)).isoformat()
        data=store.day(this)
        if store.status(this)=='Closed' and 'Department Summary' in data and 'F&B Report' in data:monthpairs.append(data)
    py=heady-14
    pack_sum_d=pack_sum_m=0
    pack_rows=((250,'Breakfast','BFST'),(252,'Lunch','LNCH'),(251,'Dinner','DNNR'),(253,'All Beverage','ANB'))
    for i,(code,name,service) in enumerate(pack_rows):
        daily=day(code);monthly=mon(code)
        ent=entitled(src.get('F&B Report'),service)
        avg=daily/ent if daily is not None and ent else None
        okay=bool(monthpairs) and len(monthpairs)==cov['Department Summary']==cov['F&B Report']
        den=0;num=0
        for rec in monthpairs:
            n=entitled(rec['F&B Report'],service)
            if n is None:okay=False;break
            den+=n
            num+=sum(float(q['today']) for q in rec['Department Summary']['codes'] if int(q['code'])==code)
        avg_m=num/den if okay and den else None
        if i%2==0:rect(c,rx+1,py-2.8,rw-2,12,ROW)
        vals=(name,fmt(daily),fmt(avg),fmt(monthly),fmt(avg_m))
        for j,value in enumerate(vals):
            text(c,px[j],py,value,6.05,j==0,GRAY if j>=3 else INK,align='left' if j==0 else 'right')
        if daily is not None:pack_sum_d+=daily
        if monthly is not None:pack_sum_m+=monthly
        py-=12
    rect(c,rx+1,py-3,rw-2,13,PAL)
    text(c,px[0],py,'TOTAL PACKAGE REVENUE',6.0,True,NAVY,max_width=px[1]-px[0]-9)
    text(c,px[1],py,fmt(pack_sum_d) if has_dep else '—',6.2,True,NAVY,align='right')
    text(c,px[3],py,fmt(pack_sum_m) if money_mtd else '—',6.2,True,NAVY,align='right')

    # Companies: 10 aligned metrics for Today and MTD, including Quad after TPL.
    bx=13;bw=W-26;bottom=12;ctop=157
    card(c,bx,bottom,bw,ctop,'COMPANIES / OCCUPIED ROOM MIX')
    # Maintain a readable Company/Category name while accommodating 20 metrics.
    # Per period: Rooms SGL DBL TPL Quad Adults Mix% RmRev F&BRev TotalRev.
    period_widths=[27,18,18,18,22,27,35,55,48,63]
    cols=[bw-sum(period_widths)*2]+period_widths*2
    edges=[bx]
    for width in cols:edges.append(edges[-1]+width)
    assert cols[0]>=145 and abs(edges[-1]-(bx+bw))<.001
    rect(c,bx+1,ctop-32,bw-2,13,'#E7F3F5')
    text(c,edges[0]+6,ctop-28,'COMPANY / CATEGORY',6.3,True,INK)
    period_columns=len(period_widths)
    boundary=period_columns+1
    text(c,(edges[1]+edges[boundary])/2,ctop-28,'TODAY',7.1,True,NAVY,align='center')
    text(c,(edges[boundary]+edges[-1])/2,ctop-28,'MTD',7.1,True,AQUA,align='center')
    h_y=ctop-42
    rect(c,bx+1,h_y-3,bw-2,12,'#F0F8F9')
    hd=('Rooms','SGL','DBL','TPL','Quad','Adults','Mix %','Rm Rev','F&B Rev','Total Rev')
    for k,lab in enumerate(hd*2,1):
        text(c,edges[k+1]-3,h_y,lab,5.5,True,INK if k<=period_columns else AQUA,align='right')
    yy=h_y-12
    rows=inhouse['rows']
    # Fixed floor avoids clashing with the footer when an extra company appears.
    row_h=min(10.1,max(5.45,(yy-bottom-9)/max(1,len(rows))))
    for i,r in enumerate(rows):
        total=r.get('is_total',False)
        if total:rect(c,bx+.8,yy-2.4,bw-1.6,row_h+1,DEEP)
        elif i%2==0:rect(c,bx+.8,yy-2.4,bw-1.6,row_h+1,ROW)
        text(c,bx+6,yy,r['name'],5.65 if row_h>8 else 5.0,total,WHITE if total else INK,max_width=cols[0]-8)
        for j,record in enumerate((r['today'],r['mtd'])):
            for k,key in enumerate(('rooms','single','double','triple','quad','adults','mix','room_revenue','fnb_revenue','total_revenue')):
                val=r['today_mix' if j==0 else 'mtd_mix'] if key=='mix' else record.get(key) if record else None
                kind='int' if k<6 else 'percent' if k==6 else 'cash'
                text(c,edges[j*period_columns+k+2]-3,yy,fmt(val,kind),5.2 if row_h>8 else 4.65,
                     total,WHITE if total else INK,align='right')
        yy-=row_h
    c.showPage();c.save()
    return str(path)
