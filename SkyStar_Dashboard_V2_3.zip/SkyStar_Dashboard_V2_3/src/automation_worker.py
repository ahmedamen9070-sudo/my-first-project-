"""Headless processing after manual Comsys exports; no desktop extraction.

Only explicitly ready day folders are processed. AI and delivery are optional;
financial release rules remain deterministic and shared with the desktop app.
"""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import date,datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import time
from xml.sax.saxutils import escape

from engine import Store,TYPE_NAMES,checks,metrics,parse_source
from import_bundle import stage_reports
from report_guard import validate_date
from release_gate import release_gate
from exports_pdf_v9 import pdf_export
from native_xlsx import native_excel_export

CORE_VERSION='automation-2'
READY_FILE='READY.json'


def init_config(path,overrides=None):
    path=Path(path).expanduser().resolve();path.parent.mkdir(parents=True,exist_ok=True)
    config={'database':str(Path.home()/'.sky_star_daily_sales_v8_3'/'production.sqlite'),
            'inbox':str(path.parent/'inbox'),'outbox':str(path.parent/'outbox'),
            'state':str(path.parent/'automation_state.sqlite'),'stable_seconds':60,
            'approval_mode':'review','ai':{'enabled':False,'model':''},
            'whatsapp':{'enabled':False,'graph_version':'v23.0','phone_number_id':'','recipient':'',
                        'mode':'template','template':{'name':'','language':'ar','body_parameters':['{business_date}','{status}']}}}
    if overrides:config.update(overrides)
    if not path.exists():
        with path.open('x',encoding='utf-8') as f:json.dump(config,f,ensure_ascii=False,indent=2)
    loaded=load_config(path)
    Path(loaded['inbox']).mkdir(parents=True,exist_ok=True)
    Path(loaded['outbox']).mkdir(parents=True,exist_ok=True)
    return loaded


def load_config(path):
    path=Path(path).expanduser().resolve()
    config=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(config,dict):raise ValueError('Automation configuration must be a JSON object.')
    for key in ('database','inbox','outbox','state'):
        if not isinstance(config.get(key),str) or not config[key].strip():raise ValueError('Missing configuration path: '+key)
        item=Path(os.path.expandvars(config[key])).expanduser()
        config[key]=str((path.parent/item).resolve() if not item.is_absolute() else item.resolve())
    if config.get('approval_mode','review') not in ('review','auto_when_clean'):raise ValueError('Unknown approval_mode.')
    stable=config.get('stable_seconds',60)
    if isinstance(stable,bool) or not isinstance(stable,(int,float)) or stable<0:raise ValueError('stable_seconds must be nonnegative.')
    for key in ('ai','whatsapp'):
        if not isinstance(config.get(key,{}),dict):raise ValueError(key+' configuration must be an object.')
    if config['database']==config['state']:raise ValueError('Automation state must be separate from the business database.')
    if config['inbox']==config['outbox']:raise ValueError('Inbox and outbox must be separate folders.')
    config['_config_path']=str(path)
    return config


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()


def _atomic_json(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    temporary.replace(path)


@contextmanager
def _run_lock(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    handle=path.open('a+b')
    try:
        if os.name=='nt':
            import msvcrt
            if path.stat().st_size==0:handle.write(b'0');handle.flush()
            handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        handle.close();raise RuntimeError('Another automation run is already active.')
    try:yield
    finally:
        if os.name=='nt':
            handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_UN)
        handle.close()


def _state(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(path)
    db.execute('''CREATE TABLE IF NOT EXISTS jobs(
        job_key TEXT PRIMARY KEY,day TEXT NOT NULL,fingerprint TEXT NOT NULL,
        result_json TEXT NOT NULL,delivery_status TEXT NOT NULL DEFAULT 'pending',
        message_id TEXT,error TEXT,attempts INTEGER NOT NULL DEFAULT 0,
        next_retry REAL NOT NULL DEFAULT 0,updated TEXT NOT NULL)''')
    columns={row[1] for row in db.execute('PRAGMA table_info(jobs)')}
    if 'delivery_config_hash' not in columns:db.execute('ALTER TABLE jobs ADD COLUMN delivery_config_hash TEXT')
    db.commit();return db


def _issue(code,message,level='BLOCKER'):
    return {'code':code,'level':level,'message':message}


def _manifest(folder):
    marker=folder/READY_FILE
    if marker.is_symlink():raise ValueError('Ready marker must not be a symbolic link.')
    if marker.stat().st_size>65536:raise ValueError('Ready marker is too large.')
    item=json.loads(marker.read_text(encoding='utf-8'))
    if not isinstance(item,dict):raise ValueError('READY.json must contain a JSON object.')
    if date.fromisoformat(item.get('business_date','')).isoformat()!=folder.name:
        raise ValueError('Ready marker business date must equal the day folder name.')
    for key in ('night_run_confirmed','undated_night_date_confirmed'):
        if type(item.get(key)) is not bool:raise ValueError('Ready marker requires boolean '+key+'.')
    return item


def _read_reports(paths,day,manifest):
    reports={};errors=[]
    try:
        with stage_reports(paths) as staged:
            for path in staged:
                try:
                    try:report=parse_source(path)
                    except ValueError as exc:
                        if 'No readable business date' not in str(exc) or not manifest['undated_night_date_confirmed']:raise
                        report=parse_source(path,date_override=day)
                        if report['kind']!='Night Report':raise ValueError('Only Night Report may have a certified manual business date.')
                    validate_date(report,day)
                    previous=reports.get(report['kind'])
                    if previous and previous['sha256']!=report['sha256']:
                        raise ValueError('Multiple different files for the same report type: '+report['kind'])
                    reports[report['kind']]=report
                except Exception as exc:errors.append(_issue('IMPORT_REJECTED',Path(path).name+': '+str(exc)))
    except Exception as exc:errors.append(_issue('BUNDLE_REJECTED',str(exc)))
    return list(reports.values()) if not errors else [],errors


def _facts(store,day,status,issues):
    source=store.day(day);values=metrics(source);selected={}
    if 'Department Summary' in source:
        for key in ('rooms','food','beverage','other','revenue','cash','card','city_ledger'):
            selected[key]=values[key]
    if 'Rooms Situation' in source:
        for key in ('physical_count','available_for_sale','revenue_occupied','comp','house_use','occupancy'):
            selected[key]=values[key]
        if 'Department Summary' in source:
            selected.update(adr=values['adr'],revpar=values['revpar'])
    return {'business_date':day,'status':status,'metrics':selected,
            'imported_reports':len(source),'required_reports':len(set(TYPE_NAMES.values())),
            'blocker_count':sum(item['level']=='BLOCKER' for item in issues),
            'warning_count':sum(item['level']=='WARNING' for item in issues),
            'issue_codes':[{'code':item['code'],'level':item['level']} for item in issues]}


def _summarize(facts,config,callback):
    if callback is not None:return callback(facts,config)
    try:
        from automation_services import summarize_facts
        return summarize_facts(facts,config)
    except Exception:
        return {'text':f"{facts['business_date']} | {facts['status']} | {facts['imported_reports']}/{facts['required_reports']} reports | {facts['blocker_count']} blockers | {facts['warning_count']} warnings",
                'mode':'local','error':'AI integration unavailable; local summary generated.'}


def _review_pdf(path,day,issues,facts):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
    styles=getSampleStyleSheet();items=[Paragraph('SKYSTAR - REVIEW COPY - NOT APPROVED',styles['Title']),
        Paragraph('Business date: '+day,styles['Heading2']),
        Paragraph('This review summary is not a finalized Daily Sales report. Figures below come only from saved validated sources.',styles['BodyText']),Spacer(1,12)]
    for key,value in facts['metrics'].items():
        items.append(Paragraph(escape(key.replace('_',' ').title()+': '+f'{value:,.2f}'),styles['BodyText']))
    items.extend([Spacer(1,12),Paragraph('All current findings',styles['Heading2'])])
    for issue in issues:
        items.append(Paragraph(escape(issue['level']+' | '+issue['code']+': '+issue['message']),styles['BodyText']))
    if not issues:items.append(Paragraph('Manual review/approval is still required.',styles['BodyText']))
    SimpleDocTemplate(str(path),pagesize=A4).build(items)


def _process_day(store,folder,config,state,ai_summarizer):
    day=folder.name;paths=sorted(p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ('.xls','.xlsx','.zip'))
    marker=folder/READY_FILE
    if any(p.is_symlink() for p in paths):
        return {'business_date':day,'status':'SKIPPED','reason':'Symbolic report files are not allowed.'}
    quiet=float(config.get('stable_seconds',60))
    if any(time.time()-p.stat().st_mtime<quiet for p in paths):
        return {'business_date':day,'status':'WAITING','reason':'Files have not remained stable long enough.'}
    errors=[]
    try:manifest=_manifest(folder)
    except Exception as exc:
        manifest={'business_date':day,'night_run_confirmed':False,'undated_night_date_confirmed':False}
        errors.append(_issue('READY_INVALID',str(exc)))
    if not paths:errors.append(_issue('NO_INPUT_FILES','No Excel or ZIP reports in this ready day folder.'))
    inputs=[(p.name,hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
    if not errors:
        reports,errors=_read_reports(paths,day,manifest)
        after_inputs=[(p.name,hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
        if after_inputs!=inputs:
            return {'business_date':day,'status':'WAITING','reason':'Input files changed during validation; no reports were saved.'}
        if reports and not errors:
            source=store.day(day)
            if store.status(day)=='Closed':
                existing={kind:sha for kind,sha in store.db.execute('SELECT kind,sha FROM sources WHERE day=?',(day,))}
                if any(existing.get(r['kind'])!=r['sha256'] or source.get(r['kind'])!=r['payload'] for r in reports):
                    errors.append(_issue('CLOSED_SOURCE_CHANGE','Closed day source files differ. No sources were changed.'))
            else:
                existing={kind:sha for kind,sha in store.db.execute('SELECT kind,sha FROM sources WHERE day=?',(day,))}
                conflicts=[r['kind'] for r in reports if r['kind'] in existing and existing[r['kind']]!=r['sha256']]
                if conflicts:errors.append(_issue('SOURCE_REPLACEMENT_REVIEW','Changed source versions require review: '+', '.join(conflicts)))
                else:
                    changed=any(existing.get(r['kind'])!=r['sha256'] or source.get(r['kind'])!=r['payload'] for r in reports)
                    if changed:
                        backups=Path(config['outbox'])/'backups';backups.mkdir(parents=True,exist_ok=True)
                        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
                        store.create_backup(backups/f'before_{day}_{stamp}.sqlite')
                    try:store.save_sources_batch(reports)
                    except Exception as exc:errors.append(_issue('IMPORT_ROLLED_BACK',str(exc)))
    eligibility=store.close_eligibility(day)
    if config.get('approval_mode','review')=='auto_when_clean' and manifest['night_run_confirmed'] and not errors and not eligibility['blockers'] and not eligibility['warnings'] and store.status(day)!='Closed':
        store.approve_day(day,comsys_closed=True)
    issues=list(errors)
    source=store.day(day)
    for finding in checks(source):
        if finding['level'] in ('BLOCKER','WARNING'):issues.append(dict(finding))
    for missing in eligibility['missing']:
        issues.append(_issue('MISSING_REPORT',missing+' not available for the selected day.'))
    if eligibility.get('unavailable'):
        issues.append(_issue('FNB_SOURCE_UNAVAILABLE','F&B source is documented unavailable. Meal statistics remain incomplete.','WARNING'))
    if store.active_import_alerts(day):issues.append(_issue('IMPORT_ALERTS','Unresolved import/date alerts require review.'))
    if not manifest['night_run_confirmed']:issues.append(_issue('NIGHT_RUN_UNCONFIRMED','Night Run completion is not confirmed for this ready batch.'))
    gate=release_gate(store,day)
    financial_release=gate['allowed'] and not any(item['level']=='BLOCKER' for item in issues)
    status='FINAL' if financial_release else 'REVIEW'
    if status=='REVIEW':
        for item in gate['issues']:
            if item['code'] not in {i['code'] for i in issues}:issues.append(_issue(item['code'],item['message']))
    pdf_gate=release_gate(store,day,require_pdf_layout=True)
    if status=='FINAL' and not pdf_gate['allowed']:
        status='REVIEW'
        for item in pdf_gate['issues']:
            if item['code']=='PDF_CAPACITY':issues.append(_issue('PDF_CAPACITY',item['message'],'WARNING'))
    facts=_facts(store,day,status,issues)
    ai=config.get('ai',{})
    source_hashes=sorted(store.db.execute('SELECT kind,sha FROM sources WHERE day=?',(day,)).fetchall())
    input_signature=sorted({sha for _,sha in inputs}) if errors else source_hashes
    fingerprint=_digest({'version':CORE_VERSION,'inputs':input_signature,
                         'input_errors':sorted({item['code'] for item in errors}),
                         'manifest':{key:manifest[key] for key in ('business_date','night_run_confirmed','undated_night_date_confirmed')},'source':source,
                         'status':store.status(day),'notes_hash':_digest(store.notes(day)),
                         'exceptions':sorted(eligibility.get('unavailable',{})),
                         'approval_mode':config.get('approval_mode','review'),'ai':ai,
                         'ai_key_present':bool(os.environ.get('SKYSTAR_AI_API_KEY'))})
    job_key=day+':'+fingerprint
    existing=state.execute('SELECT result_json FROM jobs WHERE job_key=?',(job_key,)).fetchone()
    if existing:
        cached=json.loads(existing[0])
        if all(Path(p).is_file() for p in cached.get('files',{}).values()):return cached
    output=Path(config['outbox'])/day/fingerprint[:16];output.mkdir(parents=True,exist_ok=True)
    summary=_summarize(facts,ai,ai_summarizer)
    result={'business_date':day,'status':status,'issues':issues,'facts':facts,'summary':summary,
            'files':{},'output_dir':str(output),'summary_mode':summary.get('mode','local'),
            'job_key':job_key,'fingerprint':fingerprint,'delivery_status':'pending'}
    if financial_release:
        xlsx=output/f'SkyStar_Daily_Sales_{day}.xlsx';native_excel_export(store,day,xlsx)
        result['files']['excel']=str(xlsx)
        if pdf_gate['allowed']:
            pdf=output/f'SkyStar_Daily_Sales_{day}.pdf';pdf_export(store,day,pdf)
            result['files']['pdf']=str(pdf)
        else:
            pdf=output/f'SkyStar_Review_{day}.pdf';_review_pdf(pdf,day,issues,facts)
            result['files']['review_pdf']=str(pdf)
    else:
        pdf=output/f'SkyStar_Review_{day}.pdf';_review_pdf(pdf,day,issues,facts);result['files']['review_pdf']=str(pdf)
    summary_path=output/'summary_ar.txt'
    prefix='مسودة ملخص بالذكاء الاصطناعي' if summary.get('mode')=='ai' else 'ملخص محلي تلقائي'
    summary_path.write_text(prefix+'\nالحالة: '+status+'\nيوم العمل: '+day+'\n\n'+str(summary.get('text',''))+'\n',encoding='utf-8')
    result['files']['summary']=str(summary_path)
    result_path=output/'result.json';result['files']['json']=str(result_path)
    _atomic_json(result_path,result)
    stamp=datetime.now(timezone.utc).isoformat()
    state.execute('INSERT INTO jobs(job_key,day,fingerprint,result_json,updated) VALUES(?,?,?,?,?) '
                  'ON CONFLICT(job_key) DO UPDATE SET result_json=excluded.result_json,updated=excluded.updated',
                  (job_key,day,fingerprint,json.dumps(result,ensure_ascii=False),stamp));state.commit()
    return result


def _delivery(result,config,state,send,transport):
    if not result.get('job_key'):return result
    row=state.execute('SELECT delivery_status,message_id,error,attempts,next_retry,delivery_config_hash FROM jobs WHERE job_key=?',(result['job_key'],)).fetchone()
    delivery,message_id,error,attempts,next_retry,prior_config_hash=row
    settings=config.get('whatsapp',{})
    config_hash=_digest({'settings':settings,'credential_present':bool(os.environ.get('SKYSTAR_WA_TOKEN'))})
    result=dict(result);result['delivery_status']=delivery
    if message_id:result['message_id']=message_id
    def persist(status,err=None,retry_at=0):
        result['delivery_status']=status
        if err:result['delivery_error']=err
        else:result.pop('delivery_error',None)
        state.execute('UPDATE jobs SET delivery_status=?,message_id=?,error=?,next_retry=?,delivery_config_hash=?,result_json=?,updated=? WHERE job_key=?',
                      (status,message_id,err,retry_at,config_hash,json.dumps(result,ensure_ascii=False),datetime.now(timezone.utc).isoformat(),result['job_key']))
        state.commit();_atomic_json(Path(result['files']['json']),result)
        return result
    if delivery in ('sent','uncertain','sending'):
        if delivery=='sending':return persist('uncertain','InterruptedSend')
        return result
    if not send:return result
    # A changed recipient/template/API configuration permits retrying only a
    # definitively rejected delivery. Confirmed or uncertain sends never reset.
    if delivery=='failed' and prior_config_hash!=config_hash:
        attempts=0;next_retry=0
        state.execute('UPDATE jobs SET attempts=0,next_retry=0 WHERE job_key=?',(result['job_key'],));state.commit()
    if not settings.get('enabled',False):
        result['delivery_missing']=['whatsapp.enabled']
        return persist('awaiting_configuration')
    if transport is None:
        from automation_services import whatsapp_config_status,send_whatsapp_document
        status=whatsapp_config_status(settings)
        if not status['ready']:
            result['delivery_missing']=status['missing']
            return persist('awaiting_configuration')
    result.pop('delivery_missing',None)
    if attempts>=3 or next_retry>time.time():return result
    try:
        # Persist the intent before the provider call. A crash cannot become a blind resend.
        state.execute("UPDATE jobs SET delivery_status='sending',attempts=attempts+1,delivery_config_hash=?,updated=? WHERE job_key=?",
                      (config_hash,datetime.now(timezone.utc).isoformat(),result['job_key']));state.commit()
        path=Path(result['files'].get('pdf') or result['files']['review_pdf'])
        summary=result['summary'].get('text','')
        if transport is not None:
            callback=transport.send_document if hasattr(transport,'send_document') else transport
            response=callback(path,result['business_date'],result['status'],summary)
        else:response=send_whatsapp_document(path,result['business_date'],result['status'],summary,settings)
        message_id=response.get('message_id') if isinstance(response,dict) else response
        if not isinstance(message_id,str) or not message_id.strip():
            raise TimeoutError('No confirmed provider message identifier.')
        result['message_id']=message_id
        return persist('sent')
    except Exception as exc:
        if type(exc).__name__ in ('ServiceRejected','ServiceConfigurationError','ServiceError'):
            return persist('failed',type(exc).__name__,time.time()+300)
        return persist('uncertain',type(exc).__name__)


def run_once(config_or_path,send=False,transport=None,ai_summarizer=None):
    config=load_config(config_or_path) if isinstance(config_or_path,(str,Path)) else dict(config_or_path)
    for key in ('inbox','outbox'):Path(config[key]).mkdir(parents=True,exist_ok=True)
    state_path=Path(config['state']);results=[]
    with _run_lock(state_path.with_suffix('.lock')):
        state=_state(state_path);store=Store(config['database'])
        try:
            for folder in sorted(Path(config['inbox']).iterdir()):
                if not folder.is_dir() or folder.is_symlink() or not (folder/READY_FILE).is_file():continue
                try:
                    if date.fromisoformat(folder.name).isoformat()!=folder.name:continue
                except ValueError:continue
                try:
                    result=_process_day(store,folder,config,state,ai_summarizer)
                    results.append(_delivery(result,config,state,send,transport))
                except Exception as exc:
                    results.append({'business_date':folder.name,'status':'ERROR','error':type(exc).__name__})
        finally:store.close();state.close()
    return results


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True,type=Path)
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--init',action='store_true');action.add_argument('--run',action='store_true')
    parser.add_argument('--send',action='store_true',help='Attempt configured WhatsApp delivery; disabled by default.')
    args=parser.parse_args(argv)
    if args.init:
        config=init_config(args.config)
        print('Automation initialized. Edit the non-secret configuration at '+str(args.config.resolve()))
        print('Inbox: '+config['inbox']);return 0
    results=run_once(args.config,send=args.send)
    print(json.dumps(results,ensure_ascii=False,indent=2))
    return 1 if any(item.get('status')=='ERROR' for item in results) else 0


if __name__=='__main__':raise SystemExit(main())
