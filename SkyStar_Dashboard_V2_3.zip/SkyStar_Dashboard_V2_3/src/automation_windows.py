"""Interactive local folder helpers for the Windows launchers."""
import argparse
from datetime import date,datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys


def default_config_path():
    return Path.home()/'.sky_star_daily_sales_v8_3'/'automation'/'config.json'


def prepare_day(config_path,business_date):
    from automation_worker import load_config
    selected=date.fromisoformat(business_date).isoformat()
    config=load_config(config_path)
    folder=Path(config['inbox'])/selected
    folder.mkdir(parents=True,exist_ok=True)
    return folder


def mark_ready(config_path,business_date,night_confirmed=False,undated_confirmed=False):
    selected=date.fromisoformat(business_date).isoformat()
    if not night_confirmed:raise ValueError('Night Run must be confirmed for the selected business date.')
    folder=prepare_day(config_path,selected)
    if not any(p.is_file() and p.suffix.lower() in ('.xls','.xlsx','.zip') for p in folder.iterdir()):
        raise ValueError('No report files found in the selected day folder.')
    value={'business_date':selected,'night_run_confirmed':True,
           'undated_night_date_confirmed':bool(undated_confirmed),
           'confirmed_at':datetime.now(timezone.utc).isoformat()}
    temporary=folder/'READY.tmp';temporary.write_text(json.dumps(value,indent=2),encoding='utf-8')
    temporary.replace(folder/'READY.json')
    return folder/'READY.json'


def open_folder(path):
    if os.name=='nt':os.startfile(str(path))
    else:print('Folder:',path)


def print_results(results):
    if not results:
        print('No ready day folders found. Prepare the day folder, export reports, then mark it ready.')
        return
    labels={'FINAL':'Final report ready','REVIEW':'Review summary ready; day is not automatically approved',
            'WAITING':'Waiting for report files to finish writing','SKIPPED':'Folder skipped','ERROR':'Processing needs attention'}
    delivery={'sent':'WhatsApp accepted this message (receipt/read status is not confirmed).',
              'awaiting_configuration':'WhatsApp is not connected. The report is saved locally.',
              'pending':'No WhatsApp message was sent.',
              'uncertain':'WhatsApp outcome is uncertain. Check delivery before retrying.',
              'failed':'WhatsApp rejected delivery. Correct its setup before retrying.'}
    for result in results:
        print(result.get('business_date','')+': '+labels.get(result.get('status'),'Processing status unavailable'))
        if result.get('reason'):print(result['reason'])
        if result.get('output_dir'):print('Output folder:',result['output_dir'])
        if result.get('delivery_status'):print(delivery.get(result['delivery_status'],'No confirmed message delivery.'))


def main(argv=None):
    parser=argparse.ArgumentParser(description='SkyStar local automation setup')
    parser.add_argument('action',choices=['setup','prepare','process','run'])
    parser.add_argument('--config',type=Path,default=default_config_path())
    parser.add_argument('--day')
    args=parser.parse_args(argv)
    from automation_worker import init_config,load_config,run_once
    if args.action=='setup':
        init_config(args.config)
        config=load_config(args.config)
        print('Local setup ready:',args.config)
        print('Comsys export remains manual. AI and WhatsApp connections are disabled until configured.')
        print('Inbox:',config['inbox']);print('Output:',config['outbox'])
        open_folder(Path(config['inbox']))
        return 0
    if not args.config.is_file():
        print('Run SETUP_AUTOMATION_WINDOWS.bat first.');return 1
    if args.action=='run':
        results=run_once(args.config,send=True);print_results(results)
        return 1 if any(item.get('status')=='ERROR' for item in results) else 0
    business_date=args.day or input('Business date (YYYY-MM-DD): ').strip()
    date.fromisoformat(business_date)
    if args.action=='prepare':
        folder=prepare_day(args.config,business_date)
        print('Export ONLY this business date reports into:',folder)
        print('When all exports finish, run PROCESS_REPORTS_WINDOWS.bat for this same date.')
        open_folder(folder);return 0
    night=input('Has Comsys completed Night Run for this exact date? Type YES: ').strip()=='YES'
    if not night:print('No readiness confirmation saved.');return 1
    undated=input('Did you verify any undated Night Report belongs to this date? Type YES if verified: ').strip()=='YES'
    mark_ready(args.config,business_date,night_confirmed=night,undated_confirmed=undated)
    result=run_once(args.config,send=True)
    print_results(result)
    return 1 if any(item.get('status')=='ERROR' for item in result) else 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError) as error:
        print('Automation could not run:',str(error));raise SystemExit(1)
