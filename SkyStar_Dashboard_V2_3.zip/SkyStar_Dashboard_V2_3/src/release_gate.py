"""Shared non-GUI checks before issuing a final management report."""
from datetime import date,timedelta
from engine import checks
from company_mix import company_mix


def release_gate(store,day,require_pdf_layout=False,company_row_count=None):
    date.fromisoformat(day)
    source=store.day(day);issues=[]
    def add(code,message):issues.append({'code':code,'message':message})
    if not source:add('NO_DATA','No imported source reports for the selected day.')
    if store.active_import_alerts(day):add('IMPORT_ALERTS','Unresolved import/date alerts require review.')
    if store.status(day)!='Closed':add('NOT_CLOSED','The selected business day has not been approved.')
    if any(item['level']=='BLOCKER' for item in checks(source)):
        add('FINANCIAL_BLOCKERS','The selected day has financial or source reconciliation blockers.')
    if require_pdf_layout:
        count=company_row_count if company_row_count is not None else len(company_mix(store,day)['rows'])
        if count>15:add('PDF_CAPACITY','More than 15 company/category lines exceed the management A4 layout.')
    mandatory={'Department Summary','Rooms Situation','Guest In House','Company Revenue','F&B Report','Cashier Summary','Daily Sales'}
    cursor=store.reporting_start(day);end=date.fromisoformat(day);incomplete=[]
    while cursor<=end:
        key=cursor.isoformat();missing=mandatory-set(store.day(key))
        if 'F&B Report' in missing and store.report_unavailable_reason(key,'F&B Report'):
            missing.remove('F&B Report')
        if store.status(key)!='Closed' or missing:
            incomplete.append({'day':key,'missing':sorted(missing),'status':store.status(key)})
        cursor+=timedelta(days=1)
    if incomplete:
        add('MTD_COVERAGE','Incomplete closed-day/source coverage: '+', '.join(item['day'] for item in incomplete[:8]))
    return {'allowed':not issues,'issues':issues,'incomplete_dates':incomplete}
