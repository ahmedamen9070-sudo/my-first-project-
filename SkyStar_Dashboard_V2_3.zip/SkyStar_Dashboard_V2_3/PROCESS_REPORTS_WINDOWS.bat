@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py -3"
) else (
  set "PY_CMD=python"
)
%PY_CMD% -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if errorlevel 1 (
  echo Python 3.10 or later is required.
  pause
  exit /b 1
)
%PY_CMD% -c "import reportlab" >nul 2>&1
if errorlevel 1 (
  %PY_CMD% -m pip install --user -r "%~dp0requirements.txt"
  if errorlevel 1 (
    echo Dependency installation failed. Review the error above.
    pause
    exit /b 1
  )
)
%PY_CMD% -X utf8 "%~dp0src\automation_windows.py" process
set "APP_EXIT=%ERRORLEVEL%"
pause
exit /b %APP_EXIT%
