$ErrorActionPreference = 'Stop'
$confirm = Read-Host 'Remove the SkyStarDailySalesAutomation task? Type YES'
if ($confirm -ceq 'YES') {
    Unregister-ScheduledTask -TaskName 'SkyStarDailySalesAutomation' -Confirm:$false
    Write-Host 'Scheduled task removed. Report data and output files were retained.'
}
