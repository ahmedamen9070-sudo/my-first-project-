"""Full folder-to-provider wiring using fake HTTP only; no live services."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from automation_worker import init_config,load_config,run_once
from automation_windows import mark_ready
from automation_services import send_whatsapp_document,summarize_facts
from test_daily_sales_workflow import make_bundle,DAY

class ProviderWiring(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.path=self.root/'config.json'
        init_config(self.path,{'database':str(self.root/'test.sqlite'),'approval_mode':'auto_when_clean','stable_seconds':0})
        self.config=load_config(self.path)
        folder=Path(self.config['inbox'])/DAY
        make_bundle(folder)
        # Keep just the exported ZIP, avoiding redundant loose input copies.
        for p in folder.glob('*.xlsx'):p.unlink()
        mark_ready(self.path,DAY,night_confirmed=True,undated_confirmed=True)
    def tearDown(self):self.tmp.cleanup()
    def test_defaults_generate_local_reports_and_never_claim_sent(self):
        def forbidden(*_):raise AssertionError('No provider connection should be attempted')
        result=run_once(self.path,send=True,transport=forbidden)[0]
        self.assertEqual(result['status'],'FINAL')
        self.assertEqual(result['delivery_status'],'awaiting_configuration')
        self.assertEqual(result['summary']['mode'],'local')
        self.assertTrue(Path(result['files']['summary']).is_file())
        self.assertTrue(Path(result['files']['pdf']).read_bytes().startswith(b'%PDF-'))
        saved=json.loads(Path(result['files']['json']).read_text())
        self.assertEqual(saved['delivery_status'],'awaiting_configuration')
    def test_simulated_provider_pipeline_and_renamed_bundle_deduplicate(self):
        cfg=json.loads(self.path.read_text())
        cfg['ai']={'enabled':True,'model':'unit-test-model'}
        cfg['whatsapp']={'enabled':True,'graph_version':'v23.0','phone_number_id':'123456789',
                         'recipient':'201000000000','mode':'template',
                         'template':{'name':'unit_test_daily_report','language':'ar','body_parameters':['{business_date}','{status}','{summary}']}}
        self.path.write_text(json.dumps(cfg))
        calls=[]
        def http(url,headers,body,timeout,max_response_bytes):
            calls.append(url)
            if url.endswith('/responses'):
                payload=json.loads(body)
                self.assertEqual(json.loads(payload['input'])['metrics']['revenue'],1275)
                return 200,json.dumps({'output':[{'type':'message','content':[{'type':'output_text','text':'مسودة ملخص بالذكاء الاصطناعي: بيانات اختبار فقط.'}]}]}).encode()
            if url.endswith('/media'):
                self.assertIn(b'%PDF-',body);return 200,b'{"id":"987654321"}'
            self.assertTrue(url.endswith('/messages'))
            message=json.loads(body)
            body_component=next(c for c in message['template']['components'] if c['type']=='body')
            self.assertEqual(body_component['parameters'][1]['text'],'FINAL')
            return 200,b'{"messages":[{"id":"wamid.UNIT_TEST_ONLY"}]}'
        def ai(facts,config):return summarize_facts(facts,config,transport=http)
        def wa(path,day,status,summary):return send_whatsapp_document(path,day,status,summary,cfg['whatsapp'],transport=http)
        with patch.dict('os.environ',{'SKYSTAR_AI_API_KEY':'unit-test-placeholder-only','SKYSTAR_WA_TOKEN':'unit-test-wa-placeholder-only'}):
            first=run_once(self.path,send=True,transport=wa,ai_summarizer=ai)[0]
            self.assertEqual(first['delivery_status'],'sent')
            self.assertEqual(first['summary']['mode'],'ai')
            folder=Path(self.config['inbox'])/DAY
            next(folder.glob('*.zip')).rename(folder/'renamed_same_reports.zip')
            mark_ready(self.path,DAY,night_confirmed=True,undated_confirmed=True)
            second=run_once(self.path,send=True,transport=wa,ai_summarizer=ai)[0]
            self.assertEqual(second['job_key'],first['job_key'])
            self.assertEqual(second['message_id'],first['message_id'])
        self.assertEqual(len(calls),3)  # One AI request, one upload, one message; zero retries.

if __name__=='__main__':unittest.main()
