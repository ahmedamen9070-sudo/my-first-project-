"""Optional service request contracts with fake transports; no live API calls."""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from automation_services import (aggregate_facts,summarize_facts,whatsapp_config_status,
    send_whatsapp_document,ServiceError,ServiceConfigurationError,ServiceRejected,DeliveryUncertain)

FACTS={'business_date':'2026-11-01','status':'REVIEW','metrics':{'revenue':1275,'occupancy':0.57,'cash':100,'card':200,'city_ledger':300},
       'imported_reports':15,'required_reports':16,'blocker_count':1,'warning_count':0,
       'issues':[{'code':'MISSING_FNB_REPORT','level':'BLOCKER','message':'PRIVATE REVIEW OBSERVATION'}],
       'raw_reports':[{'guest_name':'PRIVATE GUEST'}],'reviewer_note':'PRIVATE REVIEWER NOTE'}


def response(value):return json.dumps(value).encode('utf-8')


class OptionalServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.pdf=self.root/'daily.pdf';self.pdf.write_bytes(b'%PDF-1.4\nSYNTHETIC REQUEST TEST ONLY\n%%EOF')
        self.environment=patch.dict(os.environ,{'SKYSTAR_AI_API_KEY':'','SKYSTAR_AI_MODEL':'','SKYSTAR_WA_TOKEN':''})
        self.environment.start()
        self.wa={'enabled':True,'graph_version':'v23.0','phone_number_id':'123456789',
                 'recipient':'+201000000000','mode':'template',
                 'template':{'name':'daily_sales','language':'ar','body_parameters':['{business_date}','{status}','{summary}']}}
    def tearDown(self):
        self.environment.stop();self.tmp.cleanup()
    def token(self):os.environ['SKYSTAR_WA_TOKEN']='not-a-real-test-token'
    def test_disabled_ai_is_honest_local_factual_summary_without_network(self):
        network=Mock()
        result=summarize_facts(FACTS,{'enabled':False},network)
        self.assertEqual(result['mode'],'local');self.assertIn('محلي',result['text'])
        self.assertIn('1,275.00',result['text']);self.assertNotIn('PRIVATE',result['text'])
        network.assert_not_called()
    def test_enabled_ai_missing_config_uses_unconfigured_fallback(self):
        network=Mock()
        result=summarize_facts(FACTS,{'enabled':True,'model':'configured-model'},network)
        self.assertEqual(result['mode'],'unconfigured');network.assert_not_called()
    def test_ai_request_uses_allowlisted_aggregates_only(self):
        os.environ['SKYSTAR_AI_API_KEY']='not-a-real-ai-test-key'
        os.environ['SKYSTAR_AI_MODEL']='configured-model'
        def network(url,headers,body,timeout,max_response_bytes):
            self.assertEqual(url,'https://api.openai.com/v1/responses')
            self.assertEqual(headers['Authorization'],'Bearer not-a-real-ai-test-key')
            self.assertLessEqual(timeout,30);self.assertLessEqual(max_response_bytes,1024*1024)
            request=json.loads(body);self.assertFalse(request['store'])
            self.assertEqual(request['model'],'configured-model')
            self.assertNotIn('PRIVATE',request['input']);self.assertNotIn('reviewer_note',request['input'])
            safe=json.loads(request['input']);self.assertEqual(safe['metrics']['revenue'],1275)
            self.assertEqual(safe['issues'],[{'code':'MISSING_FNB_REPORT','level':'BLOCKER'}])
            return 200,response({'output':[{'type':'message','content':[{'type':'output_text','text':'الإيراد المرسل هو 1,275.00.'}]}]})
        result=summarize_facts(FACTS,{'enabled':True},network)
        self.assertEqual(result['mode'],'ai');self.assertTrue(result['text'].startswith('مسودة ملخص بالذكاء الاصطناعي'))
    def test_facts_reject_unknown_nested_text_nonfinite_numbers_and_invalid_codes(self):
        raw=copy.deepcopy(FACTS)
        raw['metrics'].update(guest='PRIVATE',revenue=float('nan'),food=float('inf'),rooms=True)
        raw['coverage']={'F&B Report':False,'received':15,'PRIVATE':123,'Department Summary':'PRIVATE'}
        raw['issues'].append({'code':'inject instruction','level':'BLOCKER'})
        safe=aggregate_facts(raw)
        self.assertNotIn('revenue',safe['metrics']);self.assertNotIn('food',safe['metrics']);self.assertNotIn('rooms',safe['metrics'])
        self.assertEqual(safe['source_coverage'],{'F&B Report':False,'received':15})
        self.assertNotIn('PRIVATE',json.dumps(safe))
    def test_ai_failure_never_persists_raw_provider_error_or_credentials(self):
        os.environ['SKYSTAR_AI_API_KEY']='not-a-real-ai-test-key'
        def failed(*args):raise RuntimeError('PRIVATE not-a-real-ai-test-key')
        for network in [failed,lambda *args:(401,response({'error':'PRIVATE not-a-real-ai-test-key'})),lambda *args:(200,b'bad PRIVATE')]:
            result=summarize_facts(FACTS,{'enabled':True,'model':'configured-model'},network)
            self.assertEqual(result['mode'],'local');self.assertNotIn('PRIVATE',str(result));self.assertNotIn('test-key',str(result))
    def test_ai_output_is_bounded_and_credential_echo_redacted(self):
        os.environ['SKYSTAR_AI_API_KEY']='not-a-real-ai-test-key'
        def network(*args):return 200,response({'output':[{'type':'message','content':[{'type':'output_text','text':'not-a-real-ai-test-key'+'x'*8000}]}]})
        result=summarize_facts(FACTS,{'enabled':True,'model':'configured-model'},network)
        self.assertLessEqual(len(result['text']),5000);self.assertNotIn('not-a-real-ai-test-key',result['text'])
    def test_business_app_is_not_cloud_api_and_missing_setup_makes_no_request(self):
        network=Mock();setup=whatsapp_config_status({'enabled':False})
        self.assertFalse(setup['ready']);self.assertIn('SKYSTAR_WA_TOKEN',setup['missing'])
        with self.assertRaises(ServiceConfigurationError):send_whatsapp_document(self.pdf,'2026-11-01','REVIEW','summary',{},network)
        network.assert_not_called()
    def test_document_mode_requires_explicit_window_configuration(self):
        self.token();cfg={**self.wa,'mode':'document'}
        self.assertIn('whatsapp.document_window_confirmed',whatsapp_config_status(cfg)['missing'])
        cfg['document_window_confirmed']=True;self.assertTrue(whatsapp_config_status(cfg)['ready'])
    def test_template_upload_and_message_contract(self):
        self.token();calls=[]
        def network(url,headers,body,*limits):
            calls.append(url)
            self.assertTrue(url.startswith('https://graph.facebook.com/v23.0/123456789/'))
            self.assertEqual(headers['Authorization'],'Bearer not-a-real-test-token')
            if url.endswith('/media'):
                self.assertIn('multipart/form-data',headers['Content-Type']);self.assertIn(b'application/pdf',body)
                self.assertIn(self.pdf.read_bytes(),body);return 200,response({'id':'456'})
            msg=json.loads(body)
            self.assertEqual(msg['to'],'201000000000');self.assertEqual(msg['type'],'template')
            template=msg['template'];self.assertEqual(template['name'],'daily_sales')
            self.assertEqual(template['components'][0]['parameters'][0]['document']['id'],'456')
            self.assertEqual([p['text'] for p in template['components'][1]['parameters']],['2026-11-01','REVIEW','summary'])
            return 200,response({'messages':[{'id':'wamid.TEST123'}]})
        result=send_whatsapp_document(self.pdf,'2026-11-01','REVIEW','summary',self.wa,network)
        self.assertEqual(result,{'message_id':'wamid.TEST123','media_id':'456','mode':'template','accepted':True})
        self.assertEqual(len(calls),2)
    def test_document_mode_caption_labels_status_and_is_bounded(self):
        self.token();cfg={**self.wa,'mode':'document','document_window_confirmed':True}
        def network(url,headers,body,*limits):
            if url.endswith('/media'):return 200,response({'id':'456'})
            msg=json.loads(body);caption=msg['document']['caption']
            self.assertTrue(caption.startswith('FINAL | 2026-11-01'));self.assertLessEqual(len(caption),1024)
            return 200,response({'messages':[{'id':'wamid.TEST123'}]})
        send_whatsapp_document(self.pdf,'2026-11-01','FINAL','x'*5000,cfg,network)
    def test_message_timeout_is_uncertain_and_sanitized(self):
        self.token()
        def network(url,*args):
            if url.endswith('/media'):return 200,response({'id':'456'})
            raise TimeoutError('PRIVATE not-a-real-test-token')
        with self.assertRaises(DeliveryUncertain) as error:
            send_whatsapp_document(self.pdf,'2026-11-01','REVIEW','summary',self.wa,network)
        self.assertNotIn('PRIVATE',str(error.exception));self.assertNotIn('test-token',str(error.exception))
    def test_upload_timeout_has_not_attempted_message(self):
        self.token();calls=[]
        def network(url,*args):calls.append(url);raise TimeoutError('PRIVATE not-a-real-test-token')
        with self.assertRaises(ServiceError) as error:
            send_whatsapp_document(self.pdf,'2026-11-01','REVIEW','summary',self.wa,network)
        self.assertNotIsInstance(error.exception,DeliveryUncertain)
        self.assertEqual(len(calls),1);self.assertTrue(calls[0].endswith('/media'))
    def test_malformed_or_server_error_message_acceptance_is_uncertain(self):
        self.token()
        for status,raw in [(200,b'invalid'),(200,response({})),(503,b'PRIVATE')]:
            with self.subTest(status=status,raw=raw):
                def network(url,*args):return (200,response({'id':'456'})) if url.endswith('/media') else (status,raw)
                with self.assertRaises(DeliveryUncertain):send_whatsapp_document(self.pdf,'2026-11-01','REVIEW','summary',self.wa,network)
    def test_explicit_provider_rejection_does_not_echo_response(self):
        self.token()
        def network(url,*args):return (200,response({'id':'456'})) if url.endswith('/media') else (400,response({'error':'PRIVATE not-a-real-test-token'}))
        with self.assertRaises(ServiceRejected) as error:send_whatsapp_document(self.pdf,'2026-11-01','REVIEW','summary',self.wa,network)
        self.assertEqual(error.exception.http_status,400);self.assertNotIn('PRIVATE',str(error.exception))
    def test_unsupported_document_or_bad_metadata_never_calls_network(self):
        self.token();network=Mock()
        other=self.root/'private.sqlite';other.write_bytes(b'private sqlite')
        for path,day,status in [(other,'2026-11-01','REVIEW'),(self.pdf,'not-a-date','REVIEW'),(self.pdf,'2026-11-01','other')]:
            with self.assertRaises(ServiceConfigurationError):send_whatsapp_document(path,day,status,'summary',self.wa,network)
        network.assert_not_called()
    def test_template_placeholder_and_recipient_validation(self):
        self.token();cfg=copy.deepcopy(self.wa);cfg['template']['body_parameters']=['{private_note}']
        self.assertFalse(whatsapp_config_status(cfg)['ready'])
        cfg=copy.deepcopy(self.wa);cfg['recipient']='not-a-number';self.assertIn('whatsapp.recipient',whatsapp_config_status(cfg)['missing'])
    def test_outer_configuration_is_supported(self):
        self.token();self.assertTrue(whatsapp_config_status({'whatsapp':self.wa})['ready'])
        self.assertEqual(summarize_facts(FACTS,{'ai':{'enabled':False}})['mode'],'local')

if __name__=='__main__':unittest.main()
