"""Synthetic regressions: financial company lines with explicit zero occupancy."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from engine import Store,checks,metrics,parse_source
from company_mix import company_mix,_build
from inhouse_company import is_zero_occupancy_company
from test_daily_sales_workflow import DAY,synthetic_reports,write_xlsx

ZERO_NAME='Synthetic revenue-only account'
ZERO_FIELDS=('rooms','single','double','triple','quad','other_type','suite')


def zero_record():
    return {'company':ZERO_NAME,'pax':'0/0/0',**{k:0 for k in ZERO_FIELDS},
            'room_revenue':100,'fnb_revenue':20,'other_revenue':0,'total_revenue':120}


class RevenueOnlyCompany(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.store=Store(self.root/'synthetic.sqlite')
        self.sources=self.make_reports(DAY)
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def make_reports(self,day):
        records=[];directory=self.root/day;directory.mkdir(exist_ok=True)
        for name,rows in synthetic_reports(day).items():
            path=directory/(name+'.xlsx');write_xlsx(path,name,rows)
            records.append(parse_source(path))
        # Move existing revenue into a new financial line; hotel money and
        # actual guest occupancy stay unchanged across all independent sources.
        company=next(r['payload'] for r in records if r['kind']=='Company Revenue')
        company['companies'][0].update(room_revenue=900,fnb_revenue=230,total_revenue=1155)
        company['companies'].append(zero_record())
        return records
    def source(self):return {r['kind']:r['payload'] for r in self.sources}
    def test_accepts_only_explicit_zero_statement(self):
        self.assertTrue(is_zero_occupancy_company(zero_record()))
        zero=zero_record();zero['pax']=' 0.0 / 0 / 0.00 '
        self.assertTrue(is_zero_occupancy_company(zero))
        for key in ZERO_FIELDS:
            for value in [None,False,1,-1,0.5,'0']:
                with self.subTest(key=key,value=value):
                    row=zero_record();row[key]=value
                    self.assertFalse(is_zero_occupancy_company(row))
            row=zero_record();del row[key]
            self.assertFalse(is_zero_occupancy_company(row))
        for pax in [None,'','0','0/0','0/0/0/0','1/0/0','0/1/0','0/0/1','unknown/0/0']:
            row=zero_record();row['pax']=pax
            self.assertFalse(is_zero_occupancy_company(row))
    def test_zero_occupancy_financial_line_does_not_block_day(self):
        src=self.source();before=metrics(src)
        self.assertFalse([x for x in checks(src) if x['level']=='BLOCKER'])
        self.assertIn('COMPANY_REVENUE_ONLY',{x['code'] for x in checks(src)})
        self.assertEqual(before['revenue'],1275)
        self.assertEqual(before['revenue_occupied'],1)
    def test_company_mix_preserves_money_and_real_room_totals(self):
        self.store.save_sources_batch(self.sources)
        mix=company_mix(self.store,DAY)
        row=next(r['today'] for r in mix['rows'] if r['name']==ZERO_NAME)
        self.assertEqual(row['kind'],'revenue_only')
        self.assertEqual([row[k] for k in ('rooms','single','double','triple','quad','adults')],[0]*6)
        self.assertEqual([row[k] for k in ('room_revenue','fnb_revenue','total_revenue')],[100,20,120])
        total=mix['rows'][-1]['today']
        self.assertEqual((total['rooms'],total['adults'],total['total_revenue']),(1,2,1275))
        self.assertEqual(mix['today_gap'],0)
        self.assertFalse(mix['issues'])
        names=[r['name'] for r in mix['rows']]
        self.assertLess(names.index(ZERO_NAME),names.index('Complimentary Rooms'))
    def test_unknown_zero_counts_still_block_and_remain_unmatched(self):
        src=self.source();row=src['Company Revenue']['companies'][-1];del row['suite']
        self.assertIn('COMPANY_GUEST_MISSING',{x['code'] for x in checks(src) if x['level']=='BLOCKER'})
        rows,issues=_build(src)
        self.assertEqual(rows[ZERO_NAME]['kind'],'unmatched')
        self.assertIsNone(rows[ZERO_NAME]['rooms'])
        self.assertTrue(issues)
    def test_positive_pax_or_room_type_without_guests_still_blocks(self):
        for key,value in [('pax','0/1/0'),('double',1),('rooms',1)]:
            src=self.source();src['Company Revenue']['companies'][-1][key]=value
            self.assertIn('COMPANY_GUEST_MISSING',{x['code'] for x in checks(src) if x['level']=='BLOCKER'})
            self.sources=self.make_reports(DAY)
    def test_actual_guests_against_zero_source_still_block(self):
        src=self.source()
        src['Guest In House']['guests'][0]['company']=ZERO_NAME
        findings=[x for x in checks(src) if x['level']=='BLOCKER']
        self.assertTrue(any(x['code']=='COMPANY_GUEST_COUNT' and ZERO_NAME in x['message'] for x in findings))
    def test_absent_guest_source_does_not_fabricate_zero_occupancy(self):
        src=self.source();del src['Guest In House']
        rows,issues=_build(src)
        self.assertEqual(rows[ZERO_NAME]['kind'],'unmatched')
        self.assertIsNone(rows[ZERO_NAME]['rooms'])
        self.assertIn('MISSING_GUEST_IN_HOUSE',{x['code'] for x in checks(src) if x['level']=='BLOCKER'})
    def test_closed_two_day_mtd_preserves_revenue_only_counts_and_amounts(self):
        self.store.save_sources_batch(self.sources);self.store.approve_day(DAY,comsys_closed=True)
        next_day='2026-11-02'
        self.store.save_sources_batch(self.make_reports(next_day));self.store.approve_day(next_day,comsys_closed=True)
        mix=company_mix(self.store,next_day)
        row=next(r['mtd'] for r in mix['rows'] if r['name']==ZERO_NAME)
        self.assertEqual((row['rooms'],row['adults'],row['total_revenue']),(0,0,240))
        total=mix['rows'][-1]['mtd']
        self.assertEqual((total['rooms'],total['adults'],total['total_revenue']),(2,4,2550))
        self.assertEqual(mix['mtd_gap'],0)
        self.assertFalse(mix['issues'])
    def test_company_transition_to_paid_occupancy_preserves_mtd(self):
        self.store.save_sources_batch(self.sources);self.store.approve_day(DAY,comsys_closed=True)
        next_day='2026-11-02';next_reports=self.make_reports(next_day)
        src={r['kind']:r['payload'] for r in next_reports}
        src['Guest In House']['guests'][0]['company']=ZERO_NAME
        active,financial=src['Company Revenue']['companies']
        active.update({k:0 for k in ZERO_FIELDS});active['pax']='0/0/0'
        financial.update(rooms=1,double=1,pax='2/0/0')
        self.store.save_sources_batch(next_reports);self.store.approve_day(next_day,comsys_closed=True)
        mix=company_mix(self.store,next_day)
        row=next(r['mtd'] for r in mix['rows'] if r['name']==ZERO_NAME)
        self.assertEqual((row['rooms'],row['adults'],row['total_revenue']),(1,2,240))
        self.assertEqual(mix['rows'][-1]['mtd']['total_revenue'],2550)
        self.assertEqual(mix['mtd_gap'],0)

if __name__=='__main__':unittest.main()
