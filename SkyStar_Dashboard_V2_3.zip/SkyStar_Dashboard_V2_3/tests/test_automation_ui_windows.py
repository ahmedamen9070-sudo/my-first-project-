"""Local setup/readiness behavior. No provider calls or Windows task execution."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from automation_windows import prepare_day,mark_ready
from automation_worker import init_config,load_config

class WindowsFolderHelpers(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.config=self.root/'config.json';init_config(self.config,{'database':str(self.root/'dev.sqlite')})
    def tearDown(self):self.tmp.cleanup()
    def test_prepare_requires_real_calendar_date(self):
        with self.assertRaises(ValueError):prepare_day(self.config,'../../outside')
        self.assertEqual(prepare_day(self.config,'2026-11-01').name,'2026-11-01')
    def test_marker_needs_files_and_explicit_night_confirmation(self):
        folder=prepare_day(self.config,'2026-11-01')
        with self.assertRaises(ValueError):mark_ready(self.config,'2026-11-01',night_confirmed=True)
        (folder/'report.xlsx').write_bytes(b'fixture marker only')
        with self.assertRaises(ValueError):mark_ready(self.config,'2026-11-01')
        self.assertFalse((folder/'READY.json').exists())
        path=mark_ready(self.config,'2026-11-01',night_confirmed=True,undated_confirmed=False)
        value=json.loads(path.read_text())
        self.assertTrue(value['night_run_confirmed']);self.assertFalse(value['undated_night_date_confirmed'])
        self.assertEqual(value['business_date'],'2026-11-01')
    def test_init_preserves_saved_settings_and_disables_connections(self):
        config=load_config(self.config)
        self.assertFalse(config['ai']['enabled']);self.assertFalse(config['whatsapp']['enabled'])
        raw=json.loads(self.config.read_text());raw['approval_mode']='auto_when_clean'
        self.config.write_text(json.dumps(raw))
        init_config(self.config,{'database':'SHOULD_NOT_REPLACE'})
        after=load_config(self.config)
        self.assertEqual(after['approval_mode'],'auto_when_clean')
        self.assertEqual(after['database'],str(self.root/'dev.sqlite'))

@unittest.skipUnless(os.environ.get('DISPLAY') or os.name=='nt','A Tk display is required')
class AutomationUi(unittest.TestCase):
    def setUp(self):
        from app import App
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.app=App(self.root/'demo.sqlite',demo=True);self.app.withdraw();self.app.date_var.set('2026-11-01')
        self.app.show('Automation');self.app.update()
    def tearDown(self):self.app.quit_app();self.tmp.cleanup()
    def test_open_page_does_not_create_setup_or_connect(self):
        self.assertFalse(self.app.automation_ui['config_path'].exists())
    def test_setup_targets_current_demo_database(self):
        self.app.automation_ui['initialize']()
        config=load_config(self.app.automation_ui['config_path'])
        self.assertEqual(config['database'],str(self.root/'demo.sqlite'))
        self.assertEqual(config['approval_mode'],'review')
        self.assertFalse(config['whatsapp']['enabled']);self.assertFalse(config['ai']['enabled'])
    def test_invalid_existing_setup_is_reported_without_overwrite(self):
        hooks=self.app.automation_ui;hooks['initialize']()
        hooks['config_path'].write_text('{invalid-json',encoding='utf-8')
        self.app.show('Automation');self.app.update()
        self.assertEqual(hooks['config_path'].read_text(),'{invalid-json')

    def test_ui_marker_requires_operator_confirmation(self):
        hooks=self.app.automation_ui;hooks['initialize']()
        folder=prepare_day(hooks['config_path'],'2026-11-01');(folder/'report.xlsx').write_bytes(b'test')
        with patch('automation_ui.messagebox.showwarning') as warning:
            hooks['mark_ready']();warning.assert_called_once()
        self.assertFalse((folder/'READY.json').exists())
        hooks['night_confirmed'].set(True);hooks['undated_confirmed'].set(True);hooks['mark_ready']()
        marker=json.loads((folder/'READY.json').read_text())
        self.assertTrue(marker['night_run_confirmed']);self.assertTrue(marker['undated_night_date_confirmed'])

if __name__=='__main__':unittest.main()
