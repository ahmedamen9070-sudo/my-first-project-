"""Shared release gates apply to GUI and unattended exports."""
from pathlib import Path
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from release_gate import release_gate
from engine import Store,parse_source
from import_bundle import stage_reports
from test_daily_sales_workflow import DAY,make_bundle


class ReleaseGate(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.store=Store(self.root/'data.sqlite')
    def tearDown(self):self.store.close();self.tmp.cleanup()
    def import_day(self,day=DAY):
        bundle=make_bundle(self.root/day,day)
        with stage_reports([bundle]) as paths:self.store.save_sources_batch([parse_source(p) for p in paths])
    def test_no_data_and_pending_are_not_released(self):
        codes={i['code'] for i in release_gate(self.store,DAY)['issues']}
        self.assertIn('NO_DATA',codes);self.assertIn('NOT_CLOSED',codes)
        self.import_day()
        self.assertFalse(release_gate(self.store,DAY)['allowed'])
    def test_clean_closed_day_releases_both_formats(self):
        self.import_day();self.store.approve_day(DAY,comsys_closed=True)
        self.assertTrue(release_gate(self.store,DAY)['allowed'])
        self.assertTrue(release_gate(self.store,DAY,require_pdf_layout=True)['allowed'])
    def test_pdf_capacity_is_not_an_excel_restriction(self):
        self.import_day();self.store.approve_day(DAY,comsys_closed=True)
        self.assertTrue(release_gate(self.store,DAY,company_row_count=16)['allowed'])
        self.assertIn('PDF_CAPACITY',{i['code'] for i in release_gate(self.store,DAY,True,16)['issues']})
    def test_import_alerts_block_previously_closed_day(self):
        self.import_day();self.store.approve_day(DAY,comsys_closed=True)
        self.store.add_import_alert(DAY,'wrong.xlsx','Wrong date remains unresolved')
        self.assertIn('IMPORT_ALERTS',{i['code'] for i in release_gate(self.store,DAY)['issues']})
    def test_missing_previous_day_blocks_final_mtd(self):
        self.import_day('2026-11-02');self.store.approve_day('2026-11-02',comsys_closed=True)
        self.assertIn('MTD_COVERAGE',{i['code'] for i in release_gate(self.store,'2026-11-02')['issues']})

if __name__=='__main__':unittest.main()
