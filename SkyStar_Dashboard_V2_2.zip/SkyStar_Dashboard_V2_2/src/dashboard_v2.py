"""Executive dashboard presentation. All figures come from the existing engine."""
import tkinter as tk
from datetime import date, timedelta
from engine import TYPE_NAMES, metrics
from mtd_detail import detail

BG='#F4F6FA'; INK='#14243B'; MUTED='#758298'; LINE='#E6EBF2'
NAVY='#12263F'; TEAL='#10A58D'; BLUE='#5085F5'; AMBER='#C68A29'; RED='#CF5364'
FONT='Segoe UI' if __import__('os').name=='nt' else 'Helvetica'

def money(value):
    return f'{value:,.2f}'


def render(app, day, sources, values, exceptions, month, status):
    """Render a scrolling dashboard, with no writes to the business database."""
    monthly=detail(app.store,day)
    financial=monthly['financial']
    has_revenue='Department Summary' in sources
    has_rooms='Rooms Situation' in sources
    priced=has_revenue and has_rooms
    eligibility=app.store.close_eligibility(day)
    required=set(TYPE_NAMES.values())
    imported=len(required.intersection(sources))
    issues=[x for x in exceptions if x['level'] in ('BLOCKER','WARNING')]
    blockers=len(eligibility['blockers'])
    warnings=len(eligibility['warnings'])
    open_cases=len(app.store.list_audit_cases(day=day,include_resolved=False))
    previous=(date.fromisoformat(day)-timedelta(days=1)).isoformat()
    previous_sources=app.store.day(previous)
    previous_revenue=metrics(previous_sources)['revenue'] if 'Department Summary' in previous_sources else None
    revenue_delta=None
    if has_revenue and previous_revenue is not None and previous_revenue>0:
        revenue_delta=(values['revenue']-previous_revenue)/previous_revenue*100
    shell=tk.Frame(app.content,bg=BG);shell.pack(fill='both',expand=True)
    canvas=tk.Canvas(shell,bg=BG,highlightthickness=0,takefocus=0)
    scrollbar=tk.ttk.Scrollbar(shell,orient='vertical',command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True)
    app.dashboard_canvas=canvas
    embedded=[]

    def draw(event=None):
        for widget in embedded:widget.destroy()
        embedded.clear();canvas.delete('all')
        width=max(canvas.winfo_width(),760)
        canvas.configure(scrollregion=(0,0,width,736))
        pad=3;gap=14;usable=width-2*pad
        def text(x,y,value,size=10,color=INK,bold=False,anchor='nw',maxwidth=None,tag=None):
            args={'text':value,'font':(FONT,size,'bold' if bold else 'normal'),'fill':color,'anchor':anchor}
            if maxwidth:args['width']=maxwidth
            if tag:args['tags']=(tag,)
            return canvas.create_text(x,y,**args)
        def rounded(x,y,w,h,fill,outline=None,r=14):
            points=[x+r,y,x+w-r,y,x+w,y,x+w,y+r,x+w,y+h-r,x+w,y+h,x+w-r,y+h,x+r,y+h,x,y+h,x,y+h-r,x,y+r,x,y]
            return canvas.create_polygon(points,smooth=True,splinesteps=24,fill=fill,outline=outline or fill)
        def panel(x,y,w,h):
            rounded(x,y+2,w,h,'#E9EDF4');rounded(x,y,w,h,'white')
        def button(x,y,w,label,target,primary=False):
            widget=tk.Button(canvas,text=label,command=lambda:app.show(target),font=(FONT,9,'bold'),
                             bg=TEAL if primary else '#EFF4F8',fg='white' if primary else INK,
                             activebackground='#087F70' if primary else '#E2EBF3',activeforeground='white' if primary else INK,
                             bd=0,relief='flat',cursor='hand2',takefocus=True)
            embedded.append(widget);canvas.create_window(x,y,anchor='nw',window=widget,width=w,height=34)
        text(pad,3,'YOUR HOTEL. AT A GLANCE.',9,MUTED,True)
        text(pad,25,'Executive overview',25,INK,True,tag='dashboard_v2_title')
        text(pad,66,f'{date.fromisoformat(day):%A, %d %B %Y}  |  Daily sales & revenue control',9,MUTED)
        rounded(width-162,10,158,28,'#E2F3EE',r=10)
        text(width-83,24,'DASHBOARD 2.2',8,TEAL,True,anchor='center')
        # Four equally sized KPI cards. Missing source data never appears as zero.
        cardw=(usable-gap*3)/4;top=102
        kpis=[('TOTAL HOTEL REVENUE',money(values['revenue']) if has_revenue else 'No data',
               'EGP  |  Today',NAVY,'white'),
              ('PAID OCCUPANCY',f"{values['occupancy']:.2f}%" if has_rooms else 'No data',
               f"{values['revenue_occupied']} / {values['available_for_sale']} operating rooms" if has_rooms else 'Room report needed','white',INK),
              ('AVERAGE DAILY RATE',money(values['adr']) if priced and values.get('revenue_occupied') else '—',
               'EGP / paid room' if priced and values.get('revenue_occupied') else 'Requires revenue & paid rooms','white',INK),
              ('REVPAR',money(values['revpar']) if priced and values.get('available_for_sale') else '—',
               'EGP / available room' if priced and values.get('available_for_sale') else 'Requires revenue & room capacity','white',INK)]
        for i,(label,value,subtitle,fill,fg) in enumerate(kpis):
            x=pad+i*(cardw+gap);rounded(x,top,cardw,130,fill)
            text(x+18,top+17,label,8,'#AFC3D9' if i==0 else MUTED,True)
            text(x+18,top+45,value,25 if cardw>225 else 21,fg,True,tag=('revenue_value','occupancy_value','adr_value','revpar_value')[i])
            text(x+18,top+89,subtitle,8,'#BDCEDF' if i==0 else MUTED,maxwidth=cardw-30)
            if i==0 and revenue_delta is not None:
                text(x+18,top+111,f'{revenue_delta:+.1f}% vs previous day',8,'#8FE2CC')
        # Revenue composition and an occupancy gauge use independent source data.
        y=250;leftw=(usable-gap)*.60;rightx=pad+leftw+gap;rightw=usable-leftw-gap
        panel(pad,y,leftw,260);panel(rightx,y,rightw,260)
        text(pad+20,y+18,'Revenue mix',14,INK,True)
        text(pad+20,y+45,'TODAY  /  EGP',8,MUTED,True)
        revenue_items=[('Rooms','rooms',BLUE),('Food','food',TEAL),('Beverage','beverage','#A18AE4'),('Other income','other','#E5AF61')]
        largest=max([abs(values[k]) for _,k,_ in revenue_items]+[1])
        all_positive=has_revenue and all(values[k]>=0 for _,k,_ in revenue_items) and values['revenue']>0
        for i,(label,key,color) in enumerate(revenue_items):
            rowy=y+78+i*42
            canvas.create_oval(pad+20,rowy+3,pad+27,rowy+10,fill=color,outline='')
            text(pad+36,rowy,label,9,INK,True)
            share=f"  ({values[key]/values['revenue']*100:.1f}%)" if all_positive else ''
            text(pad+leftw-20,rowy,(money(values[key])+share) if has_revenue else '—',9,INK,anchor='ne')
            rounded(pad+36,rowy+22,leftw-56,5,'#EFF2F7',r=2)
            if has_revenue and values[key]:
                rounded(pad+36,rowy+22,(leftw-56)*abs(values[key])/largest,5,color,r=2)
        text(rightx+20,y+18,'Rooms at a glance',14,INK,True)
        text(rightx+20,y+45,'PAID OCCUPANCY  /  OPERATING CAPACITY',8,MUTED,True)
        cx=rightx+rightw*.35;cy=y+151;radius=64
        canvas.create_oval(cx-radius,cy-radius,cx+radius,cy+radius,outline='#EDF1F6',width=13)
        if has_rooms:
            occupancy=values['occupancy'];extent=min(max(occupancy,0),100)*3.6
            if extent>=359.99:canvas.create_oval(cx-radius,cy-radius,cx+radius,cy+radius,outline=TEAL,width=13)
            elif extent>0:canvas.create_arc(cx-radius,cy-radius,cx+radius,cy+radius,start=90,extent=-extent,style='arc',outline=TEAL,width=13)
            text(cx,cy-8,f'{occupancy:.1f}%',23,INK,True,anchor='center')
            text(cx,cy+20,'paid occupancy',8,MUTED,anchor='center')
        else:
            text(cx,cy,'No data',14,MUTED,True,anchor='center')
        legendx=rightx+rightw*.64
        for i,(label,key,color) in enumerate([('Paid','revenue_occupied',TEAL),('Vacant','vacant','#A6B5C9'),('Comp.','comp','#A18AE4'),('House use','house_use','#E5AF61')]):
            ly=y+93+i*31
            canvas.create_oval(legendx,ly+4,legendx+6,ly+10,fill=color,outline='')
            text(legendx+13,ly,label,8,MUTED)
            text(rightx+rightw-18,ly,str(values[key]) if has_rooms else '—',10,INK,True,anchor='ne')
        # Bottom row: source completeness / release controls and real settlements.
        y=528;panel(pad,y,leftw,188);panel(rightx,y,rightw,188)
        text(pad+20,y+17,'Daily review',13,INK,True)
        label='CLOSED' if status=='Closed' else ('NEEDS ATTENTION' if blockers else 'PENDING REVIEW')
        color=TEAL if status=='Closed' else (RED if blockers else AMBER)
        text(pad+leftw-20,y+22,label,8,color,True,anchor='ne')
        text(pad+20,y+52,f'{imported} / {len(required)} reports',12,INK,True)
        text(pad+leftw-20,y+55,f'{blockers} blockers  ·  {warnings} warnings',9,MUTED,anchor='ne')
        rounded(pad+20,y+80,leftw-40,5,'#EEF2F6',r=2)
        if imported:rounded(pad+20,y+80,(leftw-40)*imported/len(required),5,TEAL,r=2)
        note=('F&B unavailable (documented); meal statistics incomplete.' if eligibility.get('unavailable') else issues[0]['code'].replace('_',' ') if issues else ('No source reports imported.' if not sources else 'Required sources loaded.' if not eligibility['missing'] else f"{len(eligibility['missing'])} required report(s) missing."))
        text(pad+20,y+101,note,8,MUTED,maxwidth=leftw-40)
        button(pad+20,y+139,(leftw-52)/2,'Review exceptions','Audit')
        button(pad+32+(leftw-52)/2,y+139,(leftw-52)/2,'Import / close day','Import',True)
        text(rightx+20,y+17,'Collections & approved MTD',12,INK,True)
        for i,(label,key) in enumerate([('Cash','cash'),('Cards','card'),('City ledger','city_ledger')]):
            rowy=y+51+i*26
            text(rightx+20,rowy,label,9,MUTED)
            text(rightx+rightw-20,rowy,money(values[key]) if has_revenue else '—',10,INK,True,anchor='ne')
        canvas.create_line(rightx+20,y+132,rightx+rightw-20,y+132,fill=LINE)
        mtd_text=money(financial['revenue']) if monthly['coverage']['Department Summary'] else '—'
        text(rightx+20,y+143,'Approved revenue',8,MUTED)
        text(rightx+rightw-20,y+140,mtd_text,13,TEAL,True,anchor='ne')
        text(rightx+20,y+165,f"{monthly['closed_days']} closed day(s)  |  "+('Complete coverage' if monthly['coverage_complete']['Department Summary'] else 'Partial / missing coverage'),8,MUTED)
        app.dashboard_summary={'date':day,'revenue':values['revenue'] if has_revenue else None,
                               'adr':values.get('adr') if priced and values.get('revenue_occupied') else None,
                               'revpar':values.get('revpar') if priced and values.get('available_for_sale') else None,
                               'required_reports':len(required),'imported_reports':imported,'open_cases':open_cases}
    canvas.bind('<Configure>',draw)
    canvas.bind('<MouseWheel>',lambda event:canvas.yview_scroll(-int(event.delta/120),'units'))
    canvas.bind('<Button-4>',lambda event:canvas.yview_scroll(-1,'units'))
    canvas.bind('<Button-5>',lambda event:canvas.yview_scroll(1,'units'))
    draw()
