"""Linux/Qt native-window and PDF smoke check; requires a display and desktop dependencies.
Run in an isolated environment with MADAR_DB pointing to a temporary database.
"""
import sys,os,json,time,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run,webview
from PyQt6 import QtPrintSupport,QtWidgets
from PIL import ImageGrab
output=Path(tempfile.mkdtemp(prefix='am-desktop-smoke-'))/'native-print.pdf'
real_create=webview.create_window
result={}
class PrintToTestPdf:
    def __init__(self,printer,parent):
        printer.setOutputFormat(QtPrintSupport.QPrinter.OutputFormat.PdfFormat)
        printer.setOutputFileName(str(output))
    def exec(self):return QtWidgets.QDialog.DialogCode.Accepted
QtPrintSupport.QPrintDialog=PrintToTestPdf

def create(*a,**kw):
    kw['confirm_close']=False
    w=real_create(*a,**kw)
    def evaluate(script):return json.loads(w.run_js('JSON.stringify('+script+')'))
    def loaded():
        try:
            for _ in range(100):
                if evaluate('document.querySelector("#loading").hidden'):break
                time.sleep(.1)
            else:raise AssertionError('Data bootstrap did not finish')
            result['hotel']=evaluate('document.querySelector(".hotel-copy h1").innerText')
            assert 'نيو بانوراما' in result['hotel'] and 'رمسيس' in result['hotel']
            assert evaluate('document.querySelector(".hotel-photo").naturalWidth')>100
            assert evaluate('document.querySelectorAll("#modules [data-page=invoices]").length')==0
            w.run_js('page("accounting")')
            for _ in range(100):
                if evaluate('accountingData !== null'):break
                time.sleep(.1)
            else:raise AssertionError('Native accounting page did not load')
            assert evaluate('accountingData.settings.base_currency')=='EGP'
            assert evaluate('accountingData.accounts.length')>=250
            assert evaluate('accountingData.accounts.filter(a=>a.parent_id===null).length')==8
            result['chart_accounts']=evaluate('accountingData.accounts.length')
            w.run_js('document.querySelector("#account-search").value="111000";renderAccountTree()')
            time.sleep(.2)
            ImageGrab.grab().save(str(Path(__file__).with_name('accounting-native.png')))
            w.run_js('page("supplier"); supplierTab("invoices")')
            assert evaluate('!document.querySelector("#invoices").hidden')
            w.run_js('page("dashboard")')
            time.sleep(.3)
            ImageGrab.grab().save(str(Path(__file__).with_name('desktop-test.png')))
            w.run_js('FiscalSetup.periods(2026)')
            for _ in range(100):
                if evaluate('document.querySelectorAll("#fiscal-setup-window[open] .fiscal-period-card").length===12'):break
                time.sleep(.1)
            else:raise AssertionError('Native fiscal period screen did not load')
            result['fiscal_periods']=evaluate('document.querySelectorAll(".fiscal-period-card").length')
            ImageGrab.grab().save(str(Path(__file__).with_name('fiscal-periods-native.png')))
            w.run_js('document.querySelector("[data-fiscal-action=close]").click()')
            w.run_js('FiscalSetup.taxes()')
            for _ in range(100):
                if evaluate('Boolean(document.querySelector("#fiscal-setup-window[open] [data-fiscal-action=save-tax-settings]"))'):break
                time.sleep(.1)
            else:raise AssertionError('Native tax setup did not load')
            result['tax_setup']=evaluate('document.querySelector("#fiscal-title").innerText')
            ImageGrab.grab().save(str(Path(__file__).with_name('tax-setup-native.png')))
            w.run_js('document.querySelector("[data-fiscal-action=close]").click()')
            w.run_js('SupplierSettlement.reconciliation()')
            for _ in range(100):
                if evaluate('Boolean(document.querySelector("#supplier-settlement-window[open] .ss-result"))'):break
                time.sleep(.1)
            else:raise AssertionError('Native supplier reconciliation did not load')
            result['reconciliation']=evaluate('document.querySelector("#ss-title").innerText')
            assert 'مطابقة' in result['reconciliation']
            ImageGrab.grab().save(str(Path(__file__).with_name('settlement-native.png')))
            w.run_js('document.querySelector("[data-ss-action=print-reconciliation]").click()')
            for _ in range(100):
                if output.exists() and output.stat().st_size>100:break
                time.sleep(.1)
            else:raise AssertionError('Native PDF was not created')
            assert output.read_bytes().startswith(b'%PDF')
            result['pdf_bytes']=output.stat().st_size
            w.run_js('document.querySelector("[data-ss-action=close]").click()')
            w.run_js('LedgerReports.trialBalance({from_date:"2026-01-01",to_date:"2026-12-31",include_zero:true})')
            for _ in range(100):
                if evaluate('Boolean(document.querySelector("#ledger-reports-window[open] .lr-trial-table"))'):break
                time.sleep(.1)
            else:raise AssertionError('Native trial balance did not load')
            result['trial_balance']=evaluate('document.querySelector("#ledger-reports-title").innerText')
            assert 'ميزان المراجعة' in result['trial_balance']
            ImageGrab.grab().save(str(Path(__file__).with_name('trial-balance-native.png')))
            cash=evaluate('accountingData.accounts.find(a=>a.code==="111002").id')
            w.run_js('LedgerReports.ledger('+str(cash)+',{from_date:"2026-01-01",to_date:"2026-12-31"})')
            for _ in range(100):
                if evaluate('document.querySelector("#ledger-reports-title").innerText.includes("حركة الحساب")'):break
                time.sleep(.1)
            else:raise AssertionError('Native account ledger did not load')
            output.unlink()
            w.run_js('document.querySelector("#ledger-reports-window [data-ledger-action=print]").click()')
            for _ in range(100):
                if output.exists() and output.stat().st_size>100:break
                time.sleep(.1)
            else:raise AssertionError('Native ledger PDF was not created')
            assert output.read_bytes().startswith(b'%PDF')
            result['ledger_pdf_bytes']=output.stat().st_size
            result['ok']=True
        except BaseException as e:result['error']=str(e)
        finally:w.destroy()
    w.events.loaded+=loaded
    return w
webview.create_window=create
code=run.main()
print('NATIVE_RESULT',json.dumps(result,ensure_ascii=False),flush=True)
if code or not result.get('ok'):raise SystemExit(1)
