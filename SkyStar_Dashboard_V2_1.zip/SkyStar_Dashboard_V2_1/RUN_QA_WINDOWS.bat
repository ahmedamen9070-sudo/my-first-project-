@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
%PY% -m unittest discover -s tests -v
if errorlevel 1 (
  echo Some QA tests failed. Do not continue before checking the output.
) else (
  echo QA regression passed (optional developer-only tests may be skipped if dependencies are absent).
)
pause
