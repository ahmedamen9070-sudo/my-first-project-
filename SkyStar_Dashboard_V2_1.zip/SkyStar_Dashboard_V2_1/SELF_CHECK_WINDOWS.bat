@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
 py -3 src\self_check.py
) else (
 python src\self_check.py
)
echo.
pause
