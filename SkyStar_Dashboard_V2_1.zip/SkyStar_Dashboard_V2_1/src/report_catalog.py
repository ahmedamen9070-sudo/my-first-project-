"""Extensible report catalog. Only Daily Sales is enabled now.

Future management reports can register an id, title and exporter without changing
Comsys source parsing, shared source storage or the management PDF layout.
"""
REPORTS = {
    "daily_sales": {"name": "Sky Star Daily Sales", "enabled": True,
                    "pdf_module": "exports_pdf_v9", "xlsx_module": "native_xlsx"},
}

def register_report(identifier, name, pdf_module, xlsx_module=None):
    if not identifier or identifier in REPORTS:
        raise ValueError("Invalid or duplicate report type")
    REPORTS[identifier] = {"name": name, "enabled": True,
                           "pdf_module": pdf_module, "xlsx_module": xlsx_module}
