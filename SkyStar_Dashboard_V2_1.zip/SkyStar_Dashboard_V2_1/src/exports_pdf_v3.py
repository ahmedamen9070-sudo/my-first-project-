"""Boardroom-quality management PDF and separate financial audit PDF."""
from __future__ import annotations
from html import escape
from pathlib import Path
import re
from datetime import date
from engine import metrics,checks,monthly,generate_commentary

NAVY='#13263F';DEEP='#0C1C31';BLUE='#225B9B';TEAL='#087F70';MUTED='#6E7E8F';RULE='#D8E3EC';PALE='#EFF4F9';RED='#A34D45'

def money(value):return f'{float(value or 0):,.2f}'

def mapped_codes(src,field):
    c=src.get('Department Summary',{}).get('codes',[])
    mapping=[('Rooms', {101,102,103,104,105,199,903}),('Food',{201,202,203,204,205,250,251,252,299}),
             ('Beverage',{253,301,302,303,304,305,399}),('Other',{350,401,402,403,499,501,502,503,550,590})]
    return [(label,round(sum(z[field] for z in c if z['code'] in group),2)) for label,group in mapping]

def pdf_export(store,d,path,mode='management'):
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,HRFlowable,KeepTogether
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT,TA_RIGHT,TA_CENTER
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.colors import HexColor
    src=store.day(d);m=metrics(src);ex=checks(src);mt=monthly(store,d);state=store.status(d)
    combined=mode=='management';issues=[x for x in ex if x['level'] in ('WARNING','BLOCKER')]
    fname=Path(path);fname.parent.mkdir(parents=True,exist_ok=True)
    doc=SimpleDocTemplate(str(fname),pagesize=A4,leftMargin=37,rightMargin=37,topMargin=61,bottomMargin=48,
                          title='Sky Star Hotel | '+('Daily Management Sales Report' if combined else 'Internal Audit Control Report'),author='Sky Star Hotel - Finance')
    width=A4[0]-74
    ss={
       'section':ParagraphStyle('section',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=HexColor(NAVY),spaceBefore=11,spaceAfter=9),
       'sub':ParagraphStyle('sub',fontName='Helvetica-Bold',fontSize=10.5,leading=14,textColor=HexColor(BLUE),spaceBefore=10,spaceAfter=7),
       'body':ParagraphStyle('body',fontName='Helvetica',fontSize=9.1,leading=14.5,textColor=HexColor(NAVY),spaceAfter=7),
       'small':ParagraphStyle('small',fontName='Helvetica',fontSize=7.7,leading=11,textColor=HexColor(MUTED)),
       'cell':ParagraphStyle('cell',fontName='Helvetica',fontSize=8.1,leading=11,textColor=HexColor(NAVY)),
       'cellhead':ParagraphStyle('cellhead',fontName='Helvetica-Bold',fontSize=8,leading=11,textColor=colors.white),
       'num':ParagraphStyle('num',fontName='Helvetica',fontSize=8.1,leading=11,alignment=TA_RIGHT,textColor=HexColor(NAVY)),
       'numhead':ParagraphStyle('numhead',fontName='Helvetica-Bold',fontSize=8,leading=11,alignment=TA_RIGHT,textColor=colors.white),
       'klabel':ParagraphStyle('klabel',fontName='Helvetica-Bold',fontSize=7.4,leading=10,textColor=HexColor(MUTED)),
       'kvalue':ParagraphStyle('kvalue',fontName='Helvetica-Bold',fontSize=17,leading=21,textColor=HexColor(NAVY)),
       'lead':ParagraphStyle('lead',fontName='Helvetica',fontSize=10,leading=16,textColor=HexColor(NAVY),spaceAfter=8),
       'warn':ParagraphStyle('warn',fontName='Helvetica-Bold',fontSize=8.5,leading=12,textColor=HexColor(RED))
    }
    def para(text,style='body'):
        return Paragraph(escape(str(text)).replace('\n','<br/>'),ss[style])
    def section(text):story.append(para(text,'section'))
    def sub(text):story.append(para(text,'sub'))
    def gap(v=10):story.append(Spacer(1,v))
    def tbl(columns,rows,widths=None,numbercols=None,subtotal_indices=()):
        numbercols=set(numbercols or ())
        data=[[para(h,'numhead' if i in numbercols else 'cellhead') for i,h in enumerate(columns)]]
        for row in rows:
            data.append([para(v,'num' if i in numbercols else 'cell') for i,v in enumerate(row)])
        t=Table(data,colWidths=widths or [width/len(columns)]*len(columns),repeatRows=1,hAlign='LEFT')
        rules=[('BACKGROUND',(0,0),(-1,0),HexColor(NAVY)),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
               ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,HexColor('#F4F7FA')]),
               ('TOPPADDING',(0,0),(-1,0),11),('BOTTOMPADDING',(0,0),(-1,0),10),
               ('TOPPADDING',(0,1),(-1,-1),6),('BOTTOMPADDING',(0,1),(-1,-1),6),
               ('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),
               ('LINEBELOW',(0,-1),(-1,-1),.5,HexColor(RULE))]
        for ix in subtotal_indices:
            if 0<=ix<len(rows):rules.extend([('BACKGROUND',(0,ix+1),(-1,ix+1),HexColor('#E5EFF7')),
                                             ('LINEABOVE',(0,ix+1),(-1,ix+1),.8,HexColor('#B4CBDD'))])
        t.setStyle(TableStyle(rules));story.append(t)
    def hero(kpis):
        data=[]
        for name,value,extra in kpis:
            data.append([para(name.upper(),'klabel'),para(value,'kvalue'),para(extra,'small')])
        cards=[]
        for card in data:
            t=Table([[card[0]],[card[1]],[card[2]]],colWidths=[(width-18)/3],rowHeights=[16,28,24])
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),HexColor('#F1F5FA')),
                ('LINEABOVE',(0,0),(-1,0),3,HexColor(TEAL)),('TOPPADDING',(0,0),(-1,-1),8),('LEFTPADDING',(0,0),(-1,-1),12),
                ('BOTTOMPADDING',(0,-1),(-1,-1),9)]))
            cards.append(t)
        row=Table([[cards[0],cards[1],cards[2]]],colWidths=[width/3]*3)
        row.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),6)]))
        story.append(row)
    def newpage():story.append(PageBreak())
    def footer(c,doc):
        c.saveState();W,H=A4
        # band logo and right status strip
        c.setFillColor(HexColor(NAVY));c.rect(0,H-43,W,43,fill=1,stroke=0)
        c.setFont('Helvetica-Bold',13);c.setFillColor(colors.white);c.drawString(37,H-26,'SKY STAR HOTEL')
        c.setFont('Helvetica',8.5);c.setFillColor(HexColor('#BBD3E7'));c.drawRightString(W-37,H-25,'FINANCE  /  DAILY CONTROL')
        c.setStrokeColor(HexColor(RULE));c.line(37,39,W-37,39)
        c.setFont('Helvetica',8);c.setFillColor(HexColor(MUTED))
        c.drawString(37,25,'CONFIDENTIAL  |  FOR INTERNAL MANAGEMENT USE ONLY')
        c.drawRightString(W-37,25,f'Business date {d}  |  {doc.page}')
        if state!='Closed' or not mt['complete'] or issues or store.path.name.startswith('demo'):
            c.setFillColor(HexColor(RED));c.setFont('Helvetica-Bold',8)
            c.drawRightString(W-37,H-54,'PREVIEW / REVIEW REQUIRED')
        c.restoreState()
    story=[]
    story.append(para('DAILY SALES & MANAGEMENT REPORT' if combined else 'FINANCE AUDIT & RECONCILIATION','section'))
    story.append(para(f'BUSINESS DATE  {d}     |     STATUS  {state.upper()}     |     '+('MANAGEMENT PACK' if combined else 'INTERNAL REVIEW COPY'),'small'))
    gap(13)
    if combined:
        hero([('Hotel Revenue',money(m['revenue']) if 'Department Summary' in src else 'N/A','Daily operating revenue'),
              ('Occupancy',f'{m["occupancy"]:.2f}%' if 'occupancy' in m else 'N/A','Paid occupied / operating'),
              ('ADR',money(m.get('adr')) if 'adr' in m else 'N/A','Room revenue / paid rooms')])
        gap(17)
        section('01  /  EXECUTIVE POSITION')
        tbl(['Key management indicator','Today','Context'],[
            ('Room revenue',money(m['rooms']),'Excludes separately mapped Transportation 904'),
            ('Food revenue',money(m['food']),'Restaurant and meal-package allocation'),
            ('Beverage revenue',money(m['beverage']),'Includes All Inclusive beverage allocation'),
            ('Other income',money(m['other']),'Before code 599 adjustment'),
            ('TOTAL HOTEL REVENUE',money(m['revenue']),'Primary Daily Sales presentation'),
            ('Service charges and taxes',money(m['taxes']),'Not added to operating revenue'),
            ('Cash + cards',money(m['cash']+m['card']),'Actual recorded collection methods'),
            ('City Ledger',money(m['city_ledger']),'Transfer to receivables; not collected cash')],
            [208,122,191],{1},{4})
        gap(14)
        section('02  /  MANAGEMENT STATUS')
        story.append(para('Financial controls: '+str(len([x for x in ex if x['level']=='BLOCKER']))+' blocker(s), '+str(len([x for x in ex if x['level']=='WARNING']))+' warning(s).'))
        if mt['complete']:story.append(para(f'MTD coverage confirmed: {mt["days_closed"]} closed dates through {d}.'))
        else:story.append(para(f'MTD INCOMPLETE: {len(mt["missing"])} business dates missing or not approved from the first of the month through {d}. The Comsys MTD reference is not presented as an approved rebuilt monthly total.','warn'))
        if issues:
            story.append(para('Priority follow-up: '+issues[0]['message']))
        newpage()
        section('03  /  REVENUE ANALYSIS')
        if 'Department Summary' in src:
            today=mapped_codes(src,'today');mm=mapped_codes(src,'mtd');yy=mapped_codes(src,'ytd')
            tbl(['Business unit','Today','Comsys MTD*','Comsys YTD*'],[(x[0],money(x[1]),money(mm[i][1]),money(yy[i][1])) for i,x in enumerate(today)]+
                [('TOTAL HOTEL REVENUE',money(sum(z[1] for z in today)),money(sum(z[1] for z in mm)),money(sum(z[1] for z in yy)))],
                [175,110,118,118],{1,2,3},{4})
            gap(8)
            story.append(para('* MTD / YTD above are source reference values from Comsys Department Summary; only approved closed-day entries are eligible for independently calculated monthly totals.','small'))
            gap(14)
            sub('Posting and classification bridge')
            tbl(['Classification','Today','Treatment'],[
                ('Income adjustment 599',money(m['adjustment']),'Shown separately from hotel operating revenue'),
                ('Transportation 904',money(m['transportation']),'Excluded from Rooms Revenue'),
                ('Net posted revenue',money(m['net_revenue']),'Revenue plus stated adjustments / allocation'),
                ('Service charges / taxes',money(m['taxes']),'Pass-through posting, not F&B or Room Revenue')],[174,112,235],{1},{2})
        else:story.append(para('Department Summary not imported; revenue breakdown cannot be substantiated.','warn'))
        gap(14)
        section('04  /  ROOMS & CAPACITY')
        if 'Rooms Situation' in src:
            tbl(['Inventory & operational measure','Today','Interpretation'],[
                ('Physical hotel rooms',m['physical_count'],'Full inventory including out-of-order rooms'),
                ('Out of Order rooms',m['ooo_in_rooms'],'Already deducted from operating supply'),
                ('Operating rooms',m['available_for_sale'],'Physical rooms less OOO'),
                ('Paid occupied rooms',m['revenue_occupied'],'Excludes complimentary and house use'),
                ('Vacant rooms',m['vacant'],'Rooms not occupied'),
                ('Complimentary / House Use',f'{m["comp"]} / {m["house_use"]}','Non-revenue occupied inventory'),
                ('Paid occupancy',f'{m["occupancy"]:.2f}%','Paid occupied / operating capacity'),
                ('ADR / RevPAR',f'{money(m["adr"])} / {money(m["revpar"])}','Weighted on the business date')],[200,106,215],{1})
        else:story.append(para('Rooms Situation missing; occupancy cannot be validated.','warn'))
        newpage()
        section('05  /  COMPANY PERFORMANCE & F&B')
        cp=src.get('Company Revenue',{});companies=cp.get('companies',[])
        if companies:
            sorted_co=sorted(companies,key=lambda x:x['total_revenue'],reverse=True)
            tbl(['Company / account','Rooms','Room revenue','F&B','Total'],[(x['company'][:35],x['rooms'],money(x['room_revenue']),money(x['fnb_revenue']),money(x['total_revenue'])) for x in sorted_co[:9]],
                [163,55,101,92,110],{1,2,3,4})
            story.append(para('Top accounts only. Company revenue classifies the same hotel sales; it must not be added again to the hotel total.','small'))
        else:story.append(para('Company Revenue report not provided.'))
        gap(18)
        sub('Meal plans and included beverages')
        fb=src.get('F&B Report',{})
        if fb.get('patterns'):
            tbl(['Meal plan','Rooms','Pax','Included beverage rule'],[(x,v,fb.get('adults',{}).get(x,0)+fb.get('children',{}).get(x,0),
                'Soft included; hard chargeable' if x=='AN' else 'Soft + hard included' if x=='HAN' else 'Subject to guest entitlement') for x,v in fb['patterns'].items()],
                [130,66,65,260],{1,2})
            story.append(para('Entitlements are not actual drinks served and are not new chargeable sales. BB, HB, AN, HAN policies are preserved in controls.','small'))
        else:story.append(para('F&B entitlement details not imported.'))
        gap(16)
        section('06  /  CONTROL OBSERVATIONS')
        if issues:
            tbl(['Priority','Unresolved observation'],[(x['level'],x['message']) for x in issues[:6]],[84,437])
        else:story.append(para('No material differences in the implemented control checks. This is not a full transaction-level audit.'))
        newpage()
        section('07  /  FINANCIAL POSITION & CASHIER SETTLEMENTS')
        tbl(['Settlement or movement','Amount','Meaning'],[
            ('Cash settlements',money(m['cash']),'Cash received / settled'),('Credit cards',money(m['card']),'Card settlement postings'),
            ('City Ledger',money(m['city_ledger']),'Receivable transfer, not bank cash'),
            ('TOTAL SETTLEMENTS',money(m['total_settlements']),'Cash + cards + city ledger'),
            ('Net posted revenue',money(m['net_revenue']),'After adjustment / transportation'),
            ('Tax & service charges',money(m['taxes']),'Excluded from operating revenue'),
            ('Comsys posting movement',money(m['grand_total']),'Not profit or loss'),
            ('Posting difference',money(m.get('checks',{}).get('posting_net_movement',0)),'Zero required on implemented balance check')],
            [180,120,221],{1},{3})
        gap(12)
        if m.get('guest_ledger_closing') is not None:
            story.append(para(f'Guest Ledger snapshot at reporting date: {money(m["guest_ledger_closing"])}. Closing balances are not accumulated across days.'))
        section('08  /  MONTH-TO-DATE COVERAGE')
        if mt['complete']:
            tbl(['MTD', 'Amount'], [('Approved revenue',money(mt.get('revenue'))),('Approved room revenue',money(mt.get('rooms'))),('Approved occupied room nights',mt['occupied_room_nights']),('Weighted occupancy',f'{mt["occupancy"]:.2f}%')],[320,201],{1})
        else:
            story.append(para(f'Month-to-date report is INCOMPLETE: {len(mt["missing"])} date(s) are unapproved or missing. Closed-day subtotal is NOT the final month-to-date result.','warn'))
            story.append(para('Missing/open dates: '+', '.join(mt['missing'][:10])+(' ...' if len(mt['missing'])>10 else ''),'small'))
        newpage()
        section('09  /  WRITTEN MANAGEMENT COMMENTARY')
        written=store.notes(d)[0] or generate_commentary(store,d)
        for line in written.splitlines():
            line=line.strip()
            if not line:gap(5)
            elif re.match(r'^\d+\.\s',line):sub(line)
            else:story.append(para(line))
        gap(9)
        story.append(para('Management review is required before distribution. Source exceptions remain in the internal Audit PDF.','small'))
    else:
        section('01  /  SOURCE & CLOSING CONTROLS')
        tbl(['Control metric','Value'],[('Business date',d),('Approval state',state),('Imported source reports',len(src)),('Blockers',len([x for x in ex if x['level']=='BLOCKER'])),('Warnings',len([x for x in ex if x['level']=='WARNING'])),('MTD coverage','COMPLETE' if mt['complete'] else 'INCOMPLETE')],[310,211],{1})
        gap(14)
        sub('All imported reports')
        tbl(['Report name','Source filename','Timestamp'],[(str(x[0]),str(x[1]),str(x[2])[:16]) for x in store.sources(d)],[168,240,113])
        newpage()
        section('02  /  DETAILED AUDIT FINDINGS')
        if ex:tbl(['Level','Code','Evidence and unresolved finding'],[(x['level'],x['code'],x['message']) for x in ex],[75,155,291])
        else:story.append(para('No exceptions in the implemented checks.'))
        gap(13)
        sub('Cashier by settlement method')
        cs=src.get('Cashier Summary',{}).get('people',[])
        if cs:tbl(['Cashier','Cash','Card','C/L','Transfer'],[(x['cashier'],money(x['cash']),money(x['card']),money(x['city_ledger']),money(x['transfer_activity'])) for x in cs],
                  [136,88,90,116,91],{1,2,3,4})
        else:story.append(para('Cashier Summary not imported.'))
        newpage()
        section('03  /  SOURCE CLASSIFICATION & FOLLOW-UP')
        dep=src.get('Department Summary',{}).get('codes',[])
        if dep:
            tbl(['Code','Department','Today','MTD source'],[(x['code'],x['label'][:37],money(x['today']),money(x['mtd'])) for x in dep],
                [62,241,109,109],{2,3})
        gap(12)
        sub('Auditor note')
        story.append(para(store.notes(d)[1] or 'No auditor follow-up note was recorded for this business date.'))
        gap(15)
        story.append(para('Original Comsys evidence remains retained in the local dated import register. Voided transactions must not be deducted twice from net sales; posting-item reallocations are non-additive.','small'))
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return path
