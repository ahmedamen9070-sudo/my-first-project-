"""Financial pack exports. XLSX uses artifact_tool, PDF uses ReportLab."""
from __future__ import annotations
from pathlib import Path
import re
from html import escape
from engine import metrics,checks,monthly,generate_commentary,money
from mtd_detail import detail as mtd_detail, values_for_fnb

NAVY='#172D46';BLUE='#2463AA';LIGHT='#EAF1F7';GRAY='#64748B'

def workbook_export(store,d,path):
    try:
        from artifact_tool import Workbook,SpreadsheetFile
    except ImportError:
        from native_xlsx import native_excel_export
        return native_excel_export(store,d,path)
    wb=Workbook.create();sources=store.day(d);m=metrics(sources);ex=checks(sources);mt=monthly(store,d)
    report=wb.worksheets.add('Daily Sales')
    report.get_range('A1:F2').merge_cells() if False else None
    report.merge_cells('A1:F1');report.get_range('A1').values=[['SKY STAR HOTEL  |  DAILY SALES']]
    report.merge_cells('A2:F2');report.get_range('A2').values=[[f'Business Date: {d}   |   {store.status(d).upper()}   |   INTERNAL MANAGEMENT REVIEW']]
    report.get_range('A4:C4').values=[['REVENUE','TODAY','SOURCE / CLASSIFICATION']]
    rows=[('Room Revenue',m['rooms'],'Comsys: 101/102 etc; excludes 904 transportation'),
          ('Food Revenue',m['food'],'Food and meal packages'),
          ('Beverage Revenue',m['beverage'],'Includes All Inclusive beverage allocation'),
          ('Other Income',m['other'],'Before code 599 adjustment'),
          ('HOTEL REVENUE',None,'Daily Sales basis'),
          ('Other Income Adjustment',m['adjustment'],'599 adjustment separately'),
          ('Transportation (separate)',m['transportation'],'904 excluded from room rate'),
          ('NET POSTED REVENUE',None,'After visible adjustments'),
          ('Taxes & Service Charges',m['taxes'],'701-705'),
          ('Cash Settlements',m['cash'],'801-803, absolute settlement'),
          ('Card Settlements',m['card'],'811-814, absolute settlement'),
          ('City Ledger Settlements',m['city_ledger'],'821-822, NOT bank cash'),
          ('POSTING MOVEMENT (Comsys)',m['grand_total'],'Not hotel profit or revenue')]
    for i,row in enumerate(rows,5):
        report.get_range(f'A{i}:C{i}').values=[[row[0],row[1] if row[1] is not None else None,row[2]]]
    report.get_range('B9').formulas=[['=SUM(B5:B8)']]
    report.get_range('B12').formulas=[['=SUM(B9:B11)']]
    report.get_range('A20:C20').values=[['ROOMS & OPERATIONAL KPI','TODAY','DEFINITION']]
    roomrows=[('Physical Hotel Rooms',m.get('physical_count'), 'Gross physical inventory'),
              ('Out of Order',m.get('ooo_in_rooms'),'Already removed from sellable inventory'),
              ('Operating Rooms',m.get('available_for_sale'),'Physical less OOO'),
              ('Revenue Occupied',m.get('revenue_occupied'),'Paid occupied rooms'),
              ('Vacant',m.get('vacant'),'Unoccupied'),
              ('Complimentary',m.get('comp'),'Included within operating rooms'),
              ('House Use',m.get('house_use'),'Included within operating rooms'),
              ('Paid Occupancy %',None,'Revenue occupied / operating rooms'),
              ('ADR',None,'Room revenue / revenue occupied'),
              ('RevPAR',None,'Room revenue / operating rooms')]
    for i,r in enumerate(roomrows,21):report.get_range(f'A{i}:C{i}').values=[[r[0],r[1],r[2]]]
    report.get_range('B28').formulas=[['=IFERROR(B24/B23*100,0)']]
    report.get_range('B29').formulas=[['=IFERROR(B5/B24,0)']]
    report.get_range('B30').formulas=[['=IFERROR(B5/B23,0)']]
    report.get_range('A32:C32').values=[['SETTLEMENT RECONCILIATION','VALUE','CONTROL']]
    report.get_range('A33:C35').values=[['Settlements (total)',m['total_settlements'],'Cash + Cards + City Ledger'],
                                     ['Recomputed Posting Movement',None,'Posted revenue + taxes - settlements'],
                                     ['Difference vs Comsys',None,'Must equal zero']]
    report.get_range('B34').formulas=[['=B12+B13-B33']]
    report.get_range('B35').formulas=[['=B34-B17']]
    report.get_range('A37:C37').values=[['SOURCE COMPLETENESS','STATUS','DETAIL']]
    for i,name in enumerate(('Department Summary','Cashier Summary','Rooms Situation','Company Revenue','Posting Summary','F&B Report','Voided Transactions'),38):
        report.get_range(f'A{i}:C{i}').values=[[name,'Imported' if name in sources else 'Not uploaded', '']]
    # Monthly overview: dates and stored closing status are explicitly separated.
    sh=wb.worksheets.add('MTD & Coverage')
    sh.merge_cells('A1:G1');sh.get_range('A1').values=[['MONTH-TO-DATE - APPROVED CLOSED DAYS ONLY']]
    sh.merge_cells('A2:G2');sh.get_range('A2').values=[[f'Through {d} | Status: '+('COMPLETE' if mt['complete'] else f'INCOMPLETE - {len(mt["missing"])} DAYS MISSING')]]
    sh.get_range('A4:G4').values=[['Date','State','Rooms','Food','Beverage','Other','Hotel Revenue']]
    first=d[:8]+'01'; from datetime import datetime,timedelta
    dt=datetime.strptime(first,'%Y-%m-%d').date(); end=datetime.strptime(d,'%Y-%m-%d').date(); row=5
    while dt<=end:
        dd=dt.isoformat(); closed=store.status(dd)=='Closed' and 'Department Summary' in store.day(dd)
        data=metrics(store.day(dd)) if closed else None
        sh.get_range(f'A{row}:G{row}').values=[[dd,'Closed' if closed else 'MISSING / NOT CLOSED',
             data['rooms'] if data else None,data['food'] if data else None,data['beverage'] if data else None,
             data['other'] if data else None,None]]
        if closed:sh.get_range(f'G{row}').formulas=[[f'=SUM(C{row}:F{row})']]
        row+=1;dt+=timedelta(days=1)
    sh.get_range(f'A{row}:B{row}').values=[['MTD TOTAL',len([1 for _ in range(5,row)])-len(mt['missing'])]]
    for col in 'CDEFG':sh.get_range(f'{col}{row}').formulas=[[f'=SUM({col}5:{col}{row-1})']]
    sh.get_range(f'A{row+2}:B{row+2}').values=[['Completeness','COMPLETE' if mt['complete'] else 'INCOMPLETE - DO NOT SEND AS FINAL']]
    sh.get_range(f'A{row+3}:B{row+3}').values=[['Note','Comsys MTD is a reference, not automatically added on top of each daily movement.']]
    co=wb.worksheets.add('Company Revenue')
    co.merge_cells('A1:E1');co.get_range('A1').values=[['COMPANY REVENUE | CLASSIFICATION - NOT EXTRA SALES']]
    co.get_range('A3:E3').values=[['Company','Rooms','Room Revenue','F&B Revenue','Total Revenue']]
    companies=sources.get('Company Revenue',{}).get('companies',[])
    for i,x in enumerate(companies,4):co.get_range(f'A{i}:E{i}').values=[[x['company'],x['rooms'],x['room_revenue'],x['fnb_revenue'],x['total_revenue']]]
    if companies:
        idx=4+len(companies)
        co.get_range(f'A{idx}:B{idx}').values=[['TOTAL',None]]
        for col in 'BCDE':co.get_range(f'{col}{idx}').formulas=[[f'=SUM({col}4:{col}{idx-1})']]
    a=wb.worksheets.add('Audit & Sources')
    a.merge_cells('A1:D1');a.get_range('A1').values=[['AUDIT EXCEPTIONS - OPEN ITEMS RETAINED']]
    a.get_range('A3:C3').values=[['Severity','Control ID','Finding / Explanation']]
    if ex:
        a.get_range_by_indexes(3,0,len(ex),3).values=[[x['level'],x['code'],x['message']] for x in ex]
    ar=6+len(ex);a.get_range(f'A{ar}:C{ar}').values=[['Business Date','Report Type','Filename']]
    for i,entry in enumerate(store.sources(d),ar+1):a.get_range(f'A{i}:C{i}').values=[[d,entry[0],entry[1]]]
    review=store.notes(d)[1]
    a.get_range(f'A{ar+len(store.sources(d))+3}:B{ar+len(store.sources(d))+3}').values=[['Auditor Note',review[:1000]]]
    # Consistent Today/Approved-MTD tables for all indicators, with report-specific coverage.
    detail_m=mtd_detail(store,d);cov=detail_m['coverage'];fm=detail_m['financial'];rm=detail_m['rooms']
    dd=wb.worksheets.add('All Today & MTD')
    dd.get_range('A1:D1').values=[['SKY STAR DAILY SALES | ALL DAILY & MTD',None,None,None]]
    dd.get_range('A2:D2').values=[[f'Business date: {d}',f'Revenue {cov["Department Summary"]}/{detail_m["expected"]}',f'Rooms {cov["Rooms Situation"]}/{detail_m["expected"]}',f'Meal {cov["F&B Report"]}/{detail_m["expected"]} / Company {cov["Company Revenue"]}/{detail_m["expected"]}']]
    dd.get_range('A4:D4').values=[['Financial line','Today','Approved MTD','Basis / caution']]
    keys=[('Rooms','rooms'),('Food','food'),('Beverage','beverage'),('Other','other'),('HOTEL REVENUE','revenue'),
          ('Adjustments','adjustment'),('Transportation','transportation'),('Service & Taxes','taxes'),('Net Posted Revenue','net_revenue'),
          ('Cash','cash'),('Credit Cards','card'),('City Ledger','city_ledger'),('Settlements Total','total_settlements'),('Net Ledger Movement','grand_total')]
    for i,(label,k) in enumerate(keys,5):
        dd.get_range(f'A{i}:D{i}').values=[[label,m.get(k) if 'Department Summary' in sources else None,
                 fm.get(k) if cov['Department Summary'] else None,'Sum of approved daily flows (never add cash to revenue)']]
    dd.get_range('A20:D20').values=[['Rooms / KPI','Today','Approved MTD','Basis']]
    rkeys=[('Physical inventory','physical_count'),('OOO / room-nights','ooo_in_rooms'),('Operating / room-nights','available_for_sale'),
           ('Revenue occupied / room-nights','revenue_occupied'),('Vacant / room-nights','vacant'),('Complimentary / room-nights','comp'),
           ('House Use / room-nights','house_use'),('Paid Occupancy (%)','occupancy'),('ADR','adr'),('RevPAR','revpar')]
    for i,(label,k) in enumerate(rkeys,21):
        dd.get_range(f'A{i}:D{i}').values=[[label,m.get(k) if 'Rooms Situation' in sources else None,
            rm.get(k) if cov['Rooms Situation'] else None,'Last approved snapshot' if k=='physical_count' else 'Weighted from period sums' if k in ('occupancy','adr','revpar') else 'Room-night totals']]
    dd.get_range('A32:D32').values=[['Guest Ledger (snapshot)',m.get('guest_ledger_closing'),detail_m['guest_ledger_last_balance'],'Not a monthly sum']]
    cd=wb.worksheets.add('Company Today & MTD')
    cd.get_range('A1:I1').values=[['COMPANY PERFORMANCE | DAILY AND MTD']+[None]*8]
    cd.get_range('A3:I3').values=[['Company','Rooms D','Rooms MTD','Room Revenue D','Room Revenue MTD','F&B D','F&B MTD','Total D','Total MTD']]
    cur={z['company']:z for z in sources.get('Company Revenue',{}).get('companies',[])}
    allnames=sorted(set(cur)|set(detail_m['companies']))
    for idx,name in enumerate(allnames,4):
        v=cur.get(name,{});mc=detail_m['companies'].get(name,{})
        cd.get_range(f'A{idx}:I{idx}').values=[[name,v.get('rooms'),mc.get('rooms') if cov['Company Revenue'] else None,
             v.get('room_revenue'),mc.get('room_revenue') if cov['Company Revenue'] else None,
             v.get('fnb_revenue'),mc.get('fnb_revenue') if cov['Company Revenue'] else None,
             v.get('total_revenue'),mc.get('total_revenue') if cov['Company Revenue'] else None]]
    meal=wb.worksheets.add('Meal Plans Today MTD')
    meal.get_range('A1:F1').values=[['MEAL PLAN ROOM-NIGHTS / PAX-NIGHTS - NOT ACTUAL CONSUMPTION']+[None]*5]
    meal.get_range('A3:F3').values=[['Meal Plan','Rooms Today','Rooms MTD','Pax Today','Pax MTD','Rule']]
    meal_today=values_for_fnb(sources.get('F&B Report',{}))
    for i,code in enumerate(('BB','HB','FB','AN','HAN','BED'),4):
        z=meal_today.get(code,{});v=detail_m['meal_plans'].get(code,{})
        meal.get_range(f'A{i}:F{i}').values=[[code,z.get('rooms') if 'F&B Report' in sources else None,
           v.get('rooms',0) if cov['F&B Report'] else None,z.get('pax') if 'F&B Report' in sources else None,
           v.get('pax',0) if cov['F&B Report'] else None,
           'Soft included; hard paid' if code=='AN' else 'Soft + hard included' if code=='HAN' else 'Plan terms']]
    meal.get_range('A12:C12').values=[['Service','Today rooms','MTD entitlement room-nights']]
    for i,code in enumerate(('BFST','LNCH','DNNR','ANB','HAN'),13):
        meal.get_range(f'A{i}:C{i}').values=[[code,sources.get('F&B Report',{}).get('services_rooms',{}).get(code) if 'F&B Report' in sources else None,
                                            detail_m['meal_services'].get(code,0) if cov['F&B Report'] else None]]
    for sht,headers,widths in ((dd,['A4:D4','A20:D20'],[33,17,21,48]),(cd,['A3:I3'],[31]+[19]*8),(meal,['A3:F3','A12:C12'],[30,22,22,22,22,42])):
        for j,w in enumerate(widths):
            col='ABCDEFGHIJKLMNOPQRSTUVWXYZ'[j];sht.get_range(f'{col}:{col}').format.column_width=w
        for h in headers:sht.get_range(h).format={'fill':BLUE,'font':{'bold':True,'color':'#FFFFFF'}}
        sht.get_range('A1').format={'font':{'bold':True,'size':14,'color':NAVY},'row_height':28}
    # Apply readable compact format and neutral financial presentation.
    for sheet in (report,sh,co,a):
        sheet.get_range('A:A').format.column_width=30
        sheet.get_range('B:B').format.column_width=18
        sheet.get_range('C:C').format.column_width=27 if sheet!=a else 75
        if sheet==sh:
            for c in 'DEFG':sheet.get_range(f'{c}:{c}').format.column_width=18
        if sheet==co:
            for c in 'DE':sheet.get_range(f'{c}:{c}').format.column_width=21
        sheet.get_range('A1').format={'font':{'bold':True,'size':16,'color':'#FFFFFF'},'fill':NAVY,'row_height':34}
        sheet.get_range('A2').format.row_height=25
        sheet.get_range('A2').format.font.color=GRAY
    for rng in ('A4:C4','A20:C20','A32:C32','A37:C37'):
        report.get_range(rng).format={'fill':BLUE,'font':{'bold':True,'color':'#FFFFFF'},'row_height':24}
    for label in ('A9:C9','A12:C12','A17:C17'):
        report.get_range(label).format={'fill':LIGHT,'font':{'bold':True,'color':NAVY}}
    report.get_range('B5:B35').set_number_format('#,##0.00;[Red](#,##0.00)')
    for sht, header in ((sh,'A4:G4'),(co,'A3:E3'),(a,'A3:C3')):
        sht.get_range(header).format={'fill':BLUE,'font':{'bold':True,'color':'#FFFFFF'},'row_height':24}
    sh.get_range(f'C5:G{row}').set_number_format('#,##0.00;[Red](#,##0.00)')
    co.get_range('C4:E100').set_number_format('#,##0.00;[Red](#,##0.00)')
    report.get_range('C:C').format.column_width=69
    report.get_range('A:A').format.column_width=30
    report.get_range('B:B').format.column_width=23
    a.get_range('B:B').format.column_width=32
    a.get_range('C:C').format.column_width=88
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    SpreadsheetFile.export_xlsx(wb).save(str(path))
    return path

def pdf_export(store,d,path,combined=True):
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
    from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT,TA_CENTER
    from reportlab.lib.pagesizes import A4
    src=store.day(d);m=metrics(src);ex=checks(src);mt=monthly(store,d)
    s=getSampleStyleSheet()
    s.add(ParagraphStyle(name='HotelTitle',parent=s['Heading1'],fontName='Helvetica-Bold',fontSize=18,leading=22,textColor=colors.HexColor(NAVY),spaceAfter=7))
    s.add(ParagraphStyle(name='SectionTitleSky',parent=s['Heading2'],fontName='Helvetica-Bold',fontSize=11,leading=15,textColor=colors.HexColor(BLUE),spaceBefore=14,spaceAfter=7))
    s.add(ParagraphStyle(name='SmallSky',parent=s['BodyText'],fontSize=8,leading=11,textColor=colors.HexColor(GRAY)))
    s.add(ParagraphStyle(name='BodySky',parent=s['BodyText'],fontSize=9,leading=14,spaceAfter=5))
    s.add(ParagraphStyle(name='TableSky',fontName='Helvetica',fontSize=8,leading=11))
    s.add(ParagraphStyle(name='TableHeadSky',fontName='Helvetica-Bold',fontSize=8,leading=11,textColor=colors.white))
    doc=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=40,rightMargin=40,topMargin=50,bottomMargin=44,title='Sky Star Daily Sales and Commentary')
    elements=[]
    def p(text,style='BodySky'):return Paragraph(escape(str(text)).replace('\n','<br/>'),s[style])
    def section(t):elements.append(p(t,'SectionTitleSky'))
    def rows_table(headers,rows,widths=None):
        data=[[p(x,'TableHeadSky') for x in headers]]
        for item in rows:data.append([p(x,'TableSky') for x in item])
        t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(NAVY)),('TEXTCOLOR',(0,0),(-1,0),colors.white),
            ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F2F6FA')]),
            ('BOTTOMPADDING',(0,0),(-1,0),9),('TOPPADDING',(0,0),(-1,0),9),
            ('LINEBELOW',(0,-1),(-1,-1),0.4,colors.HexColor('#D6DFE7')),
            ('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('VALIGN',(0,0),(-1,-1),'TOP')]))
        elements.append(t)
    elements.append(p('SKY STAR HOTEL','HotelTitle'))
    elements.append(p('DAILY SALES / FINANCIAL CONTROL', 'SectionTitleSky'))
    elements.append(p(f'Business date: {d}   |   {store.status(d).upper()}  |   Preview / Internal Management Review','SmallSky'))
    elements.append(Spacer(1,8))
    section('Revenue Performance')
    revr=[('Rooms',m['rooms']),('Food',m['food']),('Beverage',m['beverage']),('Other Income (before adjustment)',m['other']),
          ('TOTAL HOTEL REVENUE',m['revenue']),('Other Adjustment',m['adjustment']),('Transportation classified separately',m['transportation']),
          ('Net Posted Revenue',m['net_revenue']),('Taxes & Service Charges',m['taxes'])]
    rows_table(['Revenue stream','Today'],[(k,f'{v:,.2f}') for k,v in revr],[355,160])
    section('Rooms & Occupancy')
    if 'Rooms Situation' in src:
        rows_table(['Indicator','Today'],[(k,str(v)) for k,v in [('Physical Rooms',m['physical_count']),('OOO',m['ooo_in_rooms']),('Operating Rooms',m['available_for_sale']),('Revenue Occupied',m['revenue_occupied']),('Vacant',m['vacant']),('Complimentary',m['comp']),('House Use',m['house_use']),('Paid Occupancy','%.2f%%'%m['occupancy']),('ADR','%.2f'%m['adr']),('RevPAR','%.2f'%m['revpar'])]],[355,160])
    else:elements.append(p('Rooms Situation was not supplied.'))
    section('Settlements - Not the Same as Revenue')
    rows_table(['Method','Amount'],[(k,f'{m[k]:,.2f}') for k in ('cash','card','city_ledger','total_settlements')]+[('Comsys Posting Movement (not revenue)',f'{m["grand_total"]:,.2f}')],[355,160])
    elements.append(p('City Ledger is a transfer to receivables, not cash collected. Internal transfers are excluded from the settlement total.','SmallSky'))
    section('MTD Coverage')
    if not mt['complete']:
        elements.append(p(f'INCOMPLETE: {len(mt["missing"])} date(s) missing / not approved. Month-to-date amounts are NOT final.','BodySky'))
    else:elements.append(p(f'All {mt["days_expected"]} business dates have been approved through {d}. Total MTD revenue {mt.get("revenue",0):,.2f}.'))
    section('Audit Exceptions')
    if ex:rows_table(['Level','Finding'],[(x['level'],x['message']) for x in ex],[85,430])
    else:elements.append(p('All implemented reconciliations are within tolerance.'))
    elements.append(Spacer(1,10))
    note=store.notes(d)[1]
    if note:elements.append(p('Auditor Notes: '+note))
    if combined:
        elements.append(PageBreak())
        elements.append(p('DAILY MANAGEMENT COMMENTARY','HotelTitle'))
        elements.append(p(f'Business Date: {d} | {store.status(d)}','SmallSky'))
        written=store.notes(d)[0] or generate_commentary(store,d)
        for raw in written.splitlines():
            line=raw.strip()
            if not line:elements.append(Spacer(1,6))
            elif re.match(r'^\d+\.\s',line):section(line)
            else:elements.append(p(line))
    def footer(c,doc):
        c.saveState();w,h=A4
        c.setStrokeColor(colors.HexColor('#D5DEE8'));c.line(40,38,w-40,38)
        c.setFont('Helvetica',8);c.setFillColor(colors.HexColor(GRAY))
        c.drawString(40,26,'Sky Star Hotel | Internal Management Review | Not a system-of-record posting')
        c.drawRightString(w-40,26,f'{d}  |  Page {doc.page}')
        if store.status(d)!='Closed':
            c.setFont('Helvetica-Bold',9);c.setFillColor(colors.HexColor('#AF4537'))
            c.drawRightString(w-40,h-25,'PREVIEW / NOT APPROVED')
        c.restoreState()
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    doc.build(elements,onFirstPage=footer,onLaterPages=footer)
    return path
