"""Source-driven company occupancy from the Comsys Guest In House register.

Company labels are *not* occupancy status. Room-level H/U and Comp flags are
independent; dummy 1301 is always excluded. Never store guest names in the
Daily Sales database. Company Revenue remains the sole source of company money.
"""
from collections import defaultdict

DUMMY_ROOMS={'1301'}
# Explicit, auditable name mapping only; unknown names are left unmatched.
COMPANY_ALIASES={
    'masria air':'Masria Air Lines',
    'corendon s':'Corendon Serbian Crew',
    'comp':'Complimentary',  # Comsys company alias; NOT an occupancy status.
}

def resolve_company(name, revenue_names):
    raw=str(name or '').strip() or 'Unspecified Company'
    match={str(n).strip().casefold():n for n in revenue_names}
    source=COMPANY_ALIASES.get(raw.casefold(),raw)
    return match.get(source.casefold(),source)


def occupancy_from_guests(payload, revenue_names=()):
    """Return paid-company and comp/HU occupancy without any inferred cash.

    Single/double/triple/quad buckets follow certified in-house adult occupancy.
    Rooms with 0 or more than 4 adults remain in Total Rooms and are flagged
    for private audit; they are never misclassified as Quad.
    """
    groups=defaultdict(lambda:{'rooms':0.,'single':0.,'double':0.,'triple':0.,'quad':0.,
                               'adults':0.,'children':0.,'kind':'paid'})
    seen=set();errors=[]
    for rec in payload.get('guests',[]):
        room=str(rec.get('room','')).strip()
        if room in DUMMY_ROOMS:continue
        if room in seen:
            errors.append(f'Duplicate physical room {room} in Guest In House')
            continue
        seen.add(room)
        kind=rec.get('kind','paid')
        if kind=='comp':name='Complimentary Rooms'
        elif kind=='hu':name='House Use'
        else:
            canonical=resolve_company(rec.get('company'), revenue_names)
            name='Comp (PMS company code)' if canonical=='Complimentary' else canonical
        bucket=groups[name];bucket['kind']=kind
        bucket['rooms']+=1
        adults=int(rec.get('adults') or 0);child=int(rec.get('children') or 0)
        bucket['adults']+=adults;bucket['children']+=child
        if adults==1:bucket['single']+=1
        elif adults==2:bucket['double']+=1
        elif adults==3:bucket['triple']+=1
        elif adults==4:bucket['quad']+=1
        else:
            errors.append(f'Room {room}: adult count {adults} is outside Single/Double/Triple/Quad buckets; review privately')
    return dict(groups),errors


def complete_guest_payload(sources):
    """Combine paid guest occupancy with separately certified free-room lists.

    No room is counted twice. Callers still must review source-status conflicts.
    """
    payload=sources.get('Guest In House',{})
    copied={**payload,'guests':[dict(x) for x in payload.get('guests',[])]}
    seen={str(x['room']) for x in copied['guests']}
    for kind,label,excluded_flag in (('Complimentary Report','comp','excludes_complimentary'),
                                     ('House Use Report','hu','excludes_house_use')):
        if not payload.get(excluded_flag):continue
        source=sources.get(kind)
        if not source:continue
        for rec in source.get('rooms',[]):
            room=str(rec.get('room','')).strip()
            if room in DUMMY_ROOMS or room in seen:continue
            seen.add(room); pax=str(rec.get('pax','')).split('/')
            ages=[]
            for i in range(3):
                try:ages.append(int(float(pax[i])))
                except (IndexError,TypeError,ValueError):ages.append(0)
            copied['guests'].append({'room':room,'company':'','adults':ages[0],
                                      'children':ages[1],'infants':ages[2],
                                      'kind':label,'meal_pattern':rec.get('meal_pattern','')})
    copied['adults']=sum(x['adults'] for x in copied['guests'])
    copied['children']=sum(x['children'] for x in copied['guests'])
    copied['infants']=sum(x['infants'] for x in copied['guests'])
    copied['rooms']=len(copied['guests'])
    return copied
