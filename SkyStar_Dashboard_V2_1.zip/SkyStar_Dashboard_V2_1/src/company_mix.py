"""Company grid: room and adult allocation from Guest In House only.

Company Revenue amounts are joined to paid room groups by explicit aliases.
Comps, House Use and dummy rooms are never inferred from a company name.
MTD is a sum of the SAME approved business days across all required sources.
"""
from collections import defaultdict
from datetime import date, timedelta
from engine import metrics
from inhouse_company import occupancy_from_guests,resolve_company,complete_guest_payload

COLUMNS=('rooms','single','double','triple','quad','adults','room_revenue','fnb_revenue','total_revenue')


def _empty(kind):
    return {**{x:0.0 for x in COLUMNS},'kind':kind}


def _amounts(source):
    return {'room_revenue':float(source['room_revenue']),
            'fnb_revenue':float(source['fnb_revenue']),
            'total_revenue':float(source['total_revenue'])}


def _build(source):
    has_guest='Guest In House' in source
    company=source.get('Company Revenue',{}).get('companies',[])
    names=[c['company'] for c in company]
    grouped,issues=occupancy_from_guests(complete_guest_payload(source),names) if has_guest else ({},[])
    rows={}
    if has_guest:
        for name,counts in grouped.items():
            rows[name]={**_empty(counts['kind']),**{k:counts[k] for k in ('rooms','single','double','triple','quad','adults')},
                        'kind':counts['kind']}
            if counts['kind']=='paid':
                # Never report an invented 0.00 for a company without an imported
                # Company Revenue record.  The money is pending reconciliation.
                for k in ('room_revenue','fnb_revenue','total_revenue'):rows[name][k]=None
    for record in company:
        canonical=record['company']
        label='Comp (PMS company code)' if canonical.casefold()=='complimentary' else canonical
        if label not in rows:
            # Company financial figure without matching occupancy is not assigned
            # to any guest; it must be visible as an unmatched financial line.
            rows[label]={**_empty('unmatched'),**{k:None for k in ('rooms','single','double','triple','quad','adults')}}
            issues.append(f'No matching in-house paid occupancy for {canonical}')
        if rows[label]['kind'] not in ('paid','unmatched'):
            issues.append(f'Invalid paid company match for {canonical}')
            continue
        rows[label].update(_amounts(record))
        if has_guest and rows[label]['rooms'] is not None and rows[label]['rooms']!=record['rooms']:
            issues.append(f'{canonical}: in-house room count {rows[label]["rooms"]} != company revenue {record["rooms"]}')
    # Guarantee actual complimentary / H/U category on days with guest source;
    # genuine 0 stays zero.  No forced "unassigned" fictitious rooms.
    if has_guest:
        for label,kind in (('Complimentary Rooms','comp'),('House Use','hu')):
            rows.setdefault(label,_empty(kind))
    return rows,issues


def _add(target,data):
    if not target:return dict(data)
    out={'kind':data.get('kind',target.get('kind'))}
    for key in COLUMNS:
        a=target.get(key);b=data.get(key)
        out[key]=(a+b) if a is not None and b is not None else None
    return out


def _totals(mapping):
    if not mapping:return None
    result={}
    for key in COLUMNS:
        vals=[r.get(key) for r in mapping.values()]
        result[key]=round(sum(vals),2) if vals and all(v is not None for v in vals) else None
    return result


def company_mix(store,business_day):
    source=store.day(business_day)
    daily,errors=_build(source)
    rm=metrics(source) if 'Rooms Situation' in source else {}
    today_denom=(rm['revenue_occupied']+rm['comp']+rm['house_use']) if 'revenue_occupied' in rm else None
    start=store.reporting_start(business_day)
    end=date.fromisoformat(business_day)
    aligned=[]
    required={'Guest In House','Company Revenue','Rooms Situation'}
    for index in range((end-start).days+1):
        day=(start+timedelta(days=index)).isoformat()
        if store.status(day)=='Closed' and required.issubset(store.day(day)):
            aligned.append((day,store.day(day)))
    month={};mtd_denom=0
    for day,record in aligned:
        rec,problems=_build(record)
        errors.extend(day+': '+e for e in problems)
        for key,val in rec.items():month[key]=_add(month.get(key),val)
        m=metrics(record)
        mtd_denom+=m['revenue_occupied']+m['comp']+m['house_use']
    today_total=_totals(daily);mtd_total=_totals(month)
    allnames=set(daily)|set(month)
    def _rank(n):
        p=daily.get(n) or month.get(n) or {}
        return (0 if p.get('kind')=='paid' else 1 if p.get('kind')=='unmatched' else 2,
                -float((p.get('total_revenue') or 0)),n)
    names=sorted(allnames,key=_rank)
    # Put Complimentary and House Use at bottom without hiding their occupancy.
    rows=[]
    def share(row,denom):return 100.0*row['rooms']/denom if row and row.get('rooms') is not None and denom else None
    for name in names:
        row_d=daily.get(name);row_m=month.get(name)
        rows.append({'name':name,'today':row_d,'mtd':row_m,
                     'today_mix':share(row_d,today_denom),
                     'mtd_mix':share(row_m,mtd_denom)})
    rows.append({'name':'TOTAL OCCUPIED MIX','today':today_total,'mtd':mtd_total,
                 'today_mix':share(today_total,today_denom),
                 'mtd_mix':share(mtd_total,mtd_denom),'is_total':True})
    return {'rows':rows,'today_den':today_denom,'mtd_den':mtd_denom if aligned else None,
            'mtd_aligned':bool(aligned),'mtd_matched_days':[k for k,_ in aligned],
            'mtd_complete':len(aligned)==(end-start).days+1,
            'today_gap':None if today_denom is None or today_total is None or today_total['rooms'] is None else today_denom-today_total['rooms'],
            'mtd_gap':None if not aligned or mtd_total is None or mtd_total['rooms'] is None else mtd_denom-mtd_total['rooms'],
            'issues':errors}
