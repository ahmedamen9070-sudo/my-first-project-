"""Compact one-sheet management daily: accurate Today/closed-day MTD.
No comments, no coverage bands; data remains strictly sourced and scoped.
"""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from engine import metrics
from mtd_detail import detail,values_for_fnb
from exports_pdf_v5 import pdf_export as previous_export

W,H=landscape(A4)
NAVY='#1C3249'; TEAL='#086E73'; PALE='#E9F1F4'; LIGHT='#F6F9FA'; DIV='#DEE6EB'; WHITE='#FFFFFF'; INK='#273A49'; MUTE='#657787'
MONEY='amt'; INT='num'; PCT='pct'

# All coordinates are PDF points, origin bottom left.
def rect(c,x,y,w,h,color):
    c.setFillColor(HexColor(color));c.rect(x,y,w,h,fill=1,stroke=0)
def line(c,x,y,x2,y2,col=DIV):
    c.setStrokeColor(HexColor(col));c.setLineWidth(.45);c.line(x,y,x2,y2)
def t(c,x,y,s,size=7,color=INK,bold=False,maxw=None,align='left'):
    s=str(s);font='Helvetica-Bold' if bold else 'Helvetica'
    if maxw is not None and stringWidth(s,font,size)>maxw:
        while s and stringWidth(s+'…',font,size)>maxw:s=s[:-1]
        s+='…'
    c.setFillColor(HexColor(color));c.setFont(font,size)
    {'left':c.drawString,'right':c.drawRightString,'center':c.drawCentredString}[align](x,y,s)
def number(v,kind='amt'):
    if v is None:return '—'
    if kind=='pct':return f'{v:,.2f}%'
    if kind=='num':return f'{v:,.0f}'
    return f'{v:,.2f}'
def bar(c,x,y,w,label,meta=None):
    rect(c,x,y-3,w,17,PALE)
    t(c,x+7,y+3,label.upper(),8.1,NAVY,True)
    if meta:t(c,x+w-5,y+3,meta,6.4,MUTE,False,align='right')
def financial_row(c,x,y,w,label,a,b,index=0,kind='amt',emph=False,indent=0):
    if index%2==0:rect(c,x,y-3,w,11,LIGHT)
    if emph:rect(c,x,y-3,w,11,PALE)
    t(c,x+7+indent,y,label,7.1 if not emph else 7.25,INK,emph,maxw=w-181-indent)
    t(c,x+w-89,y,number(a,kind),7.2,INK,emph,align='right')
    t(c,x+w-7,y,number(b,kind),7.2,TEAL,True,align='right')

# Revenue detail belongs to Department Codes; native Comsys MTD is reference only.
REVENUE_GROUPS=[
 ('ROOMS',[(101,'Individual Rate'),(102,'Group Rate'),(104,'Late Check Out'),(103,'Extra Bed'),(105,'Cancellation / Other'),(199,'Room Adjustment'),(903,'Early Check In')],'rooms'),
 ('FOOD',[(201,'Pool Bar Food'),(202,'Beach Bar Food'),(203,'Cafe Bar Food'),(204,'Kids Area Food'),(205,'Main Restaurant'),(250,'Breakfast Package'),(251,'Dinner Package'),(252,'Lunch Package'),(299,'Food Adjustment')],'food'),
 ('BEVERAGE',[(253,'All Inclusive Beverage'),(301,'Pool Bar Beverage'),(302,'Beach Bar Beverage'),(303,'Cafe Beverage'),(304,'Kids Area Beverage'),(305,'Main Restaurant Beverage'),(399,'Beverage Adjustment')],'beverage'),
 ('OTHER',[(350,'Other F&B'),(401,'Local Telephone'),(402,'National Telephone'),(403,'International Telephone'),(501,'Laundry'),(502,'Billiard'),(503,'Miscellaneous'),(550,'Tips'),(590,'Opening Balance')],'other'),
]

def pdf_export(store,date,path,mode='management'):
    if mode!='management':return previous_export(store,date,path,mode=mode)
    src=store.day(date)
    if not src:raise ValueError('No imported Comsys reports for this business date')
    m=metrics(src);mt=detail(store,date)
    covered=mt['coverage'];has_dep='Department Summary' in src
    dep_today={int(x['code']):float(x['today']) for x in src.get('Department Summary',{}).get('codes',[])}
    dep_mtd=mt['department_codes'] if covered['Department Summary'] else {}
    has_rooms='Rooms Situation' in src
    has_co='Company Revenue' in src
    has_fb='F&B Report' in src
    company_today={x['company']:x for x in src.get('Company Revenue',{}).get('companies',[])}
    company_mtd=mt['companies'] if covered['Company Revenue'] else {}
    source_room_revenue=m.get('rooms') if has_dep else None
    approved_room_revenue=mt['financial'].get('rooms') if covered['Department Summary'] else None
    # Even if PDF exported from draft, no pretend MTD coverage.
    mtd_complete=all(covered[k]==mt['expected'] for k in ('Department Summary','Rooms Situation','Company Revenue','F&B Report'))
    c=canvas.Canvas(str(path),pagesize=(W,H),pageCompression=1)
    c.setTitle(f'Sky Star Daily Sales {date} | Today and MTD')
    rect(c,0,H-35,W,35,NAVY)
    t(c,21,H-23,'Sky Star Daily Sales',15.8,WHITE,True)
    qualifier='MTD COMPLETE' if mtd_complete else 'MTD INCOMPLETE'
    t(c,W-19,H-21,f'{date}   •   {store.status(date).upper()}   •   {qualifier}',7.6,'#DBE8EB',True,align='right')
    L=19; LW=390; RX=419; RW=W-RX-19
    # TWO COLUMN BODY: revenue including taxes/settlements on left, occupancy/meal entitlements on right
    bar(c,L,548,LW,'REVENUE', 'TODAY                        MTD')
    y=530; index=0
    def fr(label,a,b,kind='amt',important=False,indent=0):
        nonlocal y,index
        financial_row(c,L,y,LW,label,a,b,index,kind,important,indent)
        index+=1;y-=11.05
    for group,items,totalkey in REVENUE_GROUPS:
        # Only non-zero detail codes remain, except important known operational rows.
        permanent={101,102,205,250,251,252,253,301,305,501,503,550}
        visible=[(code,label) for code,label in items if code in permanent or abs(dep_today.get(code,0))>.001 or abs(dep_mtd.get(code,0))>.001]
        for code,label in visible:
            fr(label,dep_today.get(code,0) if has_dep else None,
               dep_mtd.get(code,0) if covered['Department Summary'] else None,indent=8)
        fr('TOTAL '+group,m.get(totalkey) if has_dep else None,
           mt['financial'].get(totalkey) if covered['Department Summary'] else None,important=True)
    fr('TOTAL HOTEL REVENUE',m['revenue'] if has_dep else None,
       mt['financial']['revenue'] if covered['Department Summary'] else None,important=True)
    fr('Other Income Adjustment (599)',m['adjustment'] if has_dep else None,
       mt['financial']['adjustment'] if covered['Department Summary'] else None)
    fr('Transportation (904)',m['transportation'] if has_dep else None,
       mt['financial']['transportation'] if covered['Department Summary'] else None)
    fr('Service Charges + Taxes',m['taxes'] if has_dep else None,
       mt['financial']['taxes'] if covered['Department Summary'] else None)
    # Financial reconciliation is NOT added to sales.
    y-=4
    bar(c,L,y,LW,'SETTLEMENTS', 'NOT ADDITIONAL REVENUE')
    y-=20
    for label,k in [('Cash','cash'),('Credit Cards','card'),('City Ledger','city_ledger')]:
        fr(label,m.get(k) if has_dep else None,mt['financial'].get(k) if covered['Department Summary'] else None)
    # Right section rooms, same weighting as PMS paid-occupied.
    bar(c,RX,548,RW,'ROOMS / OCCUPANCY','TODAY                        MTD')
    ry=530; ri=0
    def rr(label,v,b,kind='num',emph=False):
        nonlocal ry,ri
        financial_row(c,RX,ry,RW,label,v,b,ri,kind,emph)
        ri+=1;ry-=10.60
    rm=mt['rooms'];source=(src.get('Rooms Situation',{}))
    def sd(key):return m.get(key) if has_rooms else None
    def sm(key):return rm.get(key) if covered['Rooms Situation'] else None
    rr('Physical Rooms (latest snapshot)',sd('physical_count'),sm('physical_count'))
    rr('Out of Order / OOO Nights',sd('ooo_in_rooms'),sm('ooo_in_rooms'))
    rr('Operating Rooms / Room Nights',sd('available_for_sale'),sm('available_for_sale'))
    rr('Vacant / Vacant Nights',sd('vacant'),sm('vacant'))
    rr('House Use / H.U. Nights',sd('house_use'),sm('house_use'))
    rr('Complimentary / Comp Nights',sd('comp'),sm('comp'))
    rr('Paid Occupied / Occupied Nights',sd('revenue_occupied'),sm('revenue_occupied'),emph=True)
    # Company mix is for sold rooms only, not unit architectural type.
    keys=['single','double','triple','quad','other_type','suite']
    sums_today={k:sum(float(v.get(k,0)) for v in company_today.values()) for k in keys}
    sums_mtd={k:sum(float(v.get(k,0)) for v in company_mtd.values()) for k in keys}
    rooms_day=sum(sums_today.values());rooms_month=sum(sums_mtd.values())
    for key,label in [('single','Rooms Single'),('double','Rooms Double'),('triple','Rooms Triple'),('quad','Rooms Quadruple'),('other_type','Rooms Above 4 Pax'),('suite','Suites')]:
        rr(label,sums_today[key] if has_co else None,sums_mtd[key] if covered['Company Revenue'] else None)
    rr('Single %',100*sums_today['single']/rooms_day if has_co and rooms_day else None,100*sums_mtd['single']/rooms_month if rooms_month else None,'pct')
    rr('Double %',100*sums_today['double']/rooms_day if has_co and rooms_day else None,100*sums_mtd['double']/rooms_month if rooms_month else None,'pct')
    rr('Paid Occupancy %',sd('occupancy'),sm('occupancy'),'pct',True)
    rr('Paid + Complimentary %',100*(sd('revenue_occupied')+sd('comp'))/sd('available_for_sale') if has_rooms and sd('available_for_sale') else None,
       100*(sm('revenue_occupied')+sm('comp'))/sm('available_for_sale') if sm('available_for_sale') else None,'pct')
    rr('Paid + House Use %',100*(sd('revenue_occupied')+sd('house_use'))/sd('available_for_sale') if has_rooms and sd('available_for_sale') else None,
       100*(sm('revenue_occupied')+sm('house_use'))/sm('available_for_sale') if sm('available_for_sale') else None,'pct')
    rr('Paid + Comp + House Use %',100*(sd('revenue_occupied')+sd('comp')+sd('house_use'))/sd('available_for_sale') if has_rooms and sd('available_for_sale') else None,
       100*(sm('revenue_occupied')+sm('comp')+sm('house_use'))/sm('available_for_sale') if sm('available_for_sale') else None,'pct')
    def paxsplit(text):
        try:return [int(float(x)) for x in str(text).split('/')[:3]]
        except (ValueError,TypeError):return [0,0,0]
    ap=[0,0,0]; mp=[0,0,0]
    for co in company_today.values():
        for i,n in enumerate(paxsplit(co.get('pax'))):ap[i]+=n
    for co in company_mtd.values():
        for i,n in enumerate(paxsplit(co.get('pax'))):mp[i]+=n
    rr('Adults / Adult Nights',ap[0] if has_co else None,mp[0] if covered['Company Revenue'] else None)
    rr('Children / Child Nights',ap[1] if has_co else None,mp[1] if covered['Company Revenue'] else None)
    rr('Infants / Infant Nights',ap[2] if has_co else None,mp[2] if covered['Company Revenue'] else None)
    rr('Average Room Rate (ADR)',sd('adr'),sm('adr'),'amt')
    rr('RevPAR',sd('revpar'),sm('revpar'),'amt')
    rr('Room Revenue / Adult Pax',source_room_revenue/ap[0] if has_co and has_dep and ap[0] else None,
       approved_room_revenue/mp[0] if covered['Department Summary'] and covered['Company Revenue'] and
       covered['Department Summary']==covered['Company Revenue'] and mp[0] else None,'amt')
    # Bottom-right meal table until company bar below; no repeated revenue values here.
    ry-=9
    bar(c,RX,ry+1,RW,'MEAL PLAN','ROOM-NIGHTS + PAX-NIGHTS')
    ry-=17
    # Management asked to remove the cryptic 'Included' shorthand column.
    # Give its width to the four meaningful Today/MTD count columns instead.
    cols=[RX+8,RX+146,RX+224,RX+302,RX+RW-8]
    for x,label in zip(cols,['Plan','Rooms D','Rooms MTD','Pax D','Pax MTD']):
        t(c,x,ry,label,6.3,MUTE,True,align='right' if x!=cols[0] else 'left')
    ry-=11
    plans=values_for_fnb(src.get('F&B Report',{})) if has_fb else {}
    pdict=mt['meal_plans']
    for idx,code in enumerate(('BB','HB','FB','AN','HAN','BED')):
        if idx%2==0:rect(c,RX,ry-3,RW,11,LIGHT)
        z=plans.get(code,{});zm=pdict.get(code,{})
        vals=[code,number(z.get('rooms',0) if has_fb else None,'num'),
            number(zm.get('rooms',0) if covered['F&B Report'] else None,'num'),
            number(z.get('pax',0) if has_fb else None,'num'),
            number(zm.get('pax',0) if covered['F&B Report'] else None,'num')]
        for j,(x,v) in enumerate(zip(cols,vals)):
            t(c,x,ry,v,6.8,TEAL if j in (2,4) else INK,j==0,align='right' if j>0 else 'left')
        ry-=10.5
    daily_services=src.get('F&B Report',{}).get('services_rooms',{})
    mtd_services=mt.get('meal_services',{})
    codes=[]
    for code in ('BFST','LNCH','DNNR','ANB','HAN'):
        a=number(daily_services.get(code,0) if has_fb else None,'num')
        b=number(mtd_services.get(code,0) if covered['F&B Report'] else None,'num')
        codes.append(f'{code} {a}/{b}')
    t(c,RX+6,ry+0.4,'ENTITLEMENTS (ROOMS D/MTD):  '+'   '.join(codes),5.7,MUTE,maxw=RW-10)
    # Yield metrics from proven common-source days only (not averages of daily ratios).
    y-=4
    bar(c,L,y,LW,'OPERATING AVERAGES')
    y-=20
    if has_co:
        d_single=sum(float(z.get('single',0)) for z in company_today.values())
        d_double=sum(float(z.get('double',0)) for z in company_today.values())
        d_triple=sum(float(z.get('triple',0)) for z in company_today.values())
        d_quad=sum(float(z.get('quad',0)) for z in company_today.values())
        d_other=sum(float(z.get('other_type',0)) for z in company_today.values())
    else:d_double=d_triple=d_quad=d_other=d_single=0
    if covered['Company Revenue']:
        mo_double=sum(float(z.get('double',0)) for z in company_mtd.values())
        mo_triple=sum(float(z.get('triple',0)) for z in company_mtd.values())
        mo_quad=sum(float(z.get('quad',0)) for z in company_mtd.values())
        mo_other=sum(float(z.get('other_type',0)) for z in company_mtd.values())
    else:mo_double=mo_triple=mo_quad=mo_other=0
    double_oc_today=100*(d_double+2*d_triple+3*d_quad+4*d_other)/m['revenue_occupied'] if has_co and has_rooms and m.get('revenue_occupied') else None
    double_oc_mtd=100*(mo_double+2*mo_triple+3*mo_quad+4*mo_other)/rm['revenue_occupied'] if covered['Company Revenue'] and covered['Rooms Situation'] and covered['Company Revenue']==covered['Rooms Situation'] and rm.get('revenue_occupied') else None
    # Adult pax denominator matches Comsys per-pax KPIs in the verified source sample.
    comparable=covered['Company Revenue']>0 and covered['Company Revenue']==covered['Department Summary']
    r_day=(m.get('food',0)+m.get('beverage',0))/ap[0] if has_dep and has_co and ap[0] else None
    r_month=(mt['financial']['food']+mt['financial']['beverage'])/mp[0] if comparable and mp[0] else None
    for label,dv,mv,kind in [
        ('Double Occupancy %',double_oc_today,double_oc_mtd,'pct'),
        ('Average F&B / Adult',r_day,r_month,'amt'),
        ('Extra Food / Adult',dep_today.get(205,0)/ap[0] if has_dep and has_co and ap[0] else None,dep_mtd.get(205,0)/mp[0] if comparable and mp[0] else None,'amt'),
        ('Extra Beverage / Adult',dep_today.get(301,0)/ap[0] if has_dep and has_co and ap[0] else None,dep_mtd.get(301,0)/mp[0] if comparable and mp[0] else None,'amt'),
        ('Average Food / Cover',None,None,'amt')]:
        fr(label,dv,mv,kind)

    # Full width company table uses paired Today + MTD for all source columns.
    company_y=146
    bar(c,L,company_y,W-2*L,'COMPANIES • ROOM MIX / PAX / REVENUE','Room mix = S/D/T/Q/Other/Suite')
    cy=company_y-16
    COMP_W=130
    todayW=335;monthW=W-2*L-COMP_W-todayW
    start=L+COMP_W
    rect(c,L,cy-4,W-2*L,14,'#E2EDF1')
    t(c,L+6,cy,'COMPANY',6.7,NAVY,True)
    t(c,start+todayW/2,cy,'TODAY',7,NAVY,True,align='center')
    t(c,start+todayW+monthW/2,cy,'MTD',7,TEAL,True,align='center')
    cy-=14
    bw=[26,66,40,59,59,70]
    def colpos(base):
        loc=[];acc=base
        for w in bw:acc+=w;loc.append(acc-3)
        return loc
    xs=colpos(start);xsm=colpos(start+todayW)
    rect(c,L,cy-3,W-2*L,12,'#F0F4F7')
    labs=['Rms','S/D/T/Q/O/Su','Pax A/C/I','Room Rev','F&B Rev','Total Rev']
    for coords in (xs,xsm):
        for x,lab in zip(coords,labs):t(c,x,cy,lab,6.1,MUTE,True,align='right')
    cy-=13
    names=sorted(set(company_today)|set(company_mtd),key=lambda name: -max(
        company_today.get(name,{}).get('total_revenue',0),company_mtd.get(name,{}).get('total_revenue',0)))
    # fit full source company list while preserving legibility. Typical 6-8 entries.
    if len(names)>8:
        top=names[:7];rest=names[7:]
        def reduce_rest(table):
            items=[table.get(n,{}) for n in rest]
            result={k:sum(float(item.get(k,0)) for item in items) for k in keys+['rooms','room_revenue','fnb_revenue','total_revenue']}
            totals=[0,0,0]
            for item in items:
                for i,v in enumerate(paxsplit(item.get('pax'))):totals[i]+=v
            result['pax']='/'.join(str(x) for x in totals)
            return result
        company_today['OTHER COMPANIES']=reduce_rest(company_today)
        company_mtd['OTHER COMPANIES']=reduce_rest(company_mtd)
        names=top+['OTHER COMPANIES']
    available=cy-29; row_height=min(12.3,max(8.6,available/(len(names)+1 or 1)))
    def fields(record,found):
        if not found:return ['—']*6
        mix='/'.join(str(int(record.get(k,0))) for k in keys)
        return [number(record.get('rooms'),'num'),mix,str(record.get('pax','—')),
           number(record.get('room_revenue')),number(record.get('fnb_revenue')),number(record.get('total_revenue'))]
    def print_company(y,name,day,month,idx,emph=False):
        if idx%2==0 or emph:rect(c,L,y-3,W-2*L,row_height-1,PALE if emph else LIGHT)
        t(c,L+6,y,name,6.75,NAVY,emph,maxw=COMP_W-12)
        for coords,values in ((xs,fields(day,has_co)),(xsm,fields(month,covered['Company Revenue']>0))):
            for ci,(x,v) in enumerate(zip(coords,values)):
                t(c,x,y,v,6.25 if row_height>=10 else 5.8,TEAL if coords is xsm else INK,emph,maxw=bw[ci]-6,align='right')
    for idx,name in enumerate(names):
        print_company(cy,name,company_today.get(name,{}),company_mtd.get(name,{}),idx)
        cy-=row_height
    if names:
        def summ(records):
            out={k:sum(float(v.get(k,0)) for v in records.values()) for k in keys+['rooms','room_revenue','fnb_revenue','total_revenue']}
            s=[0,0,0]
            for v in records.values():
                for i,n in enumerate(paxsplit(v.get('pax'))):s[i]+=n
            out['pax']='/'.join(map(str,s))
            return out
        print_company(cy,'TOTAL COMPANIES',summ(company_today),summ(company_mtd),len(names),True)
    else:
        t(c,L+7,cy,'No company source for this business date.',7,MUTE)
    # No notes, remarks, coverage sentences, or duplicated sections in management PDF.
    line(c,L,21,W-L,21)
    t(c,L,11,'Comsys sourced • MTD accumulates CLOSED days only • Entitlements are not extra sales',6.1,MUTE)
    t(c,W-L,11,'DESIGN PREVIEW',6.2,MUTE,True,align='right')
    c.showPage();c.save()
    return str(path)
