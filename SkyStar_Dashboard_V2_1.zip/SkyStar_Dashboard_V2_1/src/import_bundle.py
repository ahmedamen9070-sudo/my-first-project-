"""Safe, temporary staging of Comsys Excel files or a ZIP export bundle.

No XLS/XLSX content is modified. ZIP members are restricted to flat filenames,
with expansion limits; every staged file still undergoes normal report/date checks.
"""
from pathlib import Path
from contextlib import contextmanager
from tempfile import TemporaryDirectory
import zipfile

MAX_MEMBERS=50
MAX_FILE=18*1024*1024
MAX_TOTAL=70*1024*1024

@contextmanager
def stage_reports(paths):
    """Yield list of Excel paths from selected files and ZIPs; clean up afterward."""
    paths=[Path(p) for p in paths]
    with TemporaryDirectory(prefix='skystar_comsys_') as temp:
        stage=Path(temp);result=[];unique=set()
        for input_path in paths:
            if not input_path.is_file():raise ValueError(f'File not found: {input_path}')
            if input_path.suffix.lower() in ('.xls','.xlsx'):
                result.append(input_path)
                continue
            if input_path.suffix.lower()!='.zip':
                raise ValueError(f'Unsupported input file: {input_path.name}. Use .xls, .xlsx or .zip.')
            with zipfile.ZipFile(input_path) as z:
                acceptable=[];size=0
                for info in z.infolist():
                    if info.is_dir():continue
                    member=Path(info.filename.replace('\\','/'))
                    if '..' in member.parts or info.filename.startswith('/'):
                        raise ValueError(f'Unsafe ZIP path: {info.filename}')
                    if member.suffix.lower() not in ('.xls','.xlsx'):
                        # common archive metadata is skipped; unknown files are rejected
                        if member.name in ('.DS_Store',) or '__MACOSX' in member.parts:continue
                        raise ValueError(f'ZIP contains unsupported file: {info.filename}')
                    if info.flag_bits&1:raise ValueError('Password-protected ZIP is not supported.')
                    if info.file_size>MAX_FILE:raise ValueError(f'Excel file too large in ZIP: {member.name}')
                    size+=info.file_size
                    if size>MAX_TOTAL:raise ValueError('ZIP expands beyond the 70 MB safe limit.')
                    key=member.name.lower()
                    if key in unique:raise ValueError('ZIP contains duplicate Excel filenames: '+member.name)
                    unique.add(key)
                    acceptable.append((info,member.name))
                if not acceptable:raise ValueError('ZIP contains no .xls or .xlsx reports.')
                if len(acceptable)+len(result)>MAX_MEMBERS:
                    raise ValueError('More than 50 input reports in a single upload.')
                for info,name in acceptable:
                    # Preserve only basename, enforce non-overwrite within staging.
                    target=stage/name
                    if target.exists():raise ValueError('Duplicate ZIP report filename: '+name)
                    with z.open(info) as inp, target.open('wb') as out:
                        copied=0
                        while True:
                            block=inp.read(1024*1024)
                            if not block:break
                            copied+=len(block)
                            if copied>MAX_FILE:raise ValueError('Oversized compressed report: '+name)
                            out.write(block)
                    result.append(target)
        if len(result)>MAX_MEMBERS:raise ValueError('Select no more than 50 reports at once.')
        yield result
