"""Read Comsys v4.8.17 exported Excel files without Excel/Office.
Supports BIFF8 .xls (including mini-stream OLE) and modern .xlsx.
A deliberately limited reader: imported files are validated and unsupported records flagged.
"""
from __future__ import annotations
import collections, re, struct, zipfile, xml.etree.ElementTree as ET
from pathlib import Path

END = {0xFFFFFFFE, 0xFFFFFFFF}

def _decode_sst(records):
    """Decode BIFF8 SST across CONTINUE blocks without merging encoding markers.

    In BIFF8 an SST character run split across a CONTINUE record starts with
    one byte specifying the new run's encoding. Flattening the bytes corrupts
    trailing cells (especially Comsys Rooms Summary grand totals).
    """
    if not records:
        return []
    chunks=list(records)
    chunk=0
    pos=0

    def take(n):
        nonlocal chunk,pos
        result=bytearray()
        while len(result)<n:
            if chunk>=len(chunks):
                raise ValueError('Truncated Excel shared-string table')
            remaining=len(chunks[chunk])-pos
            if not remaining:
                chunk+=1;pos=0
                continue
            size=min(n-len(result),remaining)
            result.extend(chunks[chunk][pos:pos+size]);pos+=size
        return bytes(result)

    take(4)  # cstTotal
    unique=struct.unpack('<I',take(4))[0]
    if unique>200000:
        raise ValueError('Excel SST contains an unreasonable string count')
    strings=[]
    for _ in range(unique):
        chars=struct.unpack('<H',take(2))[0]
        options=take(1)[0]
        rich=struct.unpack('<H',take(2))[0] if options&8 else 0
        extended=struct.unpack('<I',take(4))[0] if options&4 else 0
        wide=bool(options&1)
        segments=[]
        left=chars
        while left:
            if chunk>=len(chunks):
                raise ValueError('Incomplete Excel text character data')
            available=len(chunks[chunk])-pos
            if available==0:
                chunk+=1;pos=0
                if chunk>=len(chunks):
                    raise ValueError('Incomplete Excel continuation')
                # Only a split *character run* carries the encoding marker.
                wide=bool(take(1)[0]&1)
                continue
            unit=2 if wide else 1
            count=min(left,available//unit)
            if count==0:
                raise ValueError('Misaligned Excel Unicode character in SST')
            payload=take(count*unit)
            segments.append(payload.decode('utf-16le' if wide else 'latin1','replace'))
            left-=count
        if rich:take(rich*4)
        if extended:take(extended)
        strings.append(''.join(segments))
    return strings


def _biff_rows(path):
    b=Path(path).read_bytes()
    if b[:8] != bytes.fromhex('d0cf11e0a1b11ae1'):raise ValueError('Not a supported legacy Excel OLE file')
    u16=lambda x,o=0:struct.unpack_from('<H',x,o)[0]
    u32=lambda x,o=0:struct.unpack_from('<I',x,o)[0]
    sec=1<<u16(b,30); mini=1<<u16(b,32)
    difat=[s for s in struct.unpack_from('<109I',b,76) if s!=0xffffffff]
    if u32(b,68) != 0xFFFFFFFE:raise ValueError('Extended OLE DIFAT not supported')
    fat=[]
    for s in difat:fat+=list(struct.unpack_from('<%dI'%(sec//4),b,(s+1)*sec))
    def chain(start,index,source,part,max_steps=40000):
        out=bytearray();s=start;seen=set()
        while s not in END and s not in seen and 0<=s<len(index) and len(seen)<max_steps:
            seen.add(s);out+=source[s*part:(s+1)*part];s=index[s]
        return bytes(out)
    data=b[512:]; directory=chain(u32(b,48),fat,data,sec)
    ent=[]
    for p in range(0,len(directory),128):
        e=directory[p:p+128]
        if len(e)<128:break
        n=u16(e,64)
        if n>=2:ent.append((e[:n-2].decode('utf-16le','replace'),e[66],*struct.unpack_from('<IQ',e,116)))
    work=next((e for e in ent if e[0].lower() in ('workbook','book')),None)
    if not work:raise ValueError('No workbook stream')
    if work[3]<u32(b,56):
        root=next(e for e in ent if e[1]==5)
        miniroot=chain(root[2],fat,data,sec)[:root[3]]
        mf=chain(u32(b,60),fat,data,sec)
        idx=list(struct.unpack('<%dI'%(len(mf)//4),mf))
        book=chain(work[2],idx,miniroot,mini)[:work[3]]
    else:book=chain(work[2],fat,data,sec)[:work[3]]
    recs=[];p=0
    while p+4<=len(book):
        tag,n=struct.unpack_from('<HH',book,p)
        if p+4+n>len(book):break
        recs.append((tag,p,book[p+4:p+4+n]));p+=4+n
    strings=[]
    for i,(tag,_,dat) in enumerate(recs):
        if tag==0xfc:
            blocks=[dat];j=i+1
            while j<len(recs) and recs[j][0]==0x3c:
                blocks.append(recs[j][2]);j+=1
            strings=_decode_sst(blocks)
            break
    offsets=[]
    for tag,_,d in recs:
        if tag==0x85:
            off,_,_,n=struct.unpack_from('<IBBB',d);flag=d[7]
            name=d[8:8+n*(2 if flag&1 else 1)].decode('utf-16le' if flag&1 else 'latin1','replace')
            offsets.append((off,name))
    offsets.sort(); results={name:collections.defaultdict(dict) for _,name in offsets}
    def put(pos,r,c,v):
        dest=next((name for off,name in reversed(offsets) if pos>=off),None)
        if dest is not None:results[dest][r][c]=v
    def rk(k):
        if k&2:
            v=k>>2
            if v & 0x20000000:v-=0x40000000
        else:v=struct.unpack('<d',struct.pack('<II',0,k&0xFFFFFFFC))[0]
        return v/100 if k&1 else v
    for tag,pos,d in recs:
        if tag==0xfd:
            r,c,_,i=struct.unpack_from('<HHHI',d)
            put(pos,r,c,strings[i] if i<len(strings) else '')
        elif tag==0x203:
            r,c,_=struct.unpack_from('<HHH',d);put(pos,r,c,struct.unpack_from('<d',d,6)[0])
        elif tag==0x27e:
            r,c,_,k=struct.unpack_from('<HHHI',d);put(pos,r,c,rk(k))
        elif tag==0xbd:
            r,first=struct.unpack_from('<HH',d); last=u16(d,len(d)-2)
            for col in range(first,last+1):put(pos,r,col,rk(u32(d,4+6*(col-first)+2)))
        elif tag==0x6:
            r,c,_=struct.unpack_from('<HHH',d)
            if d[12:14]!=b'\xff\xff':put(pos,r,c,struct.unpack_from('<d',d,6)[0])
        elif tag==0x204:
            r,c,_,n=struct.unpack_from('<HHHH',d)
            put(pos,r,c,d[8:8+n].decode('latin1','replace'))
    return {s:dict(rows) for s,rows in results.items()}

def _xlsx_rows(path):
    ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    with zipfile.ZipFile(path) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in e.findall('.//x:t',ns)) for e in root.findall('x:si',ns)]
        workbook=ET.fromstring(z.read('xl/workbook.xml'))
        relationships=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rels={e.attrib['Id']:e.attrib['Target'] for e in relationships}
        result={}
        for sh in workbook.findall('.//x:sheet',ns):
            name=sh.attrib['name']; target=rels[sh.attrib['{%s}id'%ns['r']]]
            target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            target=target.replace('xl/xl/','xl/')
            root=ET.fromstring(z.read(target));rows=collections.defaultdict(dict)
            for row in root.findall('.//x:sheetData/x:row',ns):
                ri=int(row.attrib['r'])-1
                for cell in row.findall('x:c',ns):
                    addr=cell.attrib['r']; col=0
                    for char in re.match(r'[A-Z]+',addr).group():col=col*26+ord(char)-64
                    col-=1
                    v=cell.find('x:v',ns);inline=cell.find('.//x:is/x:t',ns)
                    if inline is not None:val=inline.text or ''
                    elif v is None:continue
                    elif cell.attrib.get('t')=='s':val=shared[int(v.text)]
                    elif cell.attrib.get('t') in ('str','e'):val=v.text or ''
                    else:
                        try:val=float(v.text)
                        except (TypeError,ValueError):val=v.text
                    rows[ri][col]=val
            result[name]=dict(rows)
        return result

def read_workbook(path):
    suffix=Path(path).suffix.lower()
    if suffix=='.xls':return _biff_rows(path)
    if suffix=='.xlsx':return _xlsx_rows(path)
    raise ValueError('Only .xls and .xlsx are supported for automated import')

def num(value):
    if isinstance(value,(int,float)):return float(value)
    s=str(value or '').replace(',','').strip()
    if not s:return 0.0
    minus=s.startswith('(') and s.endswith(')')
    try:return -float(s.strip('()')) if minus else float(s)
    except ValueError:return 0.0

def date_from_rows(rows):
    from datetime import datetime
    for r in sorted(rows)[:6]:
        for v in rows[r].values():
            found=re.search(r'(?:Date:\s*|From Date:\s*|\b)(\d{2}/\d{2}/\d{4})',str(v),re.I)
            if found:
                try:return datetime.strptime(found.group(1),'%d/%m/%Y').strftime('%Y-%m-%d')
                except ValueError:pass
    return None
