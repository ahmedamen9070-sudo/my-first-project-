"""Sky Star Daily Sales engine v2.0 PREVIEW; no side effects at import time."""
from __future__ import annotations
import hashlib,json,re,sqlite3,os,shutil,tempfile
from datetime import datetime,timedelta,date
from pathlib import Path
from collections import Counter,defaultdict
from contextlib import closing
from decimal import Decimal,ROUND_HALF_UP
from comsys_reader import read_workbook,date_from_rows,num

TYPE_NAMES={
'Department_Summary':'Department Summary','Department_Details':'Department Details',
'Cashier_Summary':'Cashier Summary','Cashier_Audit':'Cashier Audit',
'Voided_Transactions':'Voided Transactions','Posting_Summary':'Posting Summary',
'Rooms_Situation_Report':'Rooms Situation','Out_of_Order_Rooms':'Out of Order Rooms',
'Company_Revenue':'Company Revenue','Complimentary_Report':'Complimentary Report',
'House_Use_Report':'House Use Report','Night_Report':'Night Report',
'Rooms_Summary':'Rooms Summary','F____B_Report':'F&B Report',
'Inhouse_Guests':'Guest In House','Guest_In_House':'Guest In House',
'Daily_Sales':'Daily Sales'}
DATE_RE=re.compile(r'\d\d/\d\d/\d\d\d\d')

def money(v):return float(Decimal(str(v)).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
def val(row,i):return num(row.get(i,0))
def clean(v):
    # Excel numeric cells arrive as floats even for integral identifiers. Keep
    # room/voucher IDs usable by the same validation as text cells, and retain
    # numeric zero as an actual value (not an empty, missing amount).
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        return str(int(v)) if isinstance(v,float) and v.is_integer() else str(v)
    return str(v or '').strip()
def normal_date(d):return datetime.strptime(d,'%Y-%m-%d').date()

def parse_source(path, date_override=None):
    sheets=read_workbook(path)
    if not sheets:raise ValueError('No worksheet found')
    sn,rows=next(iter(sheets.items()))
    report_type=TYPE_NAMES.get(sn)
    if not report_type:
        words=sn.lower().replace('_',' ')
        report_type=next((v for k,v in TYPE_NAMES.items() if k.lower().replace('_',' ') in words),None)
    if not report_type:raise ValueError(f'Unrecognized Comsys report type: {sn}')
    # A range export (e.g., 01-10 Oct) cannot represent a single daily source.
    # Check labelled range in the report header, not dates in guest detail rows.
    headers=' '.join(str(v) for idx in sorted(rows)[:12] for v in rows[idx].values())
    bounds=re.search(r'From Date:\s*(\d{2}/\d{2}/\d{4}).{0,90}?To Date:\s*(\d{2}/\d{2}/\d{4})',headers,re.I|re.S)
    if bounds and bounds.group(1)!=bounds.group(2):
        raise ValueError('Source is a multi-day report ('+bounds.group(1)+' to '+bounds.group(2)+
                         '); daily import requires the SAME From/To Business Date.')
    extracted=date_from_rows(rows)
    d=extracted or date_override
    if not d:raise ValueError('No readable business date in report; do not infer one from the selected date.')
    origin='report_header' if extracted else 'manually_verified'
    if date_override and extracted and extracted!=date_override:
        raise ValueError('Report date conflicts with selected date; override is not permitted.')
    if report_type=='Department Summary':payload=parse_department(rows)
    elif report_type=='Daily Sales':payload=parse_daily_sales(rows)
    elif report_type=='Cashier Summary':payload=parse_cashier(rows)
    elif report_type=='Rooms Situation':payload=parse_rooms(rows)
    elif report_type=='Out of Order Rooms':payload=parse_ooo(rows)
    elif report_type=='Company Revenue':payload=parse_company(rows)
    elif report_type=='Guest In House':payload=parse_guest_inhouse(rows)
    elif report_type=='F&B Report':payload=parse_fnb(rows)
    elif report_type=='Posting Summary':payload=parse_posting(rows)
    elif report_type in ('Complimentary Report','House Use Report'):payload=parse_special(rows)
    elif report_type=='Night Report':payload=parse_night(rows)
    elif report_type=='Voided Transactions':payload=parse_void(rows)
    elif report_type=='Rooms Summary':payload=parse_folios(rows)
    elif report_type in ('Department Details','Cashier Audit'):payload=parse_evidence(rows,report_type)
    else:payload={'status':'unsupported'}
    payload['source_rows']=len(rows)
    return {'date':d,'kind':report_type,'filename':Path(path).name,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'payload':payload,'date_origin':origin}

def parse_daily_sales(rows):
    """Independent Comsys Daily Sales reference only, not financial postings.

    The Comsys M.T.D. column may include dates outside the configured start
    date; it must NEVER be imported as our own approved MTD.
    """
    lines={}
    for r in sorted(rows):
        z=rows[r]; label=clean(z.get(0))
        if label:
            lines[label]={
                'today': money(val(z,1)),
                'comsys_mtd_reference':money(val(z,4)),
                'text_today':clean(z.get(1))
            }
    required={'Total Hotel','Total Room Rate','Total Food','Total Bevarage','Total Other',
              'Rooms Occupied','Rooms Available'}
    missing=required-set(lines)
    if missing:raise ValueError('Daily Sales report does not contain required Comsys rows: '+', '.join(sorted(missing)))
    return {'lines':lines,
            'revenue_today':lines.get('Total Hotel',{}).get('today'),
            'room_revenue_today':lines.get('Total Room Rate',{}).get('today'),
            'food_today':lines.get('Total Food',{}).get('today'),
            'beverage_today':lines.get('Total Bevarage',{}).get('today'),
            'other_today':lines.get('Total Other',{}).get('today'),
            'paid_rooms_today':lines.get('Rooms Occupied',{}).get('today'),
            'operating_rooms_today':lines.get('Rooms Available',{}).get('today'),
            'comsys_mtd_reference':lines.get('Total Hotel',{}).get('comsys_mtd_reference')}

def parse_department(rows):
    codes=[];totals={}; ledger={}
    for r in sorted(rows):
        z=rows[r]; name=clean(z.get(0)); match=re.match(r'^(\d{3})\s+(.+)$',name)
        if match:
            code=int(match[1]);label=match[2]
            if val(z,1) or val(z,2) or val(z,3):codes.append({'code':code,'label':label,'today':money(val(z,1)),'mtd':money(val(z,2)),'ytd':money(val(z,3))})
        elif name.startswith('Total ') or name=='Grand Total':
            totals[name]={'today':money(val(z,1)),'mtd':money(val(z,2)),'ytd':money(val(z,3))}
        elif name in ('Carried Forward','Today','M.T.D.','Y.T.D.'):
            ledger[name]={'debit':money(val(z,1)),'credit':money(val(z,2)),'balance':money(val(z,3))}
        if name=='Total Balance':ledger['closing_balance']=money(val(z,3))
    if not codes or 'Grand Total' not in totals:
        raise ValueError('Department Summary is missing the department rows or Grand Total; export the original Comsys report.')
    return {'codes':codes,'totals':totals,'ledger':ledger}

def parse_cashier(rows):
    people=[]
    for r in sorted(rows):
        z=rows[r];name=clean(z.get(0))
        if not name or name.isdigit() or name in ('User ID','Total','Grand Total'):continue
        if r<4 or not any(val(z,c) for c in (1,2,3,4,5)):continue
        people.append({'cashier':name,'cash':money(val(z,1)),'city_ledger':money(val(z,2)),
                       'card':money(val(z,3)),'transfer_activity':money(val(z,4)),'other':money(val(z,5))})
    return {'people':people,'totals':{key:money(sum(p[key] for p in people)) for key in ('cash','city_ledger','card','transfer_activity','other')}}

def parse_rooms(rows):
    info=[]
    for r in sorted(rows):
        if r<4:continue
        z=rows[r]; room=clean(z.get(0));
        if not room.isdigit() or len(room)>5:continue
        info.append({'room':room,'type':clean(z.get(1)),'available':clean(z.get(2)).upper(),
                     'status':clean(z.get(3)),'remark':clean(z.get(7))})
    if not info:
        raise ValueError('Room Situation has no physical room records; check the report layout.')
    types=Counter(x['type'] for x in info if x['status'].upper()!='OOO' and x['room']!='1301')
    included=[x for x in info if x['room']!='1301' and x['status'].upper()!='OOO']
    vacancy=sum(x['status'].lower()=='vacant' for x in included)
    comp_rooms=sorted(x['room'] for x in included if 'comp' in x['remark'].lower())
    hu_rooms=sorted(x['room'] for x in included if 'h/u' in x['remark'].lower() or 'house use' in x['remark'].lower())
    comp=len(comp_rooms);hu=len(hu_rooms)
    rev_occ=len(included)-vacancy-comp-hu
    return {'room_records':len(info),'physical_count':len([x for x in info if x['room']!='1301']),
            'ooo_in_rooms':len([x for x in info if x['status'].upper()=='OOO']),
            'outside_guest_records':len([x for x in info if x['room']=='1301']),
            'available_for_sale':len(included),'vacant':vacancy,'comp':comp,'house_use':hu,
            'complimentary_rooms':comp_rooms,'house_use_rooms':hu_rooms,
            'paid_room_ids':sorted(x['room'] for x in included
                if x['status'].lower()!='vacant' and x['room'] not in comp_rooms and x['room'] not in hu_rooms),
            'revenue_occupied':rev_occ,'room_type_counts':dict(types),
            'oos_occupied':[x['room'] for x in included if 'OOS' in x['status'].upper()]}

def parse_ooo(rows):
    entries=[]
    for r in sorted(rows):
        z=rows[r];id_=clean(z.get(0))
        if r<4 or not id_.isdigit():continue
        entries.append({'room':id_,'from':clean(z.get(1)),'to':clean(z.get(2)),
                        'reason':clean(z.get(3)),'approved_by':clean(z.get(4))})
    return {'rooms':entries,'count':len(entries)}

def parse_guest_inhouse(rows):
    """Read an in-house register without assuming nationality is a free-room flag.

    Comsys can export paid-only guest lists with filters 'Exclude H/U' and
    'Exclude Complimentary'.  The special reports carry those other rooms.
    """
    guests=[];excluded=[];unknown_flags=[]
    header=' '.join(clean(v) for r in sorted(rows)[:8] for v in rows[r].values()).casefold()
    excludes_hu='exclude h/u' in header or 'exclude house use' in header
    excludes_comp='exclude complimentary' in header
    headings=next((rows[r] for r in sorted(rows)[:12] if clean(rows[r].get(0)).strip().lower()=='room'),{})
    # Only columns explicitly headed as free-room flags can be read as such.
    hu_cols=[i for i,v in headings.items() if clean(v).casefold() in ('h/u','house use','h/u flag','house use flag')]
    comp_cols=[i for i,v in headings.items() if clean(v).casefold() in ('comp','complimentary','comp flag','complimentary flag')]
    # These are values in *explicitly labelled* Comsys status columns, not company codes.
    hu_positives={'y','yes','true','1','x','h/u','hu','house use','mgmt','management'}
    comp_positives={'y','yes','true','1','x','comp','complimentary','gm','g.m','g.m.'}
    for r in sorted(rows):
        z=rows[r];room=clean(z.get(0))
        if r<5 or not room.isdigit() or len(room)>5:continue
        if room=='1301':excluded.append(room);continue
        pax=clean(z.get(2)).split('/')
        def integer_at(i):
            try:return int(float(pax[i]))
            except (IndexError,ValueError,TypeError):return 0
        hu=any(clean(z.get(i)).casefold() in hu_positives for i in hu_cols)
        comp=any(clean(z.get(i)).casefold() in comp_positives for i in comp_cols)
        for col,accepted in [(i,hu_positives) for i in hu_cols]+[(i,comp_positives) for i in comp_cols]:
            marker=clean(z.get(col)).casefold()
            if marker and marker not in accepted and marker not in ('n','no','false','0','-'):
                unknown_flags.append({'room':room,'column':col,'marker':marker})
        if hu and comp:
            unknown_flags.append({'room':room,'column':'both','marker':'Conflicting H/U and Comp flags'})
        kind='hu' if hu else 'comp' if comp else 'paid'
        guests.append({'room':room,'company':clean(z.get(7)),
                       'adults':integer_at(0),'children':integer_at(1),
                       'infants':integer_at(2),'kind':kind,
                       'meal_pattern':clean(z.get(3))})
    unknown_status=not (excludes_hu and excludes_comp) and not (hu_cols and comp_cols)
    return {'guests':guests,'rooms':len(guests),'excluded_dummy':excluded,
            'paid':sum(z['kind']=='paid' for z in guests),
            'complimentary':sum(z['kind']=='comp' for z in guests),
            'house_use':sum(z['kind']=='hu' for z in guests),
            'adults':sum(z['adults'] for z in guests),
            'children':sum(z['children'] for z in guests),
            'infants':sum(z['infants'] for z in guests),
            'excludes_complimentary':excludes_comp,
            'excludes_house_use':excludes_hu,
            'status_ambiguous':unknown_status,'unknown_flags':unknown_flags}

def parse_company(rows):
    companies=[];totals={}
    for r in sorted(rows):
        z=rows[r]; n=clean(z.get(0))
        if r<5 or not n:continue
        obj={'company':n,'pax':clean(z.get(1)),'single':int(val(z,2)), 'double':int(val(z,3)),
             'triple':int(val(z,4)),'quad':int(val(z,5)),'other_type':int(val(z,6)),
             'suite':int(val(z,7)),'rooms':int(val(z,8)),'room_revenue':money(val(z,9)),
             'fnb_revenue':money(val(z,12)),'other_revenue':money(val(z,13)),'total_revenue':money(val(z,14))}
        if n.lower()=='total':totals=obj
        else:companies.append(obj)
    return {'companies':companies,'totals':totals}

def normalize_meal_pattern(raw):
    """Map Comsys abbreviated display labels onto configured Meal Pattern codes."""
    s=str(raw or '').strip().upper().replace('  ',' ')
    if s in ('BB','B&B','BED & BREAKFAST','BED AND BREAKFAST'):return 'BB'
    if s in ('HB','HALF BOARD','HALF B'):return 'HB'
    if s in ('FB','FULL BOARD','FULL B'):return 'FB'
    if s in ('BED','BED ONLY','ROOM ONLY'):return 'BED'
    if s in ('HAN','HN','HARD ALL I','HARD ALL','HARD ALL INCLUSIVE','HARD ALL INCLU','HARD ALL INC'):return 'HAN'
    if s in ('AN','ALLL INCLU','ALL INCLU','ALL INCLUSIVE','ALL INCL','SOFT ALL INC','SOFT ALL INCLUSIVE'):return 'AN'
    return str(raw or '').strip() or 'Unknown'

def parse_fnb(rows):
    pattern=Counter();services=Counter();adults=Counter();children=Counter()
    for r in sorted(rows):
        z=rows[r]
        if r<4 or not clean(z.get(0)).isdigit():continue
        pat=normalize_meal_pattern(clean(z.get(6)))
        pattern[pat]+=1
        ages=clean(z.get(3)).split('/')
        a=int(ages[0]) if len(ages)>0 and ages[0].isdigit() else 0
        ch=int(ages[1]) if len(ages)>1 and ages[1].isdigit() else 0
        adults[pat]+=a;children[pat]+=ch
        for code in clean(z.get(7)).split(','):
            if code.strip():services[code.strip()]+=1
    return {'patterns':dict(pattern),'services_rooms':dict(services),'adults':dict(adults),'children':dict(children),
            'rooms_listed':sum(pattern.values()),'pax':sum(adults.values())+sum(children.values())}

def parse_posting(rows):
    items=[]; totals={}
    for r in sorted(rows):
        z=rows[r]; n=clean(z.get(0))
        if n.isdigit() and r>=4:
            items.append({'posting_item':n,'name':clean(z.get(1)),'net':money(val(z,2)),
                          'service':money(val(z,3)),'tax':money(val(z,4)),'other_tax':money(val(z,5)),
                          'gross':money(val(z,6))})
        elif 'Grand Total' in clean(z.get(1)):
            totals={'net':money(val(z,2)),'service':money(val(z,3)),'tax':money(val(z,4)),
                    'other_tax':money(val(z,5)),'gross':money(val(z,6))}
    return {'items':items,'totals':totals}

def parse_special(rows):
    details=[];report_total=None
    for r in sorted(rows):
        z=rows[r]; room=clean(z.get(0))
        if r>=4 and room.isdigit():details.append({'room':room,'pax':clean(z.get(2)), 'meal_pattern':clean(z.get(4)),
                                                   'reason':clean(z.get(9)),'approved_by':clean(z.get(10))})
        if report_total is None and 'Total Rooms' in clean(z.get(1)):
            m=re.search(r'\d+',clean(z.get(1))); report_total=int(m.group()) if m else None
    return {'count':len(details),'declared_count':report_total,'rooms':details}

def parse_night(rows):
    data={}
    for r in sorted(rows):
        z=rows[r];n=clean(z.get(0)).lower()
        if n=='occupied':data['rooms_occupied']=int(val(z,1));data['pax']=clean(z.get(2))
        elif n=='revenue' and 'revenue' not in data:data['revenue']=money(val(z,2))
        elif n=='avr. room rate' and 'adr' not in data:data['adr']=money(val(z,2))
        elif n=='% occupancy':
            if 'occupancy' not in data:data['occupancy']=clean(z.get(2))
    return data

def parse_void(rows):
    entries=[]; current=''
    for r in sorted(rows):
        z=rows[r];description=clean(z.get(0))
        if description=='Item':current=clean(z.get(5))
        elif r>4 and description.isdigit() and clean(z.get(6)):
            entries.append({'voucher':description,'posting_item':current,'user':clean(z.get(2)),
                            'room':clean(z.get(4)),'amount1':money(val(z,7)),'amount2':money(val(z,8))})
    return {'entries':entries,'void_sales_value':money(sum(x['amount2'] for x in entries)),
            'void_settlement_value':money(sum(x['amount1'] for x in entries))}

def parse_folios(rows):
    """Read the certified complete folio snapshot; never turn missing totals into zero."""
    totals={}
    for r in sorted(rows):
        z=rows[r];label=clean(z.get(2))
        if label.startswith('Total ') or label=='Grand Total':
            # Grand Total must contain its actual three monetary columns.
            for col in (8,9,10):
                value=clean(z.get(col))
                if not value or not re.fullmatch(r'\(?-?[\d,]+(?:\.\d{1,2})?\)?',value):
                    raise ValueError(f'Rooms Summary {label}: unreadable amount at column {col}; do not replace with zero.')
            totals[label]={'net':money(val(z,3)),'gross':money(val(z,8)),
                           'cash':money(val(z,9)),'credit':money(val(z,10))}
    required=('Total Pre-Arrivals','Total Inhouse Guests','Total Guests Checked Out Today',
              'Total Dummy Rooms','Grand Total')
    missing=[k for k in required if k not in totals]
    if missing:
        raise ValueError('Rooms Summary missing certified totals: '+', '.join(missing)+
                         '. Resend original Comsys XLS; never treat missing as zero.')
    for field in ('gross','cash','credit'):
        parts=money(sum(totals[x][field] for x in required[:-1]))
        if abs(parts-totals['Grand Total'][field])>.02:
            raise ValueError(f'Rooms Summary {field} Grand Total differs from section subtotals: '
                             f'{totals["Grand Total"][field]:,.2f} vs {parts:,.2f}.')
    total=totals['Grand Total']
    return {'folio_totals':totals,
            'computed_balance':money(total['gross']+total['cash']+total['credit']),
            'balance_scope':'All Rooms Summary categories, including Pre-Arrivals, Inhouse, Checked Out and Dummy Rooms',
            'validated':True}

def parse_evidence(rows,kind):
    if kind=='Cashier Audit':
        orig=sum(1 for r,z in rows.items() if r>3 and clean(z.get(0)).isdigit() and len(clean(z.get(0)))>=4)
        return {'rows':max(0,len(rows)-4),'original_id_rows':orig,'warning':'Audit trail contains revisions. Do not sum rows as sales or payments.'}
    room_1301=[]
    section=''
    for r in sorted(rows):
        z=rows[r]
        if clean(z.get(0))=='Department':
            section=clean(z.get(5))
        if clean(z.get(4))!='1301':continue
        match=re.match(r'^(\d{3})\s+(.+)$',section)
        if not match:continue
        code=int(match.group(1))
        # Revenue ONLY. Ignore tax, transfer, payment and adjustment sections.
        if code not in {101,102,103,104,105,199,903,201,202,203,204,205,250,251,252,253,299,
                        301,302,303,304,305,350,399,401,402,403,499,501,502,503,550,590}:
            continue
        amount=money(val(z,9))
        if amount:room_1301.append({'code':code,'label':match.group(2),'amount':amount})
    aggregates=defaultdict(float)
    for e in room_1301:aggregates[e['label']]+=e['amount']
    return {'rows':len(rows), 'dummy_room':'1301',
            'dummy_revenue_by_department':{k:money(v) for k,v in aggregates.items()},
            'dummy_revenue_total':money(sum(aggregates.values())),
            'warning':'Detail is reconciliation evidence only; no revenue or settlement is posted from this source.'}

class Store:
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.path)
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS days(day TEXT PRIMARY KEY,status TEXT NOT NULL DEFAULT 'Draft',
        commentary TEXT DEFAULT '',auditor_note TEXT DEFAULT '', updated TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sources(day TEXT NOT NULL,kind TEXT NOT NULL,filename TEXT,sha TEXT,payload TEXT,updated TEXT,
        PRIMARY KEY(day,kind),FOREIGN KEY(day) REFERENCES days(day));
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT,day TEXT,action TEXT,detail TEXT);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS source_versions(id INTEGER PRIMARY KEY AUTOINCREMENT,
            day TEXT NOT NULL,kind TEXT NOT NULL,filename TEXT,sha TEXT,payload TEXT,
            replaced_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS import_alerts(id INTEGER PRIMARY KEY AUTOINCREMENT,
            day TEXT NOT NULL,kind TEXT,filename TEXT NOT NULL,reported_date TEXT,
            message TEXT NOT NULL,resolved INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit_cases(
            id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL,
            code TEXT NOT NULL, severity TEXT NOT NULL, observation TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Open', owner TEXT NOT NULL DEFAULT '',
            created TEXT NOT NULL, updated TEXT NOT NULL,
            UNIQUE(day,code),FOREIGN KEY(day) REFERENCES days(day));
        CREATE TABLE IF NOT EXISTS audit_case_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL,
            at TEXT NOT NULL, old_status TEXT, new_status TEXT NOT NULL,
            owner TEXT NOT NULL DEFAULT '', note TEXT NOT NULL,
            FOREIGN KEY(case_id) REFERENCES audit_cases(id));
        ''')
        self._migrate_report_exceptions()
        self.db.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',
                        ('reporting_start_date','2026-10-10'))
        self.db.commit()
    def _migrate_report_exceptions(self):
        self.db.execute("CREATE TABLE IF NOT EXISTS report_exceptions("
                        "day TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind='F&B Report'),"
                        "reason TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL,"
                        "PRIMARY KEY(day,kind),FOREIGN KEY(day) REFERENCES days(day))")

    def report_unavailable_reason(self,day,kind):
        row=self.db.execute('SELECT reason FROM report_exceptions WHERE day=? AND kind=?',
                            (day,kind)).fetchone()
        return row[0] if row else None

    def set_report_unavailable(self,day,kind,reason):
        """Document one unavailable F&B source; never approve or fabricate data."""
        normal_date(day)
        if kind!='F&B Report':
            raise ValueError('Only F&B Report can have a documented unavailable-source exception.')
        reason=str(reason or '').strip()
        if len(reason)<12:
            raise ValueError('Explain why F&B Report is unavailable (at least 12 characters).')
        if self.status(day)=='Closed':
            raise ValueError(f'{day} is Closed. Reopen with an auditor note before changing source exceptions.')
        if kind in self.day(day):
            raise ValueError('F&B Report is already imported for this business date.')
        prior=self.report_unavailable_reason(day,kind)
        if prior==reason:
            return reason
        stamp=datetime.now().isoformat(timespec='seconds')
        with self.db:
            self.ensure(day)
            self.db.execute('INSERT INTO report_exceptions(day,kind,reason,created,updated) VALUES(?,?,?,?,?) '
                            'ON CONFLICT(day,kind) DO UPDATE SET reason=excluded.reason,updated=excluded.updated',
                            (day,kind,reason,stamp,stamp))
            self.db.execute('UPDATE days SET status=?,updated=? WHERE day=?',('Pending Review',stamp,day))
            self.event(day,'REPORT_UNAVAILABLE',kind+' | '+reason)
        return reason

    def _approval_warnings(self,day):
        warnings=[item for item in checks(self.day(day)) if item['level']=='WARNING']
        reason=self.report_unavailable_reason(day,'F&B Report')
        if reason and 'F&B Report' not in self.day(day):
            warnings.append({'code':'FNB_SOURCE_UNAVAILABLE','level':'WARNING',
                             'message':'F&B Report unavailable: '+reason+
                             '. Meal counts and package averages are not available.'})
        return warnings

    def ensure(self,d):
        self.db.execute('INSERT OR IGNORE INTO days(day,updated) VALUES(?,?)',(d,datetime.now().isoformat(timespec='seconds')))
    def get_setting(self,key,default=None):
        row=self.db.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        return row[0] if row else default
    def set_setting(self,key,value):
        if key!='reporting_start_date':raise ValueError('Unsupported setting')
        value=normal_date(value).isoformat()
        prior=self.get_setting(key)
        self.db.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',(key,value))
        if prior!=value:self.event(None,'MTD_START_CHANGED',f'Prior: {prior} | New: {value}; previous approved days not altered.')
        self.db.commit()
    def reporting_start(self,day):
        selected=normal_date(day)
        first=selected.replace(day=1)
        configured=normal_date(self.get_setting('reporting_start_date','2026-10-10'))
        return min(selected,max(first,configured))
    def add_import_alert(self,day,filename,message,kind=None,reported=None):
        self.db.execute('INSERT INTO import_alerts(day,kind,filename,reported_date,message,created) '
                        'VALUES(?,?,?,?,?,?)',
                        (day,kind,filename,reported,message,datetime.now().isoformat(timespec='seconds')))
        self.db.commit()
    def active_import_alerts(self,day):
        return self.db.execute('SELECT id,kind,filename,reported_date,message FROM import_alerts '
                               'WHERE day=? AND resolved=0 ORDER BY id DESC',(day,)).fetchall()
    def dismiss_import_alerts(self,day):
        self.db.execute('UPDATE import_alerts SET resolved=1 WHERE day=?',(day,))
        self.ensure(day)
        self.event(day,'REJECTED_IMPORTS_REVIEWED','Rejected import alerts dismissed manually')
        self.db.commit()
    def save_sources_batch(self, reports, overwrite_kinds=()):
        """Commit a validated import batch atomically, keeping replaced source history.

        All files must be pre-parsed and share exactly one business date. A
        database or integrity error rolls back every change in this batch.
        """
        if not reports:
            return []
        dates={r['date'] for r in reports}
        kinds=[r['kind'] for r in reports]
        if len(dates)!=1:
            raise ValueError('Reports contain different business dates: no files were saved.')
        if len(kinds)!=len(set(kinds)):
            raise ValueError('The selected batch contains multiple copies of the same report type. Choose one version.')
        d=next(iter(dates));normal_date(d)
        if self.status(d)=='Closed':
            raise ValueError(f'{d} is Closed. Reopen with an auditor note before importing changes.')
        current={row[0]:(row[1],row[2]) for row in self.db.execute('SELECT kind,sha,payload FROM sources WHERE day=?',(d,))}
        conflicts=[r['kind'] for r in reports if r['kind'] in current and current[r['kind']][0]!=r['sha256']]
        unauthorized=set(conflicts)-set(overwrite_kinds)
        if unauthorized:
            raise ValueError('Replacement approval required for: '+', '.join(sorted(unauthorized)))
        results=[]; stamp=datetime.now().isoformat(timespec='seconds')
        with self.db:
            self.ensure(d)
            for report in reports:
                kind=report['kind'];existing=current.get(kind)
                payload_json=json.dumps(report['payload'],ensure_ascii=False)
                parser_updated=bool(existing and existing[0]==report['sha256'] and
                                    json.loads(existing[1])!=report['payload'])
                if kind=='F&B Report':
                    removed=self.db.execute('DELETE FROM report_exceptions WHERE day=? AND kind=?',(d,kind))
                    if removed.rowcount:
                        self.event(d,'REPORT_AVAILABLE',kind+' | Unavailable-source exception cleared after source import')
                if existing and existing[0]==report['sha256'] and not parser_updated:
                    results.append((kind,'skipped'))
                    continue
                if existing:
                    self.db.execute('INSERT INTO source_versions(day,kind,filename,sha,payload,replaced_at) '
                       'SELECT day,kind,filename,sha,payload,? FROM sources WHERE day=? AND kind=?',
                       (stamp,d,kind))
                self.db.execute('INSERT OR REPLACE INTO sources VALUES(?,?,?,?,?,?)',
                    (d,kind,report['filename'],report['sha256'],
                     payload_json,stamp))
                self.event(d,'SOURCE_REPARSED' if parser_updated else 'SOURCE_REPLACED' if existing else 'SOURCE_IMPORTED',kind+' | '+report['filename'])
                self.db.execute('UPDATE import_alerts SET resolved=1 WHERE day=? AND kind=?',(d,kind))
                if report.get('date_origin')=='manually_verified':
                    self.event(d,'MANUAL_SOURCE_DATE',kind+' | '+report['filename'])
                results.append((kind,'reprocessed' if parser_updated else 'replaced' if existing else 'imported'))
            if any(action!='skipped' for _,action in results):
                self.db.execute('UPDATE days SET status=?,updated=? WHERE day=?',('Pending Review',stamp,d))
        return results

    def save_source(self,src):
        current=self.db.execute('SELECT sha FROM sources WHERE day=? AND kind=?',
                                (src['date'],src['kind'])).fetchone()
        allow=(src['kind'],) if current else ()
        return self.save_sources_batch([src],overwrite_kinds=allow)[0][1]

    def source_history(self,d):
        return self.db.execute('SELECT kind,filename,replaced_at FROM source_versions '
                               'WHERE day=? ORDER BY id DESC',(d,)).fetchall()

    def create_backup(self,path):
        target=Path(path)
        if target.resolve()==self.path.resolve():
            raise ValueError('Backup path cannot be the active database.')
        target.parent.mkdir(parents=True,exist_ok=True)
        self.db.commit()
        with closing(sqlite3.connect(target)) as backup:
            self.db.backup(backup)
            result=backup.execute('PRAGMA integrity_check').fetchone()[0]
            if result!='ok':raise ValueError('Backup database integrity check failed: '+result)
        return target

    def restore_backup(self,path):
        """Validate external SQLite first; save current data before replacing."""
        source=Path(path)
        if not source.is_file() or source.resolve()==self.path.resolve():
            raise ValueError('Select a DIFFERENT existing SQLite backup file.')
        with closing(sqlite3.connect(f'file:{source.as_posix()}?mode=ro',uri=True)) as check:
            if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise ValueError('Backup failed SQLite integrity check; no data changed.')
            tables={r[0] for r in check.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            required={'days','sources','settings','events','import_alerts'}
            if not required.issubset(tables):
                raise ValueError('Not a compatible Sky Star v8 database; no data changed.')
            check.execute('SELECT day,status FROM days LIMIT 1').fetchall()
            check.execute('SELECT day,kind,payload FROM sources LIMIT 1').fetchall()
        before=self.path.with_name(self.path.stem+'_before_restore_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite')
        self.create_backup(before)
        fd,tempfile_path=tempfile.mkstemp(prefix='.skystar_restore_',suffix='.sqlite',dir=self.path.parent)
        os.close(fd)
        try:
            with closing(sqlite3.connect(source)) as source_db, closing(sqlite3.connect(tempfile_path)) as out:
                source_db.backup(out)
                if out.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise ValueError('Staged restore failed integrity check.')
            self.db.close()
            os.replace(tempfile_path,self.path)
            self.db=sqlite3.connect(self.path)
            self.db.execute('PRAGMA foreign_keys=ON')
            # A compatible earlier v8 backup may not have the new version-history table.
            self.db.execute('CREATE TABLE IF NOT EXISTS source_versions('
                'id INTEGER PRIMARY KEY AUTOINCREMENT,day TEXT NOT NULL,kind TEXT NOT NULL,'
                'filename TEXT,sha TEXT,payload TEXT,replaced_at TEXT NOT NULL)')
            # v8.2 backups do not have a structured post-close audit register.
            self.db.execute('CREATE TABLE IF NOT EXISTS audit_cases('
                'id INTEGER PRIMARY KEY AUTOINCREMENT,day TEXT NOT NULL,code TEXT NOT NULL,'
                "severity TEXT NOT NULL,observation TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Open',"
                "owner TEXT NOT NULL DEFAULT '',created TEXT NOT NULL,updated TEXT NOT NULL,UNIQUE(day,code))")
            self.db.execute('CREATE TABLE IF NOT EXISTS audit_case_history('
                'id INTEGER PRIMARY KEY AUTOINCREMENT,case_id INTEGER NOT NULL,at TEXT NOT NULL,'
                "old_status TEXT,new_status TEXT NOT NULL,owner TEXT NOT NULL DEFAULT '',"
                'note TEXT NOT NULL)')
            self._migrate_report_exceptions()
            for closed_day, in self.db.execute("SELECT day FROM days WHERE status='Closed'").fetchall():
                self._register_approval_warnings(closed_day,self._approval_warnings(closed_day))
            self.db.commit()
        except Exception:
            Path(tempfile_path).unlink(missing_ok=True)
            # Recover the connection if it was closed before the swap completed.
            try:self.db.execute('SELECT 1')
            except sqlite3.ProgrammingError:
                self.db=sqlite3.connect(self.path)
                self.db.execute('PRAGMA foreign_keys=ON')
            raise
        return before

    def close_eligibility(self,d):
        src=self.day(d)
        # All daily sources remain required except a separately documented
        # unavailable F&B Report. The exception never supplies meal data or
        # changes existing approved dates.
        required=set(TYPE_NAMES.values())
        # A Guest In House export filtered to paid guests alone is not a source
        # for complimentary/H.U. headcount.  Require the specialized lists
        # before promising a complete one-row-per-company occupancy statement.
        guest=src.get('Guest In House',{})
        rooms=src.get('Rooms Situation',{})
        if rooms.get('comp',0) and guest.get('excludes_complimentary'):
            required.add('Complimentary Report')
        if rooms.get('house_use',0) and guest.get('excludes_house_use'):
            required.add('House Use Report')
        unavailable={}
        reason=self.report_unavailable_reason(d,'F&B Report')
        if reason and 'F&B Report' not in src:
            unavailable['F&B Report']=reason
        missing=sorted(required-set(src)-set(unavailable))
        blockers=[item['message'] for item in checks(src) if item['level']=='BLOCKER']
        for kind in missing:
            note=kind+' missing from selected business date.'
            if not any(kind in b for b in blockers):blockers.append(note)
        if self.active_import_alerts(d):
            blockers.append('Unresolved wrong-date/import alerts. Correct or review them privately first.')
        return {'missing':missing,'blockers':blockers,'unavailable':unavailable,
                'warnings':[item['message'] for item in self._approval_warnings(d)]}

    def list_audit_cases(self,day=None,include_resolved=True):
        """Private reviewer case register. Closed business days remain immutable while
        cases/notes can be investigated and resolved independently afterward.
        """
        query='SELECT id,day,code,severity,observation,status,owner,created,updated FROM audit_cases'
        where=[];args=[]
        if day is not None:
            where.append('day=?');args.append(day)
        if not include_resolved:where.append("status!='Resolved'")
        if where:query+=' WHERE '+' AND '.join(where)
        return [dict(zip(('id','day','code','severity','observation','status','owner','created','updated'),r))
                for r in self.db.execute(query+" ORDER BY CASE WHEN status='Resolved' THEN 1 ELSE 0 END,day DESC,id",args)]

    def audit_case_history(self,case_id):
        return [dict(zip(('at','old_status','status','owner','note'),r)) for r in
                self.db.execute('SELECT at,old_status,new_status,owner,note FROM audit_case_history '
                                'WHERE case_id=? ORDER BY id',(int(case_id),))]

    def _register_approval_warnings(self,d,warnings):
        stamp=datetime.now().isoformat(timespec='seconds')
        src=self.day(d)
        for warning in warnings:
            code=warning['code'];detail=warning['message']
            if code=='VOID_PAIR' and 'Voided Transactions' in src:
                report=src['Voided Transactions']
                entries=report.get('entries',[])
                vouchers=', '.join(str(v.get('voucher')) for v in entries if v.get('voucher'))
                detail=(f"Voucher(s) {vouchers or 'not identified'} | Void sales {report['void_sales_value']:,.2f} "
                        f"vs related void settlements {report['void_settlement_value']:,.2f}. "
                        'Investigate original check, Pool Bar postings, cashier audit and void reason; '
                        'do not change revenue automatically.')
            elif code=='FOLIO_GUEST_LEDGER' and 'Rooms Summary' in src:
                folio=src['Rooms Summary'].get('computed_balance')
                ledger=metrics(src).get('guest_ledger_closing')
                if folio is not None and ledger is not None:
                    detail=(f'Rooms Summary folio snapshot {folio:,.2f}; Comsys Guest Ledger closing '
                            f'{ledger:,.2f}; difference (Ledger - Folio) {ledger-folio:,.2f}. '
                            'Investigate report scope, cut-off and exclusions; no automatic journal.')
            self.db.execute('INSERT OR IGNORE INTO audit_cases(day,code,severity,observation,status,created,updated) '
                            'VALUES(?,?,?,?,?,?,?)',(d,code,warning['level'],detail,'Open',stamp,stamp))
            row=self.db.execute('SELECT id FROM audit_cases WHERE day=? AND code=?',(d,code)).fetchone()
            existing=self.db.execute('SELECT 1 FROM audit_case_history WHERE case_id=? LIMIT 1',(row[0],)).fetchone()
            if not existing:
                self.db.execute('INSERT INTO audit_case_history(case_id,at,old_status,new_status,owner,note) '
                    'VALUES(?,?,?,?,?,?)',(row[0],stamp,None,'Open','',
                    'Created at Daily Sales approval; revenue auditor to investigate separately.'))

    def update_audit_case(self,case_id,status,owner,note):
        """Follow-up without reopening/recalculating the approved business date."""
        status=str(status).strip()
        if status not in ('Open','Under Review','Resolved'):
            raise ValueError('Select Open, Under Review, or Resolved.')
        note=str(note).strip();owner=str(owner).strip()
        if len(note)<8:
            raise ValueError('Enter an investigation comment (at least 8 characters).')
        if len(owner)>120:raise ValueError('Auditor/owner name is too long.')
        row=self.db.execute('SELECT day,status FROM audit_cases WHERE id=?',(int(case_id),)).fetchone()
        if row is None:raise ValueError('Audit case not found.')
        if status=='Resolved' and len(note)<15:
            raise ValueError('Resolution needs a clear explanation (at least 15 characters).')
        stamp=datetime.now().isoformat(timespec='seconds')
        with self.db:
            self.db.execute('UPDATE audit_cases SET status=?,owner=?,updated=? WHERE id=?',
                            (status,owner,stamp,int(case_id)))
            self.db.execute('INSERT INTO audit_case_history(case_id,at,old_status,new_status,owner,note) '
                            'VALUES(?,?,?,?,?,?)',(int(case_id),stamp,row[1],status,owner,note))
            self.event(row[0],'AUDIT_CASE_FOLLOW_UP',f'Case #{case_id} {row[1]} -> {status}; owner {owner}')
        return True

    def approve_day(self,d,comsys_closed=False):
        state=self.close_eligibility(d)
        if state['blockers']:
            raise ValueError('Approval blocked:\n'+'\n'.join(state['blockers'][:12]))
        if state['warnings'] and len(self.notes(d)[1])<12:
            raise ValueError('Unresolved warnings require an auditor note (at least 12 characters).')
        if not comsys_closed:
            raise ValueError('Confirm that Comsys Night Audit is completed for this business date.')
        self.ensure(d)
        with self.db:
            warnings=self._approval_warnings(d)
            self._register_approval_warnings(d,warnings)
            self.db.execute('UPDATE days SET status=?,updated=? WHERE day=?',
                            ('Closed',datetime.now().isoformat(timespec='seconds'),d))
            self.event(d,'DAY_APPROVED',
                       f'Comsys Night Audit confirmed; {len(warnings)} warning(s) saved in private follow-up register')
        return True

    def event(self,d,action,detail):self.db.execute('INSERT INTO events(at,day,action,detail) VALUES(?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),d,action,detail))
    def status(self,d):
        a=self.db.execute('SELECT status FROM days WHERE day=?',(d,)).fetchone();return a[0] if a else 'Draft'
    def day(self,d):
        rows=self.db.execute('SELECT kind,payload FROM sources WHERE day=?',(d,)).fetchall()
        return {kind:json.loads(data) for kind,data in rows}
    def sources(self,d):return self.db.execute('SELECT kind,filename,updated FROM sources WHERE day=? ORDER BY kind',(d,)).fetchall()
    def days(self):return [x[0] for x in self.db.execute('SELECT day FROM days ORDER BY day DESC')]
    def save_notes(self,d,commentary=None,auditor_note=None):
        self.ensure(d)
        if commentary is not None:self.db.execute('UPDATE days SET commentary=? WHERE day=?',(commentary,d))
        if auditor_note is not None:self.db.execute('UPDATE days SET auditor_note=? WHERE day=?',(auditor_note,d))
        self.event(d,'REVIEW_UPDATED','Commentary/auditor notes saved');self.db.commit()
    def notes(self,d):
        x=self.db.execute('SELECT commentary,auditor_note FROM days WHERE day=?',(d,)).fetchone();return (x[0] or '',x[1] or '') if x else ('','')
    def set_status(self,d,status):
        self.ensure(d);status=status if status in ('Draft','Pending Review','Closed') else 'Draft'
        self.db.execute('UPDATE days SET status=?,updated=? WHERE day=?',(status,datetime.now().isoformat(timespec='seconds'),d));self.event(d,'STATUS_CHANGED',status);self.db.commit()
    def close(self):self.db.close()

def metrics(sources):
    out={'rooms':0.,'food':0.,'beverage':0.,'other':0.,'adjustment':0.,'transportation':0.,
         'revenue':0.,'net_revenue':0.,'taxes':0.,'cash':0.,'card':0.,'city_ledger':0.,
         'total_settlements':0.,'grand_total':0.,'mtd_reference':None,'ytd_reference':None}
    dep=sources.get('Department Summary')
    if dep:
        codes=dep['codes']; get=lambda c,key='today':sum(x[key] for x in codes if x['code'] in c)
        out.update(rooms=money(get({101,102,103,104,105,199,903})),food=money(get({201,202,203,204,205,250,251,252,299})),
                   beverage=money(get({253,301,302,303,304,305,399})),
                   other=money(get({350,401,402,403,404,499,501,502,503,550,590})),
                   adjustment=money(get({599})),transportation=money(get({904})),
                   taxes=money(get({701,702,703,704,705})),
                   cash=money(-get({801,802,803})),card=money(-get({811,812,813,814})),
                   city_ledger=money(-get({821,822})))
        # Some Comsys category 404 is labelled Taxes, not other revenue; correct classification by explicit mapping.
        out['other']=money(out['other']-get({404}))
        out['revenue']=money(sum(out[k] for k in ('rooms','food','beverage','other')))
        out['net_revenue']=money(out['revenue']+out['adjustment']+out['transportation'])
        out['total_settlements']=money(out['cash']+out['card']+out['city_ledger'])
        out['grand_total']=money(dep['totals'].get('Grand Total',{}).get('today',0))
        out['mtd_reference']=dep['totals'].get('Grand Total',{}).get('mtd')
        out['ytd_reference']=dep['totals'].get('Grand Total',{}).get('ytd')
        out['guest_ledger_closing']=dep.get('ledger',{}).get('closing_balance')
        out['checks']={'posting_net_movement':money(out['net_revenue']+out['taxes']-out['total_settlements']-out['grand_total'])}
    rooms=sources.get('Rooms Situation')
    if rooms:
        out.update({k:rooms[k] for k in ('physical_count','available_for_sale','revenue_occupied','vacant','comp','house_use','ooo_in_rooms')})
        a=rooms['available_for_sale'];n=rooms['revenue_occupied']
        out['occupancy']=round(n/a*100,2) if a else 0
        out['adr']=round(out['rooms']/n,2) if n else 0
        out['revpar']=round(out['rooms']/a,2) if a else 0
    return out

def checks(src):
    m=metrics(src); problems=[]
    def flag(code,level,message):problems.append({'code':code,'level':level,'message':message})
    for need in ('Department Summary','Rooms Situation','Cashier Summary','Guest In House'):
        if need not in src:flag('MISSING_'+need.upper().replace(' ','_'),'BLOCKER',need+' not imported: financial close cannot be approved.')
    if 'Department Summary' in src:
        if abs(m['checks']['posting_net_movement'])>0.02:
            flag('POSTING_BALANCE','BLOCKER',f'Posting movement does not balance by {m["checks"]["posting_net_movement"]:,.2f}. Check source and mapping.')
        if 'Cashier Summary' in src:
            c=src['Cashier Summary']['totals']
            for k,ck in [('cash','cash'),('card','card'),('city_ledger','city_ledger')]:
                diff=money(m[k]-c[ck])
                if abs(diff)>0.02:flag('CASHIER_'+k.upper(),'BLOCKER',f'{k}: Department Summary vs Cashier Summary difference {diff:,.2f}.')
        if 'Posting Summary' in src:
            p=src['Posting Summary']['totals']
            if p and abs(m['grand_total']-p['gross'])>0.02:flag('POSTING_SUMMARY','WARNING',f'Posting Summary gross / Dept. grand difference {money(m["grand_total"]-p["gross"]):,.2f}.')
    if 'Rooms Situation' in src:
        rm=src['Rooms Situation']
        if rm['physical_count'] != 179:flag('INVENTORY','WARNING',f'Room physical count {rm["physical_count"]} differs from hotel master 179; verify room registry.')
        if 'Out of Order Rooms' in src:
            o=src['Out of Order Rooms']['count']
            if rm['ooo_in_rooms']!=o:flag('OOO_MISMATCH','WARNING',f'Out-of-Order report {o} vs Room Situation {rm["ooo_in_rooms"]}.')
        if rm['oos_occupied']:flag('OOS_OCCUPIED','NOTICE','Occupied, OOS (not OOO) rooms: '+', '.join(rm['oos_occupied']))
        for label,kind,key in (('Complimentary','Complimentary Report','complimentary_rooms'),
                                ('House Use','House Use Report','house_use_rooms')):
            if kind in src:
                expected={str(x['room']) for x in src[kind]['rooms']}
                recorded=set(rm.get(key,()))
                if expected!=recorded:
                    only_special=', '.join(sorted(expected-recorded)) or 'none'
                    only_situation=', '.join(sorted(recorded-expected)) or 'none'
                    flag('SPECIAL_ROOM_CONFLICT','BLOCKER',
                        f'{label} room-status conflict: in {kind} but not Rooms Situation = {only_special}; '
                        f'in Rooms Situation but not {kind} = {only_situation}. '
                        'Reconcile the room IDs in Comsys before management export.')
    if 'Guest In House' in src:
        guests=src['Guest In House']
        # Paid and certified special-room occupants must cover each usable room once.
        from inhouse_company import complete_guest_payload
        full=complete_guest_payload(src)
        if 'Rooms Situation' in src:
            situation=src['Rooms Situation']
            usable=situation['revenue_occupied']+situation['comp']+situation['house_use']
            if full['rooms']!=usable:
                flag('COMPANY_ROOM_MIX_INCOMPLETE','BLOCKER',
                    f'Certified guest rooms {full["rooms"]} vs occupied+Comp+H/U {usable}. Check guest source completeness.')
        for person in full.get('guests',[]):
            a=int(person.get('adults') or 0)
            if not 1<=a<=4:
                flag('UNCLASSIFIED_OCCUPANCY','BLOCKER',
                    f'Room {person["room"]} has {a} adults; review before publishing Single/Double/Triple/Quad.')
        from inhouse_company import occupancy_from_guests
        names=[c['company'] for c in src.get('Company Revenue',{}).get('companies',[])]
        groups,issues=occupancy_from_guests(guests,names)
        for message in issues:flag('GUEST_DUPLICATE','BLOCKER',message)
        for unsupported in guests.get('unknown_flags',[]):
            flag('GUEST_UNKNOWN_STATUS','BLOCKER',f'Room {unsupported["room"]}: unknown Comsys status flag {unsupported["marker"]} in column {unsupported["column"]}; verify classification.')
        if guests.get('status_ambiguous'):
            flag('GUEST_STATUS_UNKNOWN','BLOCKER',
                 'Guest In House has no reliable paid / complimentary / H/U status flags or exclusion filters. '
                 'Export an explicitly filtered paid-only register or verified flagged columns.')
        if 'Rooms Situation' in src:
            rm=src['Rooms Situation']
            if guests['paid']!=rm['revenue_occupied']:
                flag('GUEST_PAID','BLOCKER',f'Guest In House paid {guests["paid"]} vs Rooms Situation {rm["revenue_occupied"]}.')
            # New imports include actual paid room IDs, not counts alone.
            if 'paid_room_ids' in rm:
                roster={str(g['room']) for g in guests['guests'] if g.get('kind')=='paid'}
                checked=set(rm['paid_room_ids'])
                if roster!=checked:
                    flag('GUEST_ROOM_ID_MISMATCH','BLOCKER',
                         'Room IDs differ between Guest In House and Rooms Situation; '
                         'Guest-only: '+(', '.join(sorted(roster-checked)) or 'none')+
                         '; Situation-only: '+(', '.join(sorted(checked-roster)) or 'none'))
            # The paid-only export is NOT evidence that complimentary / H.U. are zero.
            if not guests.get('excludes_complimentary') and guests['complimentary']!=rm['comp']:
                flag('GUEST_COMPLIMENTARY','BLOCKER','Guest In House complimentary count differs from Rooms Situation.')
            if not guests.get('excludes_house_use') and guests['house_use']!=rm['house_use']:
                flag('GUEST_HOUSE_USE','BLOCKER','Guest In House house use count differs from Rooms Situation.')
        ambiguous=[x['room'] for x in guests['guests'] if x['company'].strip().casefold()=='comp' and x['kind']!='comp']
        if ambiguous:
            flag('COMP_CODE_REVIEW','WARNING','Comsys company code Comp appears on room(s) '+', '.join(ambiguous)+
                 ' without the Complimentary room flag. Confirm the coding; no Comp Paid category is defined.')
        if 'Company Revenue' in src:
            revenue=src['Company Revenue']['companies']
            for co in revenue:
                label='Comp (PMS company code)' if co['company'].casefold()=='complimentary' else co['company']
                found=groups.get(label)
                if not found:
                    flag('COMPANY_GUEST_MISSING','BLOCKER',f'Company Revenue label {co["company"]} not resolved in Guest In House.')
                elif found['rooms']!=co['rooms']:
                    flag('COMPANY_GUEST_COUNT','BLOCKER',f'{co["company"]}: Guest In House {found["rooms"]} vs Company Revenue {co["rooms"]} rooms.')
                elif str(co.get('pax','')).split('/')[0].strip().isdigit() and found['adults']!=int(str(co['pax']).split('/')[0]):
                    flag('COMPANY_ADULT_COUNT','BLOCKER',f'{co["company"]}: Inhouse adult count does not match Company Revenue pax adults.')
    if 'Daily Sales' in src:
        ds=src['Daily Sales']
        if 'Department Summary' in src:
            for label,key in (('Total Hotel','revenue'),('Total Room Rate','rooms'),
                              ('Total Food','food'),('Total Bevarage','beverage'),('Total Other','other')):
                reference=ds['lines'].get(label,{}).get('today')
                if reference is not None and abs(m[key]-reference)>0.02:
                    flag('DAILY_SALES_'+key.upper(),'BLOCKER',
                         f'Comsys Daily Sales {label} {reference:,.2f} vs Department Summary {m[key]:,.2f}.')
        if 'Rooms Situation' in src:
            for label,key in (('Rooms Occupied','revenue_occupied'),('Rooms Available','available_for_sale')):
                reference=ds['lines'].get(label,{}).get('today')
                if reference is not None and abs(m[key]-reference)>.01:
                    flag('DAILY_SALES_ROOMS','BLOCKER',
                         f'Comsys Daily Sales {label} {reference:,.0f} vs Rooms Situation {m[key]:,.0f}.')
    if 'Night Report' in src and 'Department Summary' in src:
        night=src['Night Report']
        if night.get('revenue') is not None and abs(night['revenue']-m['rooms'])>.02:
            flag('NIGHT_ROOM_REVENUE','BLOCKER','Night Report room revenue disagrees with Department Summary.')
    if 'Company Revenue' in src and 'Department Summary' in src:
        v=src['Company Revenue']['totals'].get('total_revenue',0)
        diff=money(m['revenue']-v)
        if abs(diff)>0.02:
            detail=src.get('Department Details',{})
            dummy=detail.get('dummy_revenue_total')
            if dummy is not None and abs(diff-dummy)<=.02:
                segments=', '.join(f'{k}: {a:,.2f}' for k,a in detail['dummy_revenue_by_department'].items())
                flag('COMPANY_TOTAL','NOTICE',
                     f'Company Revenue {v:,.2f} vs Hotel Revenue {m["revenue"]:,.2f}; '
                     f'difference {diff:,.2f} traced to outside/dummy room 1301: {segments}. '
                     'Already included in hotel revenue. DO NOT add revenue again; verify classification.')
            elif dummy is None:
                flag('COMPANY_TOTAL','NOTICE',
                     f'Company Revenue {v:,.2f} vs Hotel Revenue {m["revenue"]:,.2f}; '
                     f'difference {diff:,.2f}; historical Department Details payload has no '
                     'room-level reconciliation. Re-import originals on an open date to trace; do not double-count.')
            else:
                flag('COMPANY_TOTAL','WARNING',
                     f'Company Revenue {v:,.2f} vs Hotel Revenue {m["revenue"]:,.2f}; '
                     f'difference {diff:,.2f} not explained by room 1301 revenue '
                     f'{dummy:,.2f}. Investigate source; no automatic journal.')
        if abs(src['Company Revenue']['totals'].get('room_revenue',0)-m['rooms'])>0.02:
            flag('COMPANY_ROOMS','BLOCKER','Company Room Revenue and Daily Room Revenue differ; fix source data before sign-off.')
    if 'Night Report' in src and 'Rooms Situation' in src:
        night=src['Night Report']
        if night.get('rooms_occupied')!=m.get('revenue_occupied'):
            flag('NIGHT_ROOM','WARNING','Night Report occupied differs from Room Situation.')
    if 'Voided Transactions' in src:
        v=src['Voided Transactions']
        if abs(v['void_sales_value']-v['void_settlement_value'])>0.02:
            flag('VOID_PAIR','WARNING','Voided sales and related settlement amounts do not match.')
    if 'Rooms Summary' in src and 'Department Summary' in src:
        # Guest folio balances are not automatically equal to Guest Ledger by definition.
        folios=src['Rooms Summary']
        folio=folios.get('computed_balance') if folios.get('validated') else None
        ledger=m.get('guest_ledger_closing')
        gap=money(ledger-folio) if folio is not None and ledger is not None else None
        if gap is None:
            flag('FOLIO_GUEST_LEDGER','WARNING',
                 'Rooms Summary does not have a verified Grand Total. Re-import the actual original XLS '
                 'using the updated reader; no zero folio balance is inferred.')
        elif abs(gap)>0.02:
            flag('FOLIO_GUEST_LEDGER','WARNING',
                 f'Validated Rooms Summary total exposure {folio:,.2f} vs Guest Ledger closing '
                 f'{ledger:,.2f}: difference {gap:,.2f}. These sources may cover different account scopes; '
                 'requires independent mapping/cut-off review, NOT an automatic adjustment.')
        else:
            flag('FOLIO_SCOPE','NOTICE',
                 f'Rooms Summary snapshot {folio:,.2f} matches Guest Ledger closing; '
                 'different report purposes still apply. Never sum snapshots as daily revenue.')
    if 'Cashier Audit' in src:flag('AUDIT_TRAIL','NOTICE','Cashier Audit has revision rows; do not sum them as new settlements. Audit exceptions may require manual investigation.')
    return problems

def monthly(store,d):
    d0=store.reporting_start(d);to=normal_date(d)
    included=[];waiting=[]
    cursor=d0
    while cursor<=to:
        day=cursor.isoformat()
        if store.status(day)=='Closed' and 'Department Summary' in store.day(day):included.append(day)
        else:waiting.append(day)
        cursor+=timedelta(days=1)
    sums=defaultdict(float);occupied=available=0
    for day in included:
        a=metrics(store.day(day))
        for k in ('rooms','food','beverage','other','adjustment','taxes','revenue','net_revenue','cash','card','city_ledger'):
            sums[k]+=a.get(k,0)
        if 'available_for_sale' in a:
            occupied+=a['revenue_occupied'];available+=a['available_for_sale']
    sums={k:money(v) for k,v in sums.items()}
    # Cross-check the normalized month-to-date hotel revenue against Comsys cumulative
    # department codes only when the complete day sequence exists.
    latest=store.day(d).get('Department Summary')
    if latest and not waiting and d0==to.replace(day=1):
        codes=latest['codes']; ignore={599,904,701,702,703,704,705,801,802,803,811,812,813,814,821,822,601,901,902}
        # Selected mapped hotel revenue codes, never full Grand Total/Guest Ledger.
        revenue_codes={101,102,103,104,105,199,903,201,202,203,204,205,250,251,252,299,
                       253,301,302,303,304,305,399,350,401,402,403,499,501,502,503,550,590}
        ref=money(sum(x['mtd'] for x in codes if x['code'] in revenue_codes))
        sums['comsys_mtd_revenue_reference']=ref
        sums['mtd_revenue_difference']=money(sums.get('revenue',0)-ref)
    sums.update(days_closed=len(included),missing=waiting,days_expected=(to-d0).days+1,
                occupancy=round(occupied/available*100,2) if available and not waiting else None,
                occupied_room_nights=occupied,available_room_nights=available,
                complete=not waiting)
    return sums

def generate_commentary(store,d):
    src=store.day(d);m=metrics(src); ex=checks(src);mt=monthly(store,d)
    chunks=[f'SKY STAR HOTEL - DAILY SALES MANAGEMENT COMMENTARY',f'Business Date: {d}   |   Status: {store.status(d)}',
            '', '1. EXECUTIVE SUMMARY']
    if 'Department Summary' in src:
        chunks+=[f'The hotel recorded revenue of {m["revenue"]:,.2f} on the Daily Sales presentation basis, comprising room revenue {m["rooms"]:,.2f}, food {m["food"]:,.2f}, beverage {m["beverage"]:,.2f}, and other income {m["other"]:,.2f}.',
                 f'Other-income adjustment {m["adjustment"]:,.2f}, transportation allocation {m["transportation"]:,.2f}, and taxes/service charges {m["taxes"]:,.2f} are shown separately; they are not additional cash sales.']
    else:chunks+=['Revenue not available: Department Summary has not been imported.']
    chunks+=['','2. ROOMS AND OCCUPANCY']
    if 'Rooms Situation' in src:
        chunks+=[f'The room register contains {m["physical_count"]} physical rooms, of which {m["ooo_in_rooms"]} are marked Out of Order. Operating inventory is {m["available_for_sale"]}; revenue-occupied rooms {m["revenue_occupied"]}, vacant rooms {m["vacant"]}, complimentary {m["comp"]}, and house-use {m["house_use"]}.',
                 f'Paid occupancy {m["occupancy"]:.2f}%, ADR {m["adr"]:,.2f} and RevPAR {m["revpar"]:,.2f}, calculated using operating inventory without deducting OOO a second time.']
    else:chunks+=['Rooms Situation missing. Occupancy KPIs cannot be validated for this date.']
    chunks+=['','3. FOOD & BEVERAGE AND ENTITLEMENTS']
    if 'F&B Report' in src:
        ent=src['F&B Report'];chunks+=[f'F&B entitlement roster lists {ent["rooms_listed"]} rooms and {ent["pax"]} registered adults/children. Patterns: '+', '.join(f'{k}={v}' for k,v in ent['patterns'].items())+'.',
              'Meal-code room entitlements: '+', '.join(f'{k}={v}' for k,v in ent['services_rooms'].items())+'.',
              'These are entitlement counts, not meals served or cash sales. AN includes soft beverages, with hard beverages chargeable; HAN includes both within the booking.']
    else:chunks+=['F&B entitlement roster not supplied for this business date. No consumption figures are assumed.']
    if 'Voided Transactions' in src:
        v=src['Voided Transactions'];chunks+=[f'Voided transaction evidence: {len(v["entries"])} financial lines; voided charge value {v["void_sales_value"]:,.2f} with linked settlement value {v["void_settlement_value"]:,.2f}. Do not count both legs as additional voided sales or deduct the void a second time from Comsys net revenue.']
    chunks+=['','4. COMPANY REVENUE']
    if 'Company Revenue' in src:
        co=src['Company Revenue'];chunks+=[f'Company Revenue covers {co["totals"].get("rooms",0)} room nights and total revenue {co["totals"].get("total_revenue",0):,.2f}.',
               'Room/company segmentation is a classification of existing hotel revenue, not an additional revenue stream.']
        named=sorted(co['companies'],key=lambda x:x['total_revenue'],reverse=True)
        chunks.append('Leading company categories: '+', '.join(f'{x["company"]}: {x["total_revenue"]:,.2f}' for x in named[:5])+'.')
    else:chunks+=['Company Revenue not supplied for this date.']
    if 'Complimentary Report' in src:
        x=src['Complimentary Report'];chunks.append(f'Complimentary report lists {x["count"]} complimentary rooms; approvals are retained for audit, not counted as extra room revenue.')
    if 'House Use Report' in src:
        x=src['House Use Report'];chunks.append(f'House Use report lists {x["count"]} internal-use room(s), separate from paid occupancy.')
    chunks+=['','5. COLLECTIONS AND FINANCIAL CONTROLS']
    if 'Cashier Summary' in src:
        c=src['Cashier Summary']['totals'];chunks+=[f'Cash {c["cash"]:,.2f}; credit cards {c["card"]:,.2f}; City Ledger {c["city_ledger"]:,.2f} (account transfer, not cash received). Cash/card/City Ledger settlements total {sum(c[z] for z in ("cash","card","city_ledger")):,.2f}.',
               f'Gross cashier transfer activity {c["transfer_activity"]:,.2f} is not added to collections.']
    else:chunks+=['Cashier Summary not supplied. Settlement reconciliation not confirmed.']
    if 'Department Summary' in src:
        chunks+=[f'Department posting movement grand total: {m["grand_total"]:,.2f}. This is a ledger movement, NOT hotel revenue or a profitability measure.']
    chunks+=['','6. AUDIT FINDINGS AND EXCEPTIONS']
    if ex:
        for x in ex:chunks.append(f'- [{x["level"]}] {x["code"]}: {x["message"]}')
    else:chunks+=['- All implemented cross-report checks have passed. This does not constitute a complete transaction-level audit.']
    chunks+=['','7. MONTH-TO-DATE COMPLETENESS']
    if mt['complete']:
        chunks+=[f'The approved MTD is complete through {d}: {mt["days_closed"]} days posted; room {mt.get("rooms",0):,.2f}, food {mt.get("food",0):,.2f}, beverage {mt.get("beverage",0):,.2f}, other {mt.get("other",0):,.2f}.']
        if 'mtd_revenue_difference' in mt:
            chunks.append(f'Comsys mapped MTD revenue reference {mt["comsys_mtd_revenue_reference"]:,.2f}; calculated closed-day MTD difference {mt["mtd_revenue_difference"]:,.2f}.')
    else:
        sample=', '.join(mt['missing'][:7]);suffix=' ...' if len(mt['missing'])>7 else ''
        chunks+=[f'INCOMPLETE MTD: {len(mt["missing"])} business date(s) between the first of the month and {d} are not approved: {sample}{suffix}. Do not circulate an accumulated MTD figure as final.']
    chunks+=['','8. MANAGEMENT ACTIONS',
             'Investigate and document unresolved differences, confirm the Comsys night closing, then approve the business date. Any interpretation not supported by source reports requires management confirmation.',
             '', 'Prepared by: ____________________    Reviewed by: ____________________',
             ('INTERNAL MANAGEMENT REPORT - DATE CLOSED; FINAL RELEASE STILL REQUIRES REVIEW SIGN-OFF.' if store.status(d)=='Closed' else 'INTERNAL MANAGEMENT REPORT - NOT APPROVED UNTIL THE BUSINESS DATE IS CLOSED.')]
    return '\n'.join(chunks)
