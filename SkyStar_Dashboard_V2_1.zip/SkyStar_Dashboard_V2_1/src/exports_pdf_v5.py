"""Sky Star compact landscape A4: every material KPI has TODAY/MTD.

All MTD values come from closed-day, same-report uploads only; the coverage strip
states incompleteness and source-specific gaps. No cross-date joins or doubling.
"""
from pathlib import Path
import re
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from engine import metrics,checks
from mtd_detail import detail,values_for_fnb
from exports_pdf_v4 import meal_plan_pdf
from exports_pdf_v3 import pdf_export as legacy_pdf_export
W,H=landscape(A4)
NAVY='#183148'; TEAL='#117A76'; BLUE='#EAF2F6'; GRAY='#647688'; LINE='#D8E2E8'; ORANGE='#98622D';INK='#21364A'

def font(c,size=8,bold=False,color=INK):
    c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.setFillColor(HexColor(color))
def tx(c,x,y,s,size=8,bold=False,color=INK,clip=None):
    s=str(s)
    if clip:
        f='Helvetica-Bold' if bold else 'Helvetica'
        if stringWidth(s,f,size)>clip:
            while s and stringWidth(s+'..',f,size)>clip:s=s[:-1]
            s+='..'
    font(c,size,bold,color);c.drawString(x,y,s)
def rt(c,x,y,s,size=8,bold=False,color=INK):font(c,size,bold,color);c.drawRightString(x,y,str(s))
def bg(c,x,y,w,h,color):c.setFillColor(HexColor(color));c.rect(x,y,w,h,stroke=0,fill=1)
def ln(c,x,y,x2,y2,color=LINE):c.setStrokeColor(HexColor(color));c.setLineWidth(.6);c.line(x,y,x2,y2)
def fmt(v,kind='amt'):
    if v is None:return '--'
    if kind=='pct':return f'{v:.2f}%'
    if kind=='num':return f'{v:,.0f}'
    return f'{v:,.2f}'
def section(c,x,y,name,width):
    bg(c,x,y-5,width,20,BLUE);tx(c,x+7,y+1,name,9,True,NAVY)
def cell_line(c,x,y,label,dv,mv,w,kind='amt',idx=0):
    if idx%2==0:bg(c,x,y-4,w,15,'#F7FAFB')
    tx(c,x+7,y,str(label),7.7,False,INK,clip=w*.50)
    rt(c,x+w-91,y,fmt(dv,kind),8,False)
    rt(c,x+w-6,y,fmt(mv,kind),8,True,TEAL)
def report(store,d,path):
    src=store.day(d)
    if not src:raise ValueError('No Comsys reports for this business date.')
    mm=metrics(src);mt=detail(store,d);flags=checks(src)
    financial=mt['financial'];roommt=mt['rooms'];status=store.status(d)
    def f(k,source='Department Summary'):
        return financial.get(k) if mt['coverage'][source] else None
    def r(k):return roommt.get(k) if mt['coverage']['Rooms Situation'] else None
    def dval(k,source):return mm.get(k) if source in src else None
    path=str(path);Path(path).parent.mkdir(parents=True,exist_ok=True)
    c=canvas.Canvas(path,pagesize=(W,H),pageCompression=1);c.setTitle(f'Sky Star Daily Sales - Today and MTD - {d}')
    bg(c,0,H-34,W,34,NAVY)
    tx(c,24,H-23,'Sky Star Daily Sales',16,True,'#FFFFFF')
    rt(c,W-24,H-20,d+'  |  '+status.upper()+'  |  PREVIEW / REVIEW REQUIRED',8.2,True,'#D6E5EA')
    # Cumulative coverage must always be visible, not implied by zero.
    rev_cov=mt['coverage']['Department Summary']; room_cov=mt['coverage']['Rooms Situation'];fb_cov=mt['coverage']['F&B Report'];co_cov=mt['coverage']['Company Revenue']
    cover=f'APPROVED MTD COVERAGE: Revenue {rev_cov}/{mt["expected"]} days  |  Rooms {room_cov}/{mt["expected"]}  |  Meal Plans {fb_cov}/{mt["expected"]}  |  Companies {co_cov}/{mt["expected"]}'
    bg(c,22,529,W-44,24,'#EDF5F6');tx(c,30,537,cover,8.5,True,NAVY)
    if min(rev_cov,room_cov,fb_cov,co_cov)<mt['expected']:
        tx(c,24,513,'MTD VALUES SHOWN ARE PARTIAL. Missing / unapproved dates are never counted as zero; -- means no closed source.',7.6,True,ORANGE)
    else:tx(c,24,513,'MTD complete from approved Comsys business dates through '+d,7.6,True,TEAL)
    left=24;right=431;wid=386
    # Vertical sections, finance left + room right.
    section(c,left,487,'REVENUE / POSTINGS',wid);section(c,right,487,'ROOMS / OCCUPANCY',wid)
    rt(c,left+wid-91,468,'TODAY',7.3,True,GRAY);rt(c,left+wid-6,468,'MTD',7.3,True,TEAL)
    rt(c,right+wid-91,468,'TODAY',7.3,True,GRAY);rt(c,right+wid-6,468,'MTD',7.3,True,TEAL)
    finance_rows=[('Room Revenue','rooms'),('Food Revenue','food'),('Beverage Revenue','beverage'),('Other Income','other'),
                  ('HOTEL REVENUE','revenue'),('Revenue Adjustment','adjustment'),('Transportation','transportation'),
                  ('Service + Taxes','taxes'),('Net Posted Revenue','net_revenue')]
    for i,(label,k) in enumerate(finance_rows):
        cell_line(c,left,450-i*16,label,dval(k,'Department Summary'),f(k),wid,idx=i)
    room_rows=[('Physical Rooms (snapshot)','physical_count','num'),('OOO / OOO room-nights','ooo_in_rooms','num'),
               ('Operating / Available room-nights','available_for_sale','num'),('Paid Occupied / room-nights','revenue_occupied','num'),
               ('Vacant / vacant room-nights','vacant','num'),('Complimentary / room-nights','comp','num'),
               ('House Use / room-nights','house_use','num'),('Paid Occupancy','occupancy','pct'),
               ('ADR','adr','amt'),('RevPAR','revpar','amt')]
    for i,(label,k,kind) in enumerate(room_rows):
        cell_line(c,right,450-i*16,label,dval(k,'Rooms Situation'),r(k),wid,kind,idx=i)
    ln(c,left,298,W-24,298)
    # Meal plan every daily entitlement has independent approved cumulative room / pax nights.
    section(c,left,280,'MEAL PLAN - ROOM-NIGHTS / PAX-NIGHTS',wid)
    tx(c,left+6,260,'PLAN',7,True,GRAY)
    for offset,label in ((150,'ROOMS D'),(204,'ROOMS MTD'),(260,'PAX D'),(330,'PAX MTD')):rt(c,left+offset,260,label,6.8,True,TEAL)
    fb=src.get('F&B Report');todaymeals=values_for_fnb(fb) if fb else {};monthmeal=mt['meal_plans']
    mealorder=['BB','HB','FB','AN','HAN','BED']
    for i,plan in enumerate(mealorder):
        y=243-i*16
        if i%2==0:bg(c,left,y-4,wid,15,'#F7FAFB')
        tx(c,left+6,y,plan,8.0,True)
        t=todaymeals.get(plan);v=monthmeal.get(plan)
        for offset,val in ((150,t['rooms'] if t else (0 if fb else None)),(204,v.get('rooms',0) if mt['coverage']['F&B Report'] else None),
                           (260,t['pax'] if t else (0 if fb else None)),(330,v.get('pax',0) if mt['coverage']['F&B Report'] else None)):
            rt(c,left+offset,y,fmt(val,'num'),7.9,False)
    # Company room nights and classified revenue: includes F&B allocations, never extra hotel sales.
    section(c,right,280,'COMPANIES - ROOMS / TOTAL REVENUE (INCL. F&B)',wid)
    tx(c,right+6,260,'COMPANY',7,True,GRAY)
    for offset,label in ((192,'RMS D'),(242,'RMS M'),(312,'REV D'),(380,'REV M')):rt(c,right+offset,260,label,7,True,TEAL)
    companies=src.get('Company Revenue',{}).get('companies',[])
    cnames={x['company'] for x in companies}|set(mt['companies'])
    names=sorted(cnames,key=lambda n:next((x['total_revenue'] for x in companies if x['company']==n),0),reverse=True)
    today_by={x['company']:x for x in companies}; allnames=names[:6]
    if len(names)>6:allnames=names[:5]+['OTHER COMPANIES']
    def cs(n,key,monthly=False):
        if monthly:
            if mt['coverage']['Company Revenue']==0:return None
            if n=='OTHER COMPANIES':return sum(mt['companies'].get(x,{}).get(key,0) for x in names[5:])
            return mt['companies'].get(n,{}).get(key,0)
        if 'Company Revenue' not in src:return None
        if n=='OTHER COMPANIES':return sum(today_by.get(x,{}).get(key,0) for x in names[5:])
        return today_by.get(n,{}).get(key,0)
    for i,name in enumerate(allnames):
        y=243-i*16
        if i%2==0:bg(c,right,y-4,wid,15,'#F7FAFB')
        tx(c,right+6,y,name,7.5,False,INK,clip=174)
        for offset,value,kind in ((192,cs(name,'rooms'), 'num'),(242,cs(name,'rooms',True),'num'),
                                  (312,cs(name,'total_revenue'),'amt'),(380,cs(name,'total_revenue',True),'amt')):
            rt(c,right+offset,y,fmt(value,kind),7.6,False)
    if not allnames:tx(c,right+6,224,'No same-date company details; none were invented.',8,False,ORANGE)
    # Bottom compact region.
    ln(c,24,138,W-24,138)
    section(c,left,121,'SETTLEMENTS (NOT REVENUE)',wid)
    rt(c,left+wid-91,102,'TODAY',7,True,GRAY);rt(c,left+wid-6,102,'MTD',7,True,TEAL)
    for i,(label,k) in enumerate((('Cash','cash'),('Credit cards','card'),('City Ledger','city_ledger'))):
        cell_line(c,left,86-i*15,label,dval(k,'Department Summary'),f(k),wid,idx=i)
    section(c,right,121,'NOTES / FOLLOW-UP',wid)
    manual=store.notes(d)[0]
    notes=[x.strip().lstrip('-* ').strip() for x in manual.splitlines() if x.strip()] if manual.strip() else []
    if not notes:
        for q in flags:
            if q['level'] not in ('BLOCKER','WARNING'):continue
            if q['code']=='COMPANY_TOTAL':
                match=re.search(r'unreconciled\s+([\d,.]+)',q['message'])
                notes.append('Company revenue difference '+(match.group(1) if match else '?')+' - needs allocation review.')
            elif q['code']=='FOLIO_GUEST_LEDGER':
                match=re.search(r'differ by\s+([\d,.]+)',q['message'])
                notes.append('Guest Ledger / folio variance '+(match.group(1) if match else '?')+' - investigate scope.')
            else:notes.append(q['message'])
            if len(notes)>=2:break
        if rev_cov < mt['expected']:notes.append(f'MTD incomplete: {mt["expected"]-rev_cov} day(s) lack approved revenue reports.')
        if not notes:notes=['No material differences in implemented controls; full audit remains separate.']
    for i,s in enumerate(notes[:3]):tx(c,right+8,103-i*16,str(i+1)+'. '+str(s),7.4,False,INK,clip=wid-17)
    ln(c,24,36,W-24,36)
    tx(c,24,24,'Amounts per Comsys source; MTD only includes closed, dated source reports. Meal entitlements are NOT consumption or extra sales.',7.3,False,GRAY)
    rt(c,W-24,24,'INTERNAL - NOT FOR CIRCULATION WITHOUT APPROVAL',7,True,ORANGE)
    c.showPage();c.save();return path

def pdf_export(store,d,path,mode='management'):
    if mode=='management':return report(store,d,path)
    if mode=='meal_plan':return meal_plan_pdf(store,d,path)
    return legacy_pdf_export(store,d,path,mode=mode)
