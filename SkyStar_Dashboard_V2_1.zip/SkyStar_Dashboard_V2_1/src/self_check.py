"""Non-destructive local installation check (does not read production data)."""
import sys,sqlite3,tempfile
from pathlib import Path

def main():
    errors=[]
    print('SKY STAR DAILY SALES - INSTALLATION CHECK')
    print('Python:',sys.version.split()[0])
    if sys.version_info<(3,10):errors.append('Python 3.10 or later is required')
    try:
        import tkinter
        print('Windows interface: OK (Tkinter available)')
    except ImportError:errors.append('Python Tkinter missing')
    try:
        import reportlab
        print('PDF engine: OK')
    except ImportError:errors.append('ReportLab missing. Run FIX_PDF_EXPORT_WINDOWS.bat')
    try:
        from engine import Store
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'check.sqlite')
            if store.get_setting('reporting_start_date')!='2026-10-10':
                errors.append('Initial MTD start date mismatch')
            store.create_backup(Path(d)/'backup.sqlite')
            store.close()
        print('Local database / backup: OK')
    except Exception as exc:errors.append('Database check: '+str(exc))
    if errors:
        print('\nFAILED:')
        for err in errors:print('- '+err)
        return 1
    print('\nALL INSTALLATION CHECKS PASSED. Existing v8.3 approved workspace is preserved by the v8.7 QA Fix update.')
    return 0
if __name__=='__main__':raise SystemExit(main())
