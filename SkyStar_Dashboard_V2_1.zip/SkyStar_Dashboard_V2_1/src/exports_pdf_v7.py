"""Compact one-sheet management daily: accurate Today/closed-day MTD.
No comments, no coverage bands; data remains strictly sourced and scoped.
"""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from engine import metrics
from mtd_detail import detail,values_for_fnb
from exports_pdf_v5 import pdf_export as previous_export
from company_mix import company_mix

W,H=landscape(A4)
NAVY='#1C3249'; TEAL='#087E85'; PALE='#E9F4F5'; LIGHT='#F7FAFC'; DIV='#D8E4EA'; WHITE='#FFFFFF'; INK='#24384A'; MUTE='#627889'
MONEY='amt'; INT='num'; PCT='pct'

# All coordinates are PDF points, origin bottom left.
def rect(c,x,y,w,h,color):
    c.setFillColor(HexColor(color));c.rect(x,y,w,h,fill=1,stroke=0)
def line(c,x,y,x2,y2,col=DIV):
    c.setStrokeColor(HexColor(col));c.setLineWidth(.45);c.line(x,y,x2,y2)
def t(c,x,y,s,size=7,color=INK,bold=False,maxw=None,align='left'):
    s=str(s);font='Helvetica-Bold' if bold else 'Helvetica'
    # Missing MTD values are muted gray, not blue decorative-looking dashes.
    if s=='—' and color==TEAL: color=MUTE
    if maxw is not None and stringWidth(s,font,size)>maxw:
        while s and stringWidth(s+'…',font,size)>maxw:s=s[:-1]
        s+='…'
    c.setFillColor(HexColor(color));c.setFont(font,size)
    {'left':c.drawString,'right':c.drawRightString,'center':c.drawCentredString}[align](x,y,s)
def number(v,kind='amt'):
    if v is None:return '—'
    if kind=='pct':return f'{v:,.2f}%'
    if kind=='num':return f'{v:,.0f}'
    return f'{v:,.2f}'
def bar(c,x,y,w,label,meta=None):
    """Card header: centered bold heading with reserved space for small column hints."""
    c.setFillColor(HexColor(NAVY))
    c.roundRect(x+.9,y-3,w-1.8,17.6,5.1,stroke=0,fill=1)
    t(c,x+w/2,y+2.3,label.upper(),9.1,WHITE,True,align='center')
    if meta and len(meta)<35:
        # Column aids only when they do not crowd the centered title.
        t(c,x+w-8,y+2.1,meta,5.8,'#CEE6EA',False,align='right')

def card_base(c,x,bottom,w,top):
    c.setFillColor(HexColor('#DFE8ED'))
    c.roundRect(x+1.2,bottom-1.5,w,top-bottom,7,fill=1,stroke=0)
    c.setFillColor(HexColor(WHITE))
    c.roundRect(x,bottom,w,top-bottom,7,fill=1,stroke=0)

def card_outline(c,x,bottom,w,top):
    c.setStrokeColor(HexColor('#CBD5DC'))
    c.setLineWidth(.85)
    c.roundRect(x,bottom,w,top-bottom,7,fill=0,stroke=1)

def financial_column_headers(c,x,y,w):
    """Column headings must have the very same right edges as the figures."""
    # Column figures are drawn at x+w-89 and x+w-8 in financial_row.
    t(c,x+w-89,y,'TODAY',6.8,'#E7F4F8',True,align='right')
    t(c,x+w-8,y,'MTD',6.8,'#8BE0E5',True,align='right')

def financial_row(c,x,y,w,label,a,b,index=0,kind='amt',emph=False,indent=0,height=9.15):
    if index%2==0:rect(c,x+2,y-2.45,w-4,height,LIGHT)
    if emph:
        rect(c,x+2,y-2.45,w-4,height,PALE)
        # No decorative cyan vertical strip: totals use bold + pale background.
    t(c,x+8+indent,y,label,7.05 if not emph else 7.35,NAVY if emph else INK,emph,maxw=w-183-indent)
    t(c,x+w-89,y,number(a,kind),7.05,NAVY if emph else INK,emph,align='right')
    t(c,x+w-8,y,number(b,kind),7.05,TEAL,True,align='right')

# Revenue detail belongs to Department Codes; native Comsys MTD is reference only.
REVENUE_GROUPS=[
 ('ROOMS',[(101,'Individual Rate'),(102,'Group Rate'),(104,'Late Check Out'),(103,'Extra Bed'),(105,'Cancellation / Other'),(199,'Room Adjustment'),(903,'Early Check In')],'rooms'),
 ('FOOD',[(201,'Pool Bar Food'),(202,'Beach Bar Food'),(203,'Cafe Bar Food'),(204,'Kids Area Food'),(205,'Main Restaurant'),(250,'Breakfast Package'),(251,'Dinner Package'),(252,'Lunch Package'),(299,'Food Adjustment')],'food'),
 ('BEVERAGE',[(253,'All Inclusive Beverage'),(301,'Pool Bar Beverage'),(302,'Beach Bar Beverage'),(303,'Cafe Beverage'),(304,'Kids Area Beverage'),(305,'Main Restaurant Beverage'),(399,'Beverage Adjustment')],'beverage'),
 ('OTHER',[(350,'Other F&B'),(401,'Local Telephone'),(402,'National Telephone'),(403,'International Telephone'),(501,'Laundry'),(502,'Billiard'),(503,'Miscellaneous'),(550,'Tips'),(590,'Opening Balance')],'other'),
]

def pdf_export(store,date,path,mode='management'):
    if mode!='management':return previous_export(store,date,path,mode=mode)
    src=store.day(date)
    if not src:raise ValueError('No imported Comsys reports for this business date')
    m=metrics(src);mt=detail(store,date)
    covered=mt['coverage'];has_dep='Department Summary' in src
    dep_today={int(x['code']):float(x['today']) for x in src.get('Department Summary',{}).get('codes',[])}
    dep_mtd=mt['department_codes'] if covered['Department Summary'] else {}
    has_rooms='Rooms Situation' in src
    has_co='Company Revenue' in src
    has_fb='F&B Report' in src
    company_today={x['company']:x for x in src.get('Company Revenue',{}).get('companies',[])}
    company_mtd=mt['companies'] if covered['Company Revenue'] else {}
    source_room_revenue=m.get('rooms') if has_dep else None
    approved_room_revenue=mt['financial'].get('rooms') if covered['Department Summary'] else None
    # Even if PDF exported from draft, no pretend MTD coverage.
    mtd_complete=all(covered[k]==mt['expected'] for k in ('Department Summary','Rooms Situation','Company Revenue','F&B Report','Guest In House'))
    c=canvas.Canvas(str(path),pagesize=(W,H),pageCompression=1)
    c.setTitle(f'Sky Star Daily Sales {date} | Today and MTD')
    rect(c,0,H-35,W,35,NAVY)
    t(c,21,H-23,'Sky Star Daily Sales',15.8,WHITE,True)
    qualifier='MTD COMPLETE' if mtd_complete else 'MTD INCOMPLETE'
    t(c,W-19,H-21,f'{date}   •   {store.status(date).upper()}   •   {qualifier}',7.6,'#DBE8EB',True,align='right')
    L=19; LW=390; RX=419; RW=W-RX-19
    # Light page surface and six discrete white cards, rather than unframed bands.
    rect(c,0,25,W,H-60,'#F1F5F8')
    for args in ((L,344,LW,565),(L,279.5,LW,344),(L,189.5,LW,281.6),
                 (RX,302,RW,565),(RX,189.5,RW,302),(L,28,W-2*L,176)):
        card_base(c,*args)
    # TWO COLUMN BODY: revenue including taxes/settlements on left, occupancy/meal entitlements on right
    bar(c,L,548,LW,'REVENUE')
    financial_column_headers(c,L,550,LW)
    y=530; index=0
    def fr(label,a,b,kind='amt',important=False,indent=0):
        nonlocal y,index
        financial_row(c,L,y,LW,label,a,b,index,kind,important,indent)
        index+=1;y-=9.55
    for group,items,totalkey in REVENUE_GROUPS:
        # Only non-zero detail codes remain, except important known operational rows.
        permanent={101,102,205,250,251,252,253,301,305,501,503,550}
        visible=[(code,label) for code,label in items if code in permanent or abs(dep_today.get(code,0))>.001 or abs(dep_mtd.get(code,0))>.001]
        for code,label in visible:
            fr(label,dep_today.get(code,0) if has_dep else None,
               dep_mtd.get(code,0) if covered['Department Summary'] else None,indent=8)
        fr('TOTAL '+group,m.get(totalkey) if has_dep else None,
           mt['financial'].get(totalkey) if covered['Department Summary'] else None,important=True)
    fr('TOTAL HOTEL REVENUE',m['revenue'] if has_dep else None,
       mt['financial']['revenue'] if covered['Department Summary'] else None,important=True)
    fr('Other Income Adjustment (599)',m['adjustment'] if has_dep else None,
       mt['financial']['adjustment'] if covered['Department Summary'] else None)
    fr('Transportation (904)',m['transportation'] if has_dep else None,
       mt['financial']['transportation'] if covered['Department Summary'] else None)
    fr('Service Charges + Taxes',m['taxes'] if has_dep else None,
       mt['financial']['taxes'] if covered['Department Summary'] else None)
    # Financial reconciliation is NOT added to sales.
    y-=10
    bar(c,L,y,LW,'SETTLEMENTS',None)
    financial_column_headers(c,L,y+2,LW)
    y-=18
    for i,(label,k) in enumerate([('Cash','cash'),('Credit Cards','card'),('City Ledger','city_ledger')]):
        financial_row(c,L,y,LW,label,m.get(k) if has_dep else None,
                      mt['financial'].get(k) if covered['Department Summary'] else None,
                      i,height=9)
        y-=9.1
    financial_row(c,L,y,LW,'TOTAL SETTLEMENTS',
                  m.get('total_settlements') if has_dep else None,
                  mt['financial'].get('total_settlements') if covered['Department Summary'] else None,
                  3,emph=True,height=9)
    y-=9.1
    # Right section rooms, same weighting as PMS paid-occupied.
    bar(c,RX,548,RW,'ROOMS / OCCUPANCY')
    financial_column_headers(c,RX,550,RW)
    ry=530; ri=0
    def rr(label,v,b,kind='num',emph=False):
        nonlocal ry,ri
        financial_row(c,RX,ry,RW,label,v,b,ri,kind,emph)
        ri+=1;ry-=8.35
    rm=mt['rooms'];source=(src.get('Rooms Situation',{}))
    def sd(key):return m.get(key) if has_rooms else None
    def sm(key):return rm.get(key) if covered['Rooms Situation'] else None
    rr('Physical Rooms',sd('physical_count'),sm('physical_count'))
    rr('O.O.O.',sd('ooo_in_rooms'),sm('ooo_in_rooms'))
    rr('Rooms Available',sd('available_for_sale'),sm('available_for_sale'))
    rr('Rooms Vacant',sd('vacant'),sm('vacant'))
    rr('House Use',sd('house_use'),sm('house_use'))
    rr('Rooms Comp.',sd('comp'),sm('comp'))
    rr('Rooms Occupied',sd('revenue_occupied'),sm('revenue_occupied'),emph=True)
    # Company mix is for sold rooms only, not unit architectural type.
    keys=['single','double','triple','quad','other_type','suite']
    sums_today={k:sum(float(v.get(k,0)) for v in company_today.values()) for k in keys}
    sums_mtd={k:sum(float(v.get(k,0)) for v in company_mtd.values()) for k in keys}
    rooms_day=sum(sums_today.values());rooms_month=sum(sums_mtd.values())
    for key,label in [('single','Rooms Single'),('double','Rooms Double'),('triple','Rooms Triple'),('quad','Rooms Quadruple'),('other_type','Rooms Above 4 Pax'),('suite','Suites')]:
        rr(label,sums_today[key] if has_co else None,sums_mtd[key] if covered['Company Revenue'] else None)
    rr('% Rooms Single',100*sums_today['single']/rooms_day if has_co and rooms_day else None,100*sums_mtd['single']/rooms_month if rooms_month else None,'pct')
    rr('% Rooms Double',100*sums_today['double']/rooms_day if has_co and rooms_day else None,100*sums_mtd['double']/rooms_month if rooms_month else None,'pct')
    rr('% Rooms Triple',100*sums_today['triple']/rooms_day if has_co and rooms_day else None,100*sums_mtd['triple']/rooms_month if rooms_month else None,'pct')
    rr('% Occupancy',sd('occupancy'),sm('occupancy'),'pct',True)
    rr('% Occupied + Comp',100*(sd('revenue_occupied')+sd('comp'))/sd('available_for_sale') if has_rooms and sd('available_for_sale') else None,
       100*(sm('revenue_occupied')+sm('comp'))/sm('available_for_sale') if sm('available_for_sale') else None,'pct')
    rr('% Occupied + H/U',100*(sd('revenue_occupied')+sd('house_use'))/sd('available_for_sale') if has_rooms and sd('available_for_sale') else None,
       100*(sm('revenue_occupied')+sm('house_use'))/sm('available_for_sale') if sm('available_for_sale') else None,'pct')
    rr('% Occ + Comp + H/U',100*(sd('revenue_occupied')+sd('comp')+sd('house_use'))/sd('available_for_sale') if has_rooms and sd('available_for_sale') else None,
       100*(sm('revenue_occupied')+sm('comp')+sm('house_use'))/sm('available_for_sale') if sm('available_for_sale') else None,'pct')
    def paxsplit(text):
        try:return [int(float(x)) for x in str(text).split('/')[:3]]
        except (ValueError,TypeError):return [0,0,0]
    ap=[0,0,0]; mp=[0,0,0]
    for co in company_today.values():
        for i,n in enumerate(paxsplit(co.get('pax'))):ap[i]+=n
    for co in company_mtd.values():
        for i,n in enumerate(paxsplit(co.get('pax'))):mp[i]+=n
    rr('Adults',ap[0] if has_co else None,mp[0] if covered['Company Revenue'] else None)
    rr('Children',ap[1] if has_co else None,mp[1] if covered['Company Revenue'] else None)
    rr('Infants',ap[2] if has_co else None,mp[2] if covered['Company Revenue'] else None)
    rr('% Rooms Quadruple',100*sums_today['quad']/rooms_day if has_co and rooms_day else None,100*sums_mtd['quad']/rooms_month if rooms_month else None,'pct')
    rr('Avr. Room Rate',sd('adr'),sm('adr'),'amt')
    rr('RevPAR',sd('revpar'),sm('revpar'),'amt')
    rr('Room Revenue / Adult Pax',source_room_revenue/ap[0] if has_co and has_dep and ap[0] else None,
       approved_room_revenue/mp[0] if covered['Department Summary'] and covered['Company Revenue'] and
       covered['Department Summary']==covered['Company Revenue'] and mp[0] else None,'amt')
    # Bottom-right meal table until company bar below; no repeated revenue values here.
    # Keep the Meal Plan heading aligned inside its own card even after removing the row.
    ry-=18.35
    bar(c,RX,ry+1,RW,'MEAL PLAN',None)
    ry-=17
    # Management asked to remove the cryptic 'Included' shorthand column.
    # Give its width to the four meaningful Today/MTD count columns instead.
    cols=[RX+8,RX+146,RX+224,RX+302,RX+RW-8]
    for x,label in zip(cols,['Plan','Rooms Today','Pax Today','Rooms MTD','Pax MTD']):
        t(c,x,ry,label,6.6,NAVY if x in cols[:3] else TEAL,True,align='right' if x!=cols[0] else 'left')
    ry-=11
    plans=values_for_fnb(src.get('F&B Report',{})) if has_fb else {}
    pdict=mt['meal_plans']
    for idx,code in enumerate(('BB','HB','FB','AN','HAN','BED')):
        if idx%2==0:rect(c,RX,ry-3,RW,11,LIGHT)
        z=plans.get(code,{});zm=pdict.get(code,{})
        vals=[code,number(z.get('rooms',0) if has_fb else None,'num'),
            number(z.get('pax',0) if has_fb else None,'num'),
            number(zm.get('rooms',0) if covered['F&B Report'] else None,'num'),
            number(zm.get('pax',0) if covered['F&B Report'] else None,'num')]
        for j,(x,v) in enumerate(zip(cols,vals)):
            t(c,x,ry,v,6.8,TEAL if j in (3,4) else INK,j==0,align='right' if j>0 else 'left')
        ry-=10.5
    meal_day_rooms=sum(z.get('rooms',0) for z in plans.values()) if has_fb else None
    meal_month_rooms=sum(z.get('rooms',0) for z in pdict.values()) if covered['F&B Report'] else None
    meal_day_pax=sum(z.get('pax',0) for z in plans.values()) if has_fb else None
    meal_month_pax=sum(z.get('pax',0) for z in pdict.values()) if covered['F&B Report'] else None
    rect(c,RX+2,ry-3,RW-4,11.6,PALE)
    for j,(x,v) in enumerate(zip(cols,['TOTAL MEAL PLANS',number(meal_day_rooms,'num'),
                       number(meal_day_pax,'num'),number(meal_month_rooms,'num'),
                       number(meal_month_pax,'num')])):
        t(c,x,ry,v,6.7,NAVY if j==0 else TEAL,True,align='left' if j==0 else 'right')
    # Intentionally no explanatory/entitlements line under Meal Plan.
    # These service counts remain available in the separate Excel audit data.
    # Package revenue per verified entitled person replaces old operating averages.
    from datetime import date as dt_cls,timedelta
    y-=8;bar(c,L,y,LW,'PACKAGE AVERAGES',None)
    y-=19
    px=[L+7,L+190,L+243,L+317,L+LW-7]
    for i,(x,label) in enumerate(zip(px,['Package','Revenue D','Avg/Pax D','Revenue MTD','Avg/Pax MTD'])):
        t(c,x,y,label,6.25,NAVY if i<=2 else TEAL,True,align='left' if i==0 else 'right')
    y-=11
    def entitled(fb,code):
        patterns={'BFST':('BB','HB','FB','AN','HAN'),'LNCH':('FB','AN','HAN'),
                  'DNNR':('HB','FB','AN','HAN'),'ANB':('AN','HAN')}[code]
        if not fb:return None
        vals=values_for_fnb(fb)
        actual=fb.get('services_rooms',{}).get(code)
        expected=sum(vals.get(z,{}).get('rooms',0) for z in patterns)
        if actual is None or actual!=expected:return None
        return sum(vals.get(z,{}).get('pax',0) for z in patterns)
    source_fb=src.get('F&B Report')
    first=dt_cls.fromisoformat(date).replace(day=1)
    pairs=[]
    for ix in range(int(date[-2:])):
        day=(first+timedelta(days=ix)).isoformat()
        if store.status(day)=='Closed':
            record=store.day(day)
            if 'Department Summary' in record and 'F&B Report' in record:pairs.append(record)
    day_package=month_package=0.0
    for ix,(code,name,service) in enumerate(((250,'Breakfast','BFST'),(252,'Lunch','LNCH'),(251,'Dinner','DNNR'),(253,'AI Beverage','ANB'))):
        a=dep_today.get(code,0) if has_dep else None
        b=dep_mtd.get(code,0) if covered['Department Summary'] else None
        pax=entitled(source_fb,service)
        ratio=a/pax if a is not None and pax and (a!=0 or store.status(date)=='Closed') else None
        den=0;nu=0;ok=bool(pairs) and len(pairs)==covered['Department Summary']==covered['F&B Report']
        for rec in pairs:
            v=entitled(rec['F&B Report'],service)
            if v is None:ok=False;break
            den+=v
            nu+=sum(x['today'] for x in rec['Department Summary']['codes'] if x['code']==code)
        ratio_m=nu/den if ok and den else None
        if ix%2==0:rect(c,L+2,y-2.5,LW-4,9.15,LIGHT)
        for j,(x,val) in enumerate(zip(px,[name,number(a),number(ratio),number(b),number(ratio_m)])):
            t(c,x,y,val,6.45,TEAL if j>2 else INK,j==0,align='left' if j==0 else 'right')
        if a is not None:day_package+=a
        if b is not None:month_package+=b
        y-=10.7
    rect(c,L+2,y-3,LW-4,11,PALE)
    t(c,L+7,y,'TOTAL PACKAGE REVENUE',6.75,INK,True)
    t(c,px[1],y,number(day_package) if has_dep else '—',6.6,INK,True,align='right')
    t(c,px[3],y,number(month_package) if covered['Department Summary'] else '—',6.6,TEAL,True,align='right')

    # Modern one-line-per-company grid: TODAY | MTD side by side, NOT stacked.
    # Occupancy MIX uses room-by-room Guest In House paid/comp/HU flags, not 175
    # sellable rooms. Missing paid/comp rooms are visibly "Unassigned".
    allocation=company_mix(store,date)
    company_y=161
    bar(c,L,company_y,W-2*L,'COMPANIES / OCCUPIED ROOM MIX',None)
    cy=company_y-15
    base_width=116
    # Each period has all nine user-approved metrics, with MTD at row end.
    period_widths=[31,22,22,22,30,35,61,54,60]
    allwidth=[base_width]+period_widths*2
    company_area=W-2*L
    # Fill any fractional width remainder in the company field only.
    allwidth[0]+=company_area-sum(allwidth)
    xx=[L]
    for width in allwidth:xx.append(xx[-1]+width)
    rect(c,L,cy-2,company_area,12,'#DDEAF0')
    t(c,xx[0]+5,cy+1,'COMPANY / CATEGORY',6.0,NAVY,True)
    t(c,(xx[1]+xx[10])/2,cy+1,'TODAY',6.4,NAVY,True,align='center')
    t(c,(xx[10]+xx[-1])/2,cy+1,'MTD',6.4,TEAL,True,align='center')
    cy-=13.0
    rect(c,L,cy-2,company_area,11,PALE)
    metric_headers=['Rooms','SGL','DBL','TPL','Adults','Mix %','Rm Rev','F&B Rev','Total Rev']
    t(c,xx[0]+5,cy+1,'',5.0,MUTE)
    for k,h in enumerate(metric_headers*2,1):
        t(c,xx[k+1]-3,cy+1,h,5.8,NAVY if k<=9 else TEAL,True,align='right')
    cy-=12.5
    allocation_rows=allocation['rows']
    # All named companies are retained; line height adapts within the footer space.
    available=max(5.45,(cy-27)/max(1,len(allocation_rows)))
    row_h=min(9.15,available)
    for i,r in enumerate(allocation_rows):
        total=r.get('is_total',False)
        if total:rect(c,L+2,cy-2,company_area-4,row_h+1,NAVY)
        elif i%2==0:rect(c,L+2,cy-2,company_area-4,row_h+1,LIGHT)
        t(c,xx[0]+5,cy+0.4,r['name'],5.45 if row_h>=8 else 4.9,WHITE if total else INK,
          total,maxw=allwidth[0]-9)
        for j,z in enumerate((r['today'],r['mtd'])):
            for k,key in enumerate(('rooms','single','double','triple','adults','mix','room_revenue','fnb_revenue','total_revenue')):
                val=r['today_mix' if j==0 else 'mtd_mix'] if key=='mix' else z.get(key) if z else None
                fmt='pct' if key=='mix' else 'num' if k<=4 else 'amt'
                value=number(val,fmt)
                idx=1+j*9+k
                t(c,xx[idx+1]-3,cy+0.4,value,5.15 if row_h>=8 else 4.65,
                  WHITE if total else TEAL if j==1 else INK, total,align='right')
        cy-=row_h
    # Today / MTD are distinguished by headings, not a bright divider.
    # One compact set of bottom totals. No audit notes or duplicated narrative.
    rect(c,0,0,W,25,NAVY)
    vals=[('HOTEL REVENUE',m['revenue'] if has_dep else None,mt['financial']['revenue'] if covered['Department Summary'] else None,'amt'),
          ('PAID ROOMS',sd('revenue_occupied'),sm('revenue_occupied'),'num'),
          ('MEAL PLAN ROOMS',sum(z.get('rooms',0) for z in plans.values()) if has_fb else None,
           sum(z.get('rooms',0) for z in pdict.values()) if covered['F&B Report'] else None,'num'),
          ('TOTAL SETTLEMENTS',m['total_settlements'] if has_dep else None,
           mt['financial']['total_settlements'] if covered['Department Summary'] else None,'amt')]
    for j,(label,daily,monthly,k) in enumerate(vals):
        x=12+j*(W/4)
        t(c,x,16,label,5.7,'#BDD4DC',True)
        t(c,x,5.4,'D '+number(daily,k)+'  |  MTD '+number(monthly,k),6.9,WHITE,True)
    # Stroke the card edges last, above alternating table rows.
    for args in ((L,344,LW,565),(L,279.5,LW,344),(L,189.5,LW,281.6),
                 (RX,302,RW,565),(RX,189.5,RW,302),(L,28,W-2*L,176)):
        card_outline(c,*args)
    c.showPage();c.save()
    return str(path)
