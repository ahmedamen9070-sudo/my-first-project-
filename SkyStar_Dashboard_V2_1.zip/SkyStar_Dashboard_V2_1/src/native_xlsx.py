"""Dependency-free OOXML writer for Windows deployment if artifact_tool is unavailable.
No Excel or Office installation required. Writes valid .xlsx (ZIP/XML).
"""
from __future__ import annotations
from datetime import date,timedelta
from xml.sax.saxutils import escape
import zipfile
from pathlib import Path
from engine import metrics,checks,monthly
from mtd_detail import detail as mtd_detail, values_for_fnb
from company_mix import company_mix

def _col(i):
    s='';i+=1
    while i:i,r=divmod(i-1,26);s=chr(65+r)+s
    return s

def _cells_xml(rows):
    fragments=[]
    for ri,row in enumerate(rows,1):
        cells=[]
        for ci,obj in enumerate(row):
            if obj is None:continue
            style=0;value=obj
            if isinstance(obj,dict):style=obj.get('style',0);value=obj.get('value')
            addr=f'{_col(ci)}{ri}'
            if value is None:continue
            if isinstance(value,tuple) and value and value[0]=='f':
                expr=str(value[1]).lstrip('=');cached=value[2] if len(value)>2 else 0
                cells.append(f'<c r="{addr}" s="{style}"><f>{escape(expr)}</f><v>{cached}</v></c>')
            elif isinstance(value,(int,float)) and not isinstance(value,bool):
                cells.append(f'<c r="{addr}" s="{style or 2}"><v>{value}</v></c>')
            else:
                text=escape(str(value))
                cells.append(f'<c r="{addr}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{text}</t></is></c>')
        if cells:fragments.append(f'<row r="{ri}">{"".join(cells)}</row>')
    return ''.join(fragments)

def _sheet(rows,wide=False):
    n=max((len(r) for r in rows),default=1)
    cols=[]
    for i in range(n):
        width=32 if i==0 else 18
        if i==2 and wide:width=85
        elif i==1 and wide:width=28
        cols.append(f'<col min="{i+1}" max="{i+1}" width="{width}" customWidth="1"/>')
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
        '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'
        '<sheetFormatPr defaultRowHeight="17"/><cols>'+''.join(cols)+'</cols>'
        '<sheetData>'+_cells_xml(rows)+'</sheetData>'
        '<printOptions horizontalCentered="1"/><pageMargins left="0.2" right="0.2" top="0.35" bottom="0.35" header="0.15" footer="0.15"/>'
        '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>')

def _title(s):return {'value':s,'style':3}
def _head(s):return {'value':s,'style':1}
def _note(s):return {'value':s,'style':4}
def _money(v):return {'value':v,'style':2}
def _formula(expr,cached):return {'value':('f',expr,cached),'style':2}

def native_excel_export(store,d,path):
    src=store.day(d);m=metrics(src);mt=monthly(store,d);ex=checks(src)
    data={}
    daily=[[_title('SKY STAR HOTEL  |  DAILY SALES  |  BUSINESS DATE: '+d)],
           [_note('STATUS: '+store.status(d)+' | BUSINESS DATE '+d)],[],
           [_head('REVENUE'),_head('TODAY'),_head('SOURCE / CLASSIFICATION')]]
    drows=[('Room Revenue',m['rooms'],'Comsys mapped rooms excl. 904'),('Food Revenue',m['food'],'Food and meal packages'),
           ('Beverage Revenue',m['beverage'],'Including All Inclusive beverage allocations'),
           ('Other Income',m['other'],'Before adjustment 599'),
           ('HOTEL REVENUE',None,'Daily Sales presentation basis'),
           ('Other Adjustment',m['adjustment'],'599 Adjustment'),
           ('Transportation Separate',m['transportation'],'904; not Room Revenue'),
           ('NET POSTED REVENUE',None,'Revenue plus adjustment and transportation'),
           ('Service Charge & Taxes',m['taxes'],'Codes 701-705'),
           ('Cash Settlements',m['cash'],'Not additional revenue'),
           ('Card Settlements',m['card'],'Not additional revenue'),
           ('City Ledger Settlements',m['city_ledger'],'Receivable transfer, not cash'),
           ('Comsys Posting Movement',m['grand_total'],'Not hotel profit or sales')]
    for i,(name,amount,desc) in enumerate(drows,5):
        if i==9:amount=_formula('SUM(B5:B8)',m['revenue'])
        if i==12:amount=_formula('SUM(B9:B11)',m['net_revenue'])
        daily.append([name,amount if isinstance(amount,dict) else _money(amount) if amount is not None else None,desc])
    daily+=[[],[],[_head('ROOMS & OCCUPANCY'),_head('VALUE'),_head('MEASUREMENT')]]
    roomrows=[('Physical Room Inventory',m.get('physical_count'),'All physical rooms'),('Out of Order',m.get('ooo_in_rooms'),'Not to subtract twice'),
              ('Operating Rooms',m.get('available_for_sale'),'Physical less OOO'),('Revenue Occupied',m.get('revenue_occupied'),'Paid rooms'),
              ('Vacant',m.get('vacant'),'Unoccupied'),('Complimentary',m.get('comp'),'Included inventory'),
              ('House Use',m.get('house_use'),'Included inventory'),('% Occupancy',_formula('IFERROR(B24/B23*100,0)',m.get('occupancy',0)),'Paid / Operating'),
              ('ADR',_formula('IFERROR(B5/B24,0)',m.get('adr',0)),'Rooms Revenue / Paid Occupied'),
              ('RevPAR',_formula('IFERROR(B5/B23,0)',m.get('revpar',0)),'Rooms Revenue / Operating')]
    for name,value,detail in roomrows:daily.append([name,_money(value) if isinstance(value,(int,float)) else value,detail])
    daily += [[],[_head('RECONCILIATION'),_head('VALUE'),_head('SOURCE')],
              ['Settlements (total)',_money(m['total_settlements']),'Cash / Credit Card / City Ledger'],
              ['Computed Posting',_formula('B12+B13-B33',m['grand_total']),'Revenue+Taxes-Settlements'],
              ['Posting Control Difference',_formula('B34-B17',m['checks'].get('posting_net_movement',0)),'Should be 0'],[],
              [_head('REQUIRED SOURCE'),_head('STATUS')]]
    for n in ('Department Summary','Rooms Situation','Cashier Summary','Company Revenue','F&B Report','Posting Summary','Voided Transactions'):
        daily.append([n,'Imported' if n in src else 'Not uploaded'])
    data['Daily Sales']=daily
    start=store.reporting_start(d);end=date.fromisoformat(d);x=start
    periods=[[_title('MONTH TO DATE - CLOSED DAYS ONLY')],[_note('INCOMPLETE - DO NOT SEND AS FINAL' if not mt['complete'] else 'COMPLETE AND APPROVED')],[],
             [_head('Business Date'),_head('Status'),_head('Rooms'),_head('Food'),_head('Beverage'),_head('Other'),_head('Hotel Revenue')]]
    totals={k:0 for k in ('rooms','food','beverage','other','revenue')};idx=5
    while x<=end:
        dx=x.isoformat();closed=store.status(dx)=='Closed' and 'Department Summary' in store.day(dx)
        if closed:
            v=metrics(store.day(dx));r=[dx,'Closed']
            for k in ('rooms','food','beverage','other'):r.append(_money(v[k]));totals[k]+=v[k]
            r.append(_formula(f'SUM(C{idx}:F{idx})',v['revenue']));totals['revenue']+=v['revenue']
        else:r=[dx,'MISSING / NOT CLOSED',None,None,None,None,None]
        periods.append(r);x+=timedelta(days=1);idx+=1
    periods.append([_head('MTD TOTAL'),_head(str(mt['days_closed']))]+[_formula(f'SUM({_col(c)}5:{_col(c)}{idx-1})',round(totals[k],2)) for c,k in zip(range(2,7),('rooms','food','beverage','other','revenue'))])
    periods.extend([[],[_note('Cumulative Comsys MTD figures are REFERENCE only. Never add their values as another daily transaction.')]])
    data['MTD & Coverage']=periods
    co=[[_title('COMPANY REVENUE | RECLASSIFICATION - NOT ADDITIONAL SALES')],[],
        [_head('Company'),_head('Rooms'),_head('Room Revenue'),_head('F&B Revenue'),_head('Total Revenue')]]
    for x in src.get('Company Revenue',{}).get('companies',[]):
        co.append([x['company'],x['rooms'],x['room_revenue'],x['fnb_revenue'],x['total_revenue']])
    data['Company Revenue']=co
    # NEW: all material Daily / Approved MTD fields across the same closed-day source dates.
    totals_mtd=mtd_detail(store,d)
    fb_complete=totals_mtd['coverage_complete']['F&B Report']
    source_note=('F&B source unavailable today; meal statistics incomplete.' if 'F&B Report' not in src else
                 'F&B source unavailable in MTD; meal statistics incomplete.' if totals_mtd['fnb_missing_dates'] else
                 'F&B MTD not fully approved; meal statistics incomplete.') if not fb_complete or 'F&B Report' not in src else None
    if source_note:
        # Plain public source notice survives the removal of private note-style rows.
        daily[2]=[source_note]
    fm=totals_mtd['financial'];rm=totals_mtd['rooms'];cov=totals_mtd['coverage']
    detail_sheet=[[_title('SKY STAR DAILY SALES | TODAY / MTD')],
                  [_note(f'Business Date {d} | Coverage: Revenues {cov["Department Summary"]}/{totals_mtd["expected"]}, Rooms {cov["Rooms Situation"]}/{totals_mtd["expected"]}, F&B {cov["F&B Report"]}/{totals_mtd["expected"]}, Companies {cov["Company Revenue"]}/{totals_mtd["expected"]}')],
                  [_note('MTD is approved CLOSED day sum; missing sources do not count as zero. Room rates use weighted ratios.')],[],
                  [_head('FINANCIAL CATEGORY'),_head('TODAY'),_head('APPROVED MTD'),_head('DEFINITION')]]
    if source_note:detail_sheet[2]=[source_note]
    keys=[('Room Revenue','rooms'),('Food Revenue','food'),('Beverage Revenue','beverage'),('Other Revenue','other'),
          ('TOTAL REVENUE','revenue'),('Adjustment','adjustment'),('Transportation','transportation'),('Taxes & Service','taxes'),('Net Posted Revenue','net_revenue'),
          ('Cash','cash'),('Credit Cards','card'),('City Ledger','city_ledger'),('Settlement Total','total_settlements'),('Comsys net postings','grand_total')]
    for label,key in keys:
        detail_sheet.append([label,m.get(key) if 'Department Summary' in src else None, fm.get(key) if cov['Department Summary'] else None, 'Not additional sales' if key in ('cash','card','city_ledger','total_settlements') else 'Sum of each approved business date'])
    detail_sheet.extend([[],[_head('ROOM KPI'),_head('TODAY'),_head('APPROVED MTD'),_head('MTD BASIS')]])
    rkeys=[('Physical Rooms','physical_count'),('O.O.O.','ooo_in_rooms'),('Rooms Available','available_for_sale'),
           ('Rooms Occupied','revenue_occupied'),('Rooms Vacant','vacant'),('Rooms Comp.','comp'),('House Use','house_use'),
           ('% Occupancy','occupancy'),('ADR','adr'),('RevPAR','revpar')]
    for label,key in rkeys:
        detail_sheet.append([label,m.get(key) if 'Rooms Situation' in src else None,rm.get(key) if cov['Rooms Situation'] else None,
                            'Last known approved snapshot' if key=='physical_count' else 'Ratio from MTD sums' if key in ('occupancy','adr','revpar') else 'Sum of daily room-nights'])
    detail_sheet.extend([[],[_head('LEDGER BALANCE'),_head('TODAY SNAPSHOT'),_head('LAST APPROVED CLOSE'),_head('Do not sum balance snapshots')],
                         ['Guest Ledger closing',m.get('guest_ledger_closing'),totals_mtd['guest_ledger_last_balance'],'Latest closed balance, NOT MTD sum']])
    data['All Today & MTD']=detail_sheet
    co_mtd=[[_title('COMPANY ROOM MIX / PAX / REVENUE | TODAY & MTD')],
            [_note('S/D/T/Q/O/Su = occupancy categories, not architectural room types. MTD sums closed source days.')],[],
            [_head(x) for x in ('Company','Rooms D','Rooms MTD','Single D','Single MTD','Double D','Double MTD',
            'Triple D','Triple MTD','Quad D','Quad MTD','Other D','Other MTD','Suite D','Suite MTD',
            'Adults D','Adults MTD','Room Revenue D','Room Revenue MTD',
            'F&B Revenue D','F&B Revenue MTD','Other Revenue D','Other Revenue MTD','Total D','Total MTD')]]
    mix=company_mix(store,d)
    # This secondary company sheet must agree with the certified Management Companies sheet.
    for entry in mix['rows']:
        a=entry.get('today') or {};b=entry.get('mtd') or {}
        row=[entry['name']]
        for key in ('rooms','single','double','triple','quad','other_type','suite','pax','room_revenue','fnb_revenue','other_revenue','total_revenue'):
            if key=='pax':
                row.extend((a.get('adults'),b.get('adults')))
            elif key=='other_type' or key=='suite' or key=='other_revenue':
                row.extend((None,None))  # Not populated by certified room-level company mix.
            else:
                row.extend((a.get(key),b.get(key)))
        co_mtd.append(row)
    data['Company Today & MTD']=co_mtd
    # Department codes are independently stored; no duplicate hotel revenue is created by this view.
    dsrc={int(r['code']):r for r in src.get('Department Summary',{}).get('codes',[])}
    dcum=totals_mtd.get('department_codes',{})
    defs={101:'Individual Rate',102:'Group Rate',104:'Late Check Out',201:'Pool Bar Food',
        205:'Main Restaurant Food',250:'Breakfast Package',251:'Dinner Package',252:'Lunch Package',
        253:'All Inclusive Beverage',301:'Pool Bar Beverage',305:'Main Restaurant Beverage',
        350:'Other F&B',501:'Laundry',503:'Miscellaneous',550:'Tips',599:'Other Income Adjustment',
        904:'Transportation',701:'Service Charge',702:'Sales Tax',703:'Municipality Tax'}
    dept=[[_title('REVENUE BREAKDOWN BY DEPARTMENT | TODAY & MTD')],
          [_note('Original Comsys Department Codes; posted transactions are never added to sales twice.')],[],
          [_head('Code'),_head('Department'),_head('Today'),_head('Approved MTD')]]
    for code in sorted(set(defs)|set(dsrc)|set(dcum)):
        rec=dsrc.get(code,{})
        dept.append([code,rec.get('label',defs.get(code,'Other Department')),
                     rec.get('today',0) if 'Department Summary' in src else None,
                     dcum.get(code,0) if cov['Department Summary'] else None])
    data['Department Codes MTD']=dept
    # Distribution of sold rooms and balanced occupancy, with each KPI calculated from linked data.
    roomsheet=[[_title('ROOM MIX / OCCUPANCY | TODAY & MTD')],
               [_note('Occupancy mixes from Company Revenue; capacity from Rooms Situation. MTD is weighted room nights.')],[],
               [_head('Metric'),_head('Today'),_head('Approved MTD')]]
    daytotal=mix['rows'][-1].get('today') or {}
    mtdtotal=mix['rows'][-1].get('mtd') or {}
    for key,label in [('single','Single'),('double','Double'),('triple','Triple'),('quad','Quadruple')]:
        roomsheet.append([label,daytotal.get(key),mtdtotal.get(key) if mix['mtd_complete'] else None])
    for label in ('Above 4','Suites'):
        roomsheet.append([label,None,None])  # No independent room-type certification.
    for key,label in [('physical_count','Physical rooms (latest snapshot)'),('ooo_in_rooms','Out of Order nights'),
                      ('available_for_sale','Rooms Available'),('revenue_occupied','Paid occupied room nights'),
                      ('vacant','Rooms Vacant'),('comp','Complimentary'),('house_use','House Use'),
                      ('occupancy','Paid occupancy %'),('adr','Average room rate'),('revpar','RevPAR')]:
        roomsheet.append([label,m.get(key) if 'Rooms Situation' in src else None,
             rm.get(key) if cov['Rooms Situation'] else None])
    data['Rooms Breakdown MTD']=roomsheet
    meal=[[_title('MEAL PLANS / ENTITLEMENTS | TODAY & MTD')],
          [_note(f'{cov["F&B Report"]}/{totals_mtd["expected"]} days with approved F&B reports. MTD counts are room/pax nights, NOT unique guests or meals consumed.')],[],
          [_head('Pattern'),_head('Rooms Today'),_head('Pax Today'),_head('Rooms MTD'),_head('Pax MTD')]]
    if source_note:meal[1]=[source_note]
    meal_today=values_for_fnb(src.get('F&B Report',{}))
    for code in ('BB','HB','FB','AN','HAN','BED'):
        t=meal_today.get(code,{});mm=totals_mtd['meal_plans'].get(code,{})
        meal.append([{'AN':'Soft All Inc','HAN':'Hard All Inc'}.get(code,code),t.get('rooms') if 'F&B Report' in src else None,t.get('pax') if 'F&B Report' in src else None,
            mm.get('rooms',0) if fb_complete else None,mm.get('pax',0) if fb_complete else None])
    meal.append(['TOTAL',sum(z.get('rooms',0) for z in meal_today.values()) if 'F&B Report' in src else None,
                 sum(z.get('pax',0) for z in meal_today.values()) if 'F&B Report' in src else None,
                 sum(z.get('rooms',0) for z in totals_mtd['meal_plans'].values()) if fb_complete else None,
                 sum(z.get('pax',0) for z in totals_mtd['meal_plans'].values()) if fb_complete else None])
    meal.extend([[],[_head('MEAL CODE'),_head('Rooms Today'),_head('Room Nights MTD')]])
    for code in ('BFST','LNCH','DNNR','ANB','HAN'):
        meal.append([code,src.get('F&B Report',{}).get('services_rooms',{}).get(code) if 'F&B Report' in src else None,
            totals_mtd['meal_services'].get(code,0) if fb_complete else None])
    data['Meal Plans Today MTD']=meal
    # Same modern one-row layout as PDF/desktop (no stacked MTD rows).
    # Room mix includes House Use, Complimentary and separate unmapped occupancy.
    mix=company_mix(store,d)
    heads=['COMPANY']+['TODAY '+h for h in ('Rooms','SGL','DBL','TPL','Quad','Adults','Mix %','Room Revenue','F&B Revenue','Total Revenue')]+[
                         'MTD '+h for h in ('Rooms','SGL','DBL','TPL','Quad','Adults','Mix %','Room Revenue','F&B Revenue','Total Revenue')]
    view=[[_title('SKY STAR DAILY SALES | COMPANIES | GUEST IN HOUSE + REVENUE')],[],[_head(v) for v in heads]]
    def _rowfmt(obj,share):
        if obj is None:return [None]*10
        return [obj.get(x) for x in ('rooms','single','double','triple','quad','adults')]+[
            round(share,2) if share is not None else None]+[
            obj.get(x) for x in ('room_revenue','fnb_revenue','total_revenue')]
    for r in mix['rows']:
        view.append([r['name']]+_rowfmt(r['today'],r['today_mix'])+_rowfmt(r['mtd'],r['mtd_mix']))
    data['Management Companies']=view
    package=[[_title('PACKAGE AVERAGES | SOURCE VERIFIED')],
             [_note('Mean revenue per entitled pax; matched closed days only')],[],
             [_head(v) for v in ('Package','Revenue D','Entitled Pax D','Average D','Revenue MTD','Entitled Pax MTD','Average MTD')]]
    spec=[(250,'Breakfast','BFST',('BB','HB','FB','AN','HAN')),(252,'Lunch','LNCH',('FB','AN','HAN')),
          (251,'Dinner','DNNR',('HB','FB','AN','HAN')),(253,'AI Beverage','ANB',('AN','HAN'))]
    if source_note:package[1]=[source_note]
    dcode={int(z['code']):z['today'] for z in src.get('Department Summary',{}).get('codes',[])}
    def _entitlement(fb,svc,pat):
        if not fb:return None
        plans=values_for_fnb(fb)
        if sum(plans.get(k,{}).get('rooms',0) for k in pat)!=fb.get('services_rooms',{}).get(svc):return None
        return sum(plans.get(k,{}).get('pax',0) for k in pat)
    # MTD package denominator requires matching closed source days.
    paired=[]
    first=store.reporting_start(d)
    for n in range((date.fromisoformat(d)-first).days+1):
        day=(first+timedelta(days=n)).isoformat()
        if store.status(day)=='Closed' and {'Company Revenue','Rooms Situation'}<=set(store.day(day)):
            paired.append(store.day(day))
    matched=[v for v in paired if 'Department Summary' in v and 'F&B Report' in v]
    for rid,(code,name,service,patterns) in enumerate(spec,5):
        rev=dcode.get(code,0) if 'Department Summary' in src else None
        pax=_entitlement(src.get('F&B Report'),service,patterns)
        count=0;val=0
        valid=bool(matched) and totals_mtd['coverage_complete']['Department Summary'] and fb_complete and len(matched)==totals_mtd['expected']
        for obj in matched:
            n=_entitlement(obj['F&B Report'],service,patterns)
            if n is None:valid=False;break
            count+=n;val+=sum(z['today'] for z in obj['Department Summary']['codes'] if int(z['code'])==code)
        revm=totals_mtd['department_codes'].get(code) if cov['Department Summary'] else None
        package.append([name,rev,pax,_formula(f'IFERROR(B{rid}/C{rid},0)',round(rev/pax,2)) if rev is not None and pax and (rev!=0 or store.status(d)=='Closed') else None,
                       revm,count if valid else None,_formula(f'IFERROR(E{rid}/F{rid},0)',round(val/count,2)) if valid and count else None])
    package.append(['TOTAL PACKAGE REVENUE',_formula('SUM(B5:B8)',sum(dcode.get(k,0) for k,_,_,_ in spec)) if 'Department Summary' in src else None,None,None,
                    _formula('SUM(E5:E8)',sum(totals_mtd['department_codes'].get(k,0) for k,_,_,_ in spec)) if cov['Department Summary'] else None,None,None])
    data['Package Averages']=package
    audit=[[_title('AUDIT EXCEPTIONS / REVIEW LOG')],[],[_head('Severity'),_head('Code'),_head('Exception / Explanation')]]
    audit.extend([[e['level'],e['code'],e['message']] for e in ex]);audit.extend([[],[_head('SOURCE'),_head('FILE')]])
    audit.extend([[n,f] for n,f,_ in store.sources(d)]);audit.extend([[],['Auditor note',store.notes(d)[1]]])
    data['Audit & Sources']=audit
    # Management exports contain operational results ONLY. Date mismatches,
    # close warnings, audit exceptions, source filenames and review notes
    # remain private on the Windows Import / Audit screens.
    internal_sheets={'MTD & Coverage','Audit & Sources'}
    daily_rows=data.get('Daily Sales',[])
    cutoff=next((i for i,row in enumerate(daily_rows) if any(
         isinstance(c,dict) and c.get('value')=='RECONCILIATION' for c in row)),len(daily_rows))
    data['Daily Sales']=daily_rows[:cutoff]
    data={name:[([None]*len(row) if any(isinstance(cell,dict) and
          cell.get('style')==4 for cell in row) else row) for row in rows]
          for name,rows in data.items() if name not in internal_sheets}
    styles='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4"><font><sz val="10"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/></font><font><b/><color rgb="FF172D46"/><sz val="15"/></font><font><color rgb="FF66788A"/><sz val="10"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF2463AA"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEAF1F7"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0"/><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0"/><xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>'''
    workbook='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i,name in enumerate(data,1))+'</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>'
    relationships='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(data)+1))+'<Relationship Id="rId99" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
    types='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(data)+1))+'</Types>'
    relsroot='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,content in [('[Content_Types].xml',types),('_rels/.rels',relsroot),('xl/workbook.xml',workbook),('xl/_rels/workbook.xml.rels',relationships),('xl/styles.xml',styles)]:z.writestr(n,content)
        for i,(name,rows) in enumerate(data.items(),1):z.writestr(f'xl/worksheets/sheet{i}.xml',_sheet(rows,wide=name in ('Daily Sales','Audit & Sources')))
    return path
