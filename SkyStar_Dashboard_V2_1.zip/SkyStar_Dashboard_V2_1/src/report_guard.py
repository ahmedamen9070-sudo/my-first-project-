"""Internal business-date validation, never rendered on management reports."""
from datetime import date

class BusinessDateMismatch(ValueError):
    def __init__(self, file, selected, reported, report_kind):
        self.filename = str(file); self.selected = selected
        self.reported = reported; self.report_kind = report_kind
        super().__init__(f"{self.filename}: {report_kind} is dated {reported}, "
                         f"but the selected business date is {selected}. "
                         "The file was not imported. Export the correct day from Comsys.")


def validate_date(report, selected):
    selected = date.fromisoformat(selected).isoformat()
    reported = date.fromisoformat(report['date']).isoformat()
    if reported != selected:
        raise BusinessDateMismatch(report['filename'], selected, reported, report['kind'])
    return report


def import_batch_guard(paths, selected, parser):
    """Read/validate *all* files first. Return (valid reports, errors).

    Callers must not save anything if errors exist, making mixed-day batch
    imports all-or-nothing. Ambiguous reports need separate manual verification.
    """
    date.fromisoformat(selected)
    reports=[]; errors=[]
    for p in paths:
        try:reports.append(validate_date(parser(p),selected))
        except Exception as exc:errors.append((str(p),exc))
    return (reports if not errors else []),errors
