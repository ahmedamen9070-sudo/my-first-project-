"""Sky Star Hotel compact, date-safe one-page management briefs (v4)."""
from __future__ import annotations
from pathlib import Path
from datetime import date
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, Color
from reportlab.pdfbase.pdfmetrics import stringWidth
from engine import metrics, checks, monthly, normalize_meal_pattern
from exports_pdf_v3 import pdf_export as previous_pdf_export

W,H=A4
NAVY='#11263C'; TEAL='#087D75'; TXT='#193148'; MUTED='#62768B'; SOFT='#F1F6F9'; BORDER='#DCE7EC'; ORANGE='#9B542E'; WHITE='#FFFFFF'
MW=W-68

def money(v): return f'{float(v or 0):,.2f}'

def col(c,color):c.setFillColor(HexColor(color))

def draw(c,x,y,text,size=9,bold=False,color=TXT):
    col(c,color);c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.drawString(x,y,str(text))

def right(c,x,y,text,size=9,bold=False,color=TXT):
    col(c,color);c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.drawRightString(x,y,str(text))

def trunc(txt,maxwidth,sz=8,bold=False):
    txt=str(txt);font='Helvetica-Bold' if bold else 'Helvetica'
    if stringWidth(txt,font,sz)<=maxwidth:return txt
    while txt and stringWidth(txt+'...',font,sz)>maxwidth:txt=txt[:-1]
    return txt+'...'

def block(c,x,y,w,h,r=8,bg=WHITE,stroke=BORDER):
    col(c,bg);c.setStrokeColor(HexColor(stroke));c.roundRect(x,y,w,h,r,stroke=1,fill=1)

def section_label(c,x,y,title):
    draw(c,x,y,title.upper(),10.1,True,NAVY)
    c.setStrokeColor(HexColor(TEAL));c.setLineWidth(1.5);c.line(x,y-8,x+18,y-8)

def line_row(c,x,y,label,value,number_x,width,weight=False,alternate=False):
    if alternate:
        col(c,SOFT);c.rect(x-5,y-6,width+10,18,fill=1,stroke=0)
    draw(c,x,y,trunc(label,number_x-x-15,8.3,weight),8.3,weight)
    right(c,number_x,y,value,9,weight)

def card(c,x,y,w,label,value,foot):
    block(c,x,y,w,73,7,SOFT,SOFT)
    col(c,TEAL);c.roundRect(x,y+69,w,4,2,stroke=0,fill=1)
    draw(c,x+12,y+55,label.upper(),7.6,True,MUTED)
    draw(c,x+12,y+27,value,17,True,NAVY)
    draw(c,x+12,y+10,foot,7.1,False,MUTED)

def header(c,d,state,label,preview=True):
    col(c,NAVY);c.rect(0,H-52,W,52,fill=1,stroke=0)
    draw(c,34,H-31,'SKY STAR HOTEL',15,True,WHITE)
    right(c,W-34,H-30,'FINANCE  /  MANAGEMENT',8,True,'#C9DCE8')
    draw(c,34,H-83,label,15,True,NAVY)
    draw(c,34,H-104,f'BUSINESS DATE  {d}    |    {state.upper()}    |    1-PAGE MANAGEMENT BRIEF',7.7,True,MUTED)
    if preview:
        right(c,W-34,H-104,'PREVIEW - NOT APPROVED',7.4,True,ORANGE)

def footer(c,d):
    c.setStrokeColor(HexColor(BORDER));c.line(34,52,W-34,52)
    draw(c,34,38,'Source: Comsys 4.8.17  |  Internal review  |  Amounts as recorded',7.3,False,MUTED)
    right(c,W-34,38,'PAGE 1 / 1',7.3,True,MUTED)

def top_items(src,mt,ex,manual=""):
    if manual.strip():
        # Management editor: one short point per line; use at most three lines.
        manual_lines=[]
        for raw in manual.splitlines():
            item=raw.strip().lstrip('-*• ').strip()
            if not item or item.upper().startswith(('SKY STAR','BUSINESS DATE','MANAGEMENT COMMENTARY')):continue
            manual_lines.append(item)
        if manual_lines:return manual_lines[:3]
    notes=[]
    warn_codes={x['code']:x for x in ex if x['level'] in ('WARNING','BLOCKER')}
    if 'COMPANY_TOTAL' in warn_codes:notes.append('Company Revenue gap: 426.98 - allocation requires review.')
    if 'FOLIO_GUEST_LEDGER' in warn_codes:notes.append('Guest Ledger vs folio snapshot: 3,905.00 difference, unresolved.')
    elif 'MISSING_CASHIER_SUMMARY' in warn_codes:notes.append('Cashier Summary missing - settlement comparison not verified.')
    if not mt['complete']:notes.append(f'MTD incomplete: {len(mt["missing"])} day(s) missing / not closed.')
    if not notes and not any(x['level'] in ('WARNING','BLOCKER') for x in ex):notes=['No material variances in implemented checks; full audit remains separate.']
    return notes[:3]

def generate_compact_commentary(store,d):
    src=store.day(d); ex=checks(src); mt=monthly(store,d)
    return '\n'.join('- '+point for point in top_items(src,mt,ex))

def meal_rows(src):
    fb=src.get('F&B Report',{})
    policies={'BB':'Breakfast','HB':'Breakfast + dinner','FB':'Breakfast + lunch + dinner',
      'AN':'Meals + soft included','HAN':'Meals + soft + hard included','BED':'Room only'}
    patterns={};adults={};children={}
    for raw,num in fb.get('patterns',{}).items():
        key=normalize_meal_pattern(raw);patterns[key]=patterns.get(key,0)+num
        adults[key]=adults.get(key,0)+fb.get('adults',{}).get(raw,0)
        children[key]=children.get(key,0)+fb.get('children',{}).get(raw,0)
    order=['BB','HB','FB','AN','HAN','BED']
    return [(p,patterns[p],adults.get(p,0)+children.get(p,0),policies.get(p,'Check contract')) for p in order if p in patterns] + [
        (p,v,adults.get(p,0)+children.get(p,0),'See contract') for p,v in patterns.items() if p not in order]

def management_pdf(store,d,path):
    src=store.day(d);m=metrics(src);ex=checks(src);mt=monthly(store,d)
    if not src:raise ValueError('No source reports for this date')
    path=str(path);Path(path).parent.mkdir(parents=True,exist_ok=True)
    c=canvas.Canvas(path,pagesize=A4,pageCompression=1)
    c.setTitle('Sky Star | One-Page Daily Management Brief | '+d)
    state=store.status(d)
    header(c,d,state,'DAILY SALES  /  EXECUTIVE BRIEF',state!='Closed' or not mt['complete'] or bool([x for x in ex if x['level'] in ('WARNING','BLOCKER')]))
    gap=9;cw=(MW-2*gap)/3
    card(c,34,610,cw,'Hotel Revenue',money(m['revenue']) if 'Department Summary' in src else 'N/A','Operating revenue only')
    card(c,34+cw+gap,610,cw,'Paid Occupancy',f'{m["occupancy"]:.2f}%' if 'occupancy' in m else 'N/A','Revenue rooms / capacity')
    card(c,34+2*(cw+gap),610,cw,'ADR',money(m['adr']) if 'adr' in m else 'N/A','Room revenue / paid rooms')
    x1=34;x2=308; leftw=252;rightw=253
    section_label(c,x1,582,'Revenue breakdown')
    section_label(c,x2,582,'Rooms & capacity')
    revenue=[('Rooms',m['rooms']),('Food',m['food']),('Beverage',m['beverage']),('Other income',m['other'])]
    for i,(name,val) in enumerate(revenue):line_row(c,x1+6,556-i*25,name,money(val) if 'Department Summary' in src else '-',x1+leftw-6,leftw-12,alternate=i%2==0)
    if 'Rooms Situation' in src:
        rr=[('Physical inventory',m['physical_count']),('Out of Order',m['ooo_in_rooms']),('Operating rooms',m['available_for_sale']),('Paid occupied',m['revenue_occupied']),('Complimentary / H.Use',f'{m["comp"]} / {m["house_use"]}'),('Vacant',m['vacant'])]
    else:rr=[('Room status','Not supplied')]
    for i,(name,val) in enumerate(rr):line_row(c,x2+6,556-i*20,name,str(val),x2+rightw-8,rightw-12,alternate=i%2==0)
    c.setStrokeColor(HexColor(BORDER));c.line(34,429,W-34,429)
    section_label(c,x1,410,'Meal plan - F&B entitlement')
    section_label(c,x2,410,'Settlements (not revenue)')
    fb=src.get('F&B Report',{});rows=meal_rows(src)
    if rows:
        draw(c,x1+6,385,'PLAN',7,True,MUTED);right(c,x1+99,385,'ROOMS',7,True,MUTED);right(c,x1+140,385,'PAX',7,True,MUTED)
        for i,(plan,count,pax,policy) in enumerate(rows[:6]):
            yy=366-i*19
            if i%2==0:
                col(c,SOFT);c.rect(x1,yy-7,leftw,18,fill=1,stroke=0)
            draw(c,x1+8,yy,plan,9,True)
            right(c,x1+99,yy,str(count),8.4)
            right(c,x1+140,yy,str(pax),8.4)
            draw(c,x1+147,yy,trunc(policy,100,7),7,False,MUTED)
        draw(c,x1+6,243,f'TOTAL  {fb["rooms_listed"]} rooms  |  {fb["pax"]} pax',8.1,True,TEAL)
    else:
        block(c,x1,282,leftw,92,6,SOFT,SOFT)
        draw(c,x1+12,341,'NO SAME-DATE F&B REPORT',9,True,ORANGE)
        draw(c,x1+12,321,'Meal plans will appear automatically once',8,False,MUTED)
        draw(c,x1+12,306,'the F&B file for this date is imported.',8,False,MUTED)
    settlements=[('Cash',m['cash']),('Credit cards',m['card']),('City Ledger',m['city_ledger'])]
    for i,(name,val) in enumerate(settlements):line_row(c,x2+6,384-i*29,name,money(val) if 'Cashier Summary' in src or 'Department Summary' in src else '-',x2+rightw-8,rightw-12,alternate=i%2==0)
    draw(c,x2+6,278,'City Ledger = receivables, not cash collected.',7.5,False,MUTED)
    c.setStrokeColor(HexColor(BORDER));c.line(34,226,W-34,226)
    section_label(c,34,209,'Management notes / action points')
    notes=top_items(src,mt,ex,store.notes(d)[0])
    for i,note in enumerate(notes):
        yy=182-24*i
        col(c,TEAL if i==0 else MUTED);c.circle(40,yy+2,2,stroke=0,fill=1)
        draw(c,50,yy,trunc(note,490,8.7),8.7,False,TXT)
    if 'F&B Report' not in src:
        draw(c,34,89,'Meal Plan source not provided for this business date; no figures were assumed.',7.9,False,ORANGE)
    draw(c,34,69,'Full transactions, explanations and exceptions remain in the separate Audit Report.',7.9,False,MUTED)
    footer(c,d);c.showPage();c.save();return path

def meal_plan_pdf(store,d,path):
    src=store.day(d);fb=src.get('F&B Report',{})
    if not fb:raise ValueError('F&B Report not imported for '+d)
    path=str(path);Path(path).parent.mkdir(parents=True,exist_ok=True)
    c=canvas.Canvas(path,pagesize=A4,pageCompression=1);c.setTitle('Sky Star | Meal Plan Entitlements | '+d)
    header(c,d,store.status(d),'MEAL PLANS  /  ENTITLEMENT SNAPSHOT',True)
    gap=9;cw=(MW-2*gap)/3
    card(c,34,610,cw,'Rooms Listed',str(fb['rooms_listed']),'Guest entitlement roster')
    card(c,34+cw+gap,610,cw,'Total Pax',str(fb['pax']),'Adults and children')
    card(c,34+2*(cw+gap),610,cw,'Patterns',str(len(fb['patterns'])),'Configured on guest bookings')
    section_label(c,34,581,'Meal pattern breakdown')
    draw(c,46,557,'MEAL PLAN',8,True,MUTED);right(c,260,557,'ROOMS',8,True,MUTED);right(c,350,557,'PAX',8,True,MUTED)
    draw(c,374,557,'INCLUDED ENTITLEMENT',8,True,MUTED)
    rows=meal_rows(src)
    for i,(plan,n,pax,rule) in enumerate(rows):
        yy=529-i*31
        if i%2==0:col(c,SOFT);c.rect(35,yy-13,W-70,34,fill=1,stroke=0)
        draw(c,46,yy,plan,11,True)
        right(c,260,yy,str(n),10,True)
        right(c,350,yy,str(pax),10,True)
        draw(c,374,yy,trunc(rule,181,8.3),8.3)
    tail=522-min(6,len(rows))*31
    section_label(c,34,tail-12,'Meal codes recorded')
    codes=fb.get('services_rooms',{})
    defs=[('BFST','Breakfast'),('LNCH','Lunch'),('DNNR','Dinner'),('ANB','All-inclusive soft beverage'),('HAN','Hard beverage')]
    for i,(code,label) in enumerate(defs):
        yy=tail-41-i*29
        line_row(c,45,yy,f'{code}  -  {label}',str(codes.get(code,0))+' rooms',535,475,alternate=i%2==0)
    y=tail-206
    block(c,34,y-43,MW,74,6,SOFT,SOFT)
    draw(c,46,y+10,'BEVERAGE POLICY',9,True,TEAL)
    draw(c,46,y-9,'AN: Soft included, Hard chargeable  |  HAN: Soft + Hard included.',8.5,True)
    draw(c,46,y-27,'Figures are entitlements - not drinks poured, actual meals served or extra sales.',8,False,MUTED)
    footer(c,d);c.showPage();c.save();return path

def pdf_export(store,d,path,mode='management'):
    if mode=='management':return management_pdf(store,d,path)
    if mode=='meal_plan':return meal_plan_pdf(store,d,path)
    return previous_pdf_export(store,d,path,mode='audit')
