# Development

The editable application is extracted from the original repository ZIP into `app/`.
The ZIP is retained unchanged. Dashboard changes are in `src/app.py`.

Use Python 3.10+ with Tkinter. In this cloud environment:

```sh
cd /workspace/my-first-project-/app
/workspace/skystar-runtime/.venv/bin/python -m unittest discover -s tests
DISPLAY=:99 /workspace/skystar-runtime/.venv/bin/python src/app.py --demo --db /workspace/skystar-runtime/dashboard-demo.sqlite
```

A desktop display is required for the GUI; :99 is the cloud validation display.
On Windows, install requirements and run `python src/app.py --demo --db demo.sqlite`.
Use an explicit development database. Do not use production data for UI checks.
Optional PyMuPDF enables PDF validation; artifact_tool and the private original
Comsys ZIP tests are skipped when unavailable.
