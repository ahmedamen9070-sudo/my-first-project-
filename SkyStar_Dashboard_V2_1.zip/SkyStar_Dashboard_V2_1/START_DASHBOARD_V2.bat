@echo off
setlocal
cd /d "%~dp0"
title SkyStar Dashboard V2
where py >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py -3"
) else (
  set "PY_CMD=python"
)
%PY_CMD% -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if errorlevel 1 (
  echo Python 3.10 or later is required. Install it from python.org.
  pause
  exit /b 1
)
%PY_CMD% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
  echo Tkinter is missing. Enable Tcl/Tk in the Python installer.
  pause
  exit /b 1
)
%PY_CMD% -c "import reportlab" >nul 2>&1
if errorlevel 1 (
  echo Installing PDF support from requirements.txt...
  %PY_CMD% -m pip install --user -r "%~dp0requirements.txt"
  if errorlevel 1 (
    echo Dependency installation failed. Check the error above and retry.
    pause
    exit /b 1
  )
)
echo Starting SkyStar Dashboard V2 with your existing production workspace...
%PY_CMD% "%~dp0src\app.py"
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" (
  echo Dashboard V2 could not start. Review the error above.
  pause
)
exit /b %APP_EXIT%
