@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   SKY STAR HOTEL - PDF EXPORT SUPPORT INSTALLER
 echo ============================================================
where py >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py -3"
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python is not installed or not on PATH.
    echo Please install Python 3.10+ from https://www.python.org/downloads/windows/
    echo Enable Python Launcher / Add Python to PATH during setup.
    pause
    exit /b 1
  )
  set "PY_CMD=python"
)
echo Checking current Python installation...
%PY_CMD% --version
%PY_CMD% -c "import reportlab" >nul 2>&1
if not errorlevel 1 (
  echo PDF export support is already installed. No changes needed.
  goto :verify
)
echo.
echo ReportLab is missing. Installing it now; internet is required.
%PY_CMD% -m pip install --user -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo INSTALLATION FAILED. Check your internet connection and try again.
  echo Alternatively, open CMD and run: %PY_CMD% -m pip install reportlab
  echo Excel reports can still be exported without ReportLab.
  pause
  exit /b 1
)
:verify
%PY_CMD% -c "import reportlab; print('PDF export READY. ReportLab version:', reportlab.Version)"
if errorlevel 1 (
  echo Install did not succeed for the Python used to run the program.
  pause
  exit /b 1
)
echo.
echo PDF support installed. Restart Sky Star Daily Sales.
pause
exit /b 0
