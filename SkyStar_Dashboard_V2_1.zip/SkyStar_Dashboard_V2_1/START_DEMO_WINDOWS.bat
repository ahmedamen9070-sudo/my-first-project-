@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py -3"
) else (
  set "PY_CMD=python"
)
%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.10+ not found. Install it from python.org.
  pause
  exit /b 1
)
%PY_CMD% -c "import reportlab" >nul 2>&1
if errorlevel 1 (
  echo.
  echo PDF support missing - installing ReportLab automatically...
  %PY_CMD% -m pip install --user -r "%~dp0requirements.txt"
  if errorlevel 1 (
    echo WARNING: ReportLab could not be installed. PDF export will need a later fix.
    echo You can still use the demo and export Excel.
    echo Run FIX_PDF_EXPORT_WINDOWS.bat after checking internet access.
    pause
  )
)
%PY_CMD% src\app.py --demo
if errorlevel 1 (
  echo.
  echo Cannot start. Check the Python installation and error above.
  pause
)
