"""Independent regression: actual approved 10 October + clearly synthetic next day.
No test changes hotel production data or represents sample day 11 as a real booking.
"""
import copy, tempfile, shutil, zipfile, os, sys, unittest, json, sqlite3
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from engine import Store, metrics, checks, parse_source, money, normalize_meal_pattern
from mtd_detail import detail
from company_mix import company_mix
from inhouse_company import complete_guest_payload
from import_bundle import stage_reports
from report_guard import validate_date,BusinessDateMismatch
from native_xlsx import native_excel_export
from exports_pdf_v9 import pdf_export

APPROVED_DB=HERE/'initial_data'/'approved_oct10.sqlite'
CORRECTED=Path('/mnt/data/Reports_10-10-2026_CORRECTED_FULL.zip')

class RevenueQA(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/'qa.sqlite'
        shutil.copyfile(APPROVED_DB,self.db)
        self.s=Store(self.db)
        self.d='2026-10-10'
        self.src=self.s.day(self.d)
    def tearDown(self):
        self.s.close();self.tmp.cleanup()
    def code(self,code):
        return next(c for c in self.src['Department Summary']['codes'] if c['code']==code)
    def next_day(self,changed=False,close=True):
        data=copy.deepcopy(self.src);d='2026-10-11'
        if changed:
            c=next(z for z in data['Department Summary']['codes'] if z['code']==101)
            c['today']=round(c['today']+50,2)
            # Card settlement source entries signed the opposite direction to cash receipt.
            card=next(z for z in data['Department Summary']['codes'] if z['code']==811)
            card['today']=round(card['today']-50,2)
            data['Cashier Summary']['people'][0]['card']+=50
            data['Cashier Summary']['totals']['card']+=50
            data['Daily Sales']['lines']['Total Hotel']['today']+=50
            data['Daily Sales']['lines']['Total Room Rate']['today']+=50
            co=next(z for z in data['Company Revenue']['companies'] if z['company']=='Individual')
            co['room_revenue']+=50;co['total_revenue']+=50
            data['Company Revenue']['totals']['room_revenue']+=50
            data['Company Revenue']['totals']['total_revenue']+=50
            data['Night Report']['revenue']+=50
        reports=[{'date':d,'kind':k,'filename':'SYNTHETIC_UNIT_TEST.xls',
                  'sha256':f'synthetic_11_{k}','date_origin':'report_header','payload':p}
                 for k,p in data.items()]
        result=self.s.save_sources_batch(reports)
        if close:
            self.s.save_notes(d,auditor_note='SYNTHETIC QA only; warning investigations held outside this simulation.')
            self.s.approve_day(d,comsys_closed=True)
        return self.s.day(d)
    def test_source16_and_closed(self):
        self.assertEqual(len(self.src),16);self.assertEqual(self.s.status(self.d),'Closed')
    def test_approved_database_integrity(self):
        self.assertEqual(self.s.db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        self.assertEqual(self.s.db.execute('PRAGMA foreign_key_check').fetchall(),[])
    def test_real_financial_components(self):
        m=metrics(self.src)
        self.assertEqual(tuple(m[k] for k in ('rooms','food','beverage','other','revenue')),
            (159599.23,62411.98,5227.67,786.23,228025.11))
    def test_tax_each_account(self):
        self.assertEqual([self.code(n)['today'] for n in (702,701,703)], [35378.80,27269.16,1844.38])
        self.assertEqual(metrics(self.src)['taxes'],64492.34)
    def test_settlement_split(self):
        m=metrics(self.src)
        self.assertEqual([m[k] for k in ('cash','card','city_ledger','total_settlements')],
                         [1155,21969,173205,196329])
    def test_independent_daily_sales_reference(self):
        m=metrics(self.src);ds=self.src['Daily Sales']
        for item,key in [('Total Hotel','revenue'),('Total Room Rate','rooms'),('Total Food','food'),
                         ('Total Bevarage','beverage'),('Total Other','other')]:
            self.assertAlmostEqual(ds['lines'][item]['today'],m[key],places=2)
    def test_posting_control(self):
        self.assertAlmostEqual(metrics(self.src)['checks']['posting_net_movement'],0,places=2)
    def test_daily_room_identity(self):
        rm=self.src['Rooms Situation']
        self.assertEqual((rm['physical_count'],rm['ooo_in_rooms'],rm['available_for_sale']), (179,4,175))
        self.assertEqual((rm['revenue_occupied'],rm['comp'],rm['house_use'],rm['vacant']), (163,5,1,6))
        self.assertEqual(163+5+1+6,175)
    def test_occupancy_adr_revpar(self):
        m=metrics(self.src)
        self.assertEqual((m['occupancy'],m['adr'],m['revpar']), (93.14,979.14,912))
    def test_room_mix_all_types(self):
        t=company_mix(self.s,self.d)['rows'][-1]['today']
        self.assertEqual(tuple(t[k] for k in ('single','double','triple','quad','rooms','adults')),
                         (127,39,2,1,169,215))
    def test_complimentary_quad_room(self):
        r=next(r for r in company_mix(self.s,self.d)['rows'] if r['name']=='Complimentary Rooms')
        self.assertEqual((r['today']['rooms'],r['today']['quad'],r['today']['adults']), (5,1,11))
    def test_no_dummy_guest(self):
        full=complete_guest_payload(self.src)
        self.assertNotIn('1301',[r['room'] for r in full['guests']]);self.assertEqual(len(full['guests']),169)
    def test_case_history_survives_close(self):
        self.assertEqual({r['code'] for r in self.s.list_audit_cases(self.d)},
                         {'VOID_PAIR','FOLIO_GUEST_LEDGER'})
        self.s.update_audit_case(1,'Under Review','Auditor','Follow up without reopening day')
        self.assertEqual(self.s.status(self.d),'Closed');self.assertTrue(self.s.audit_case_history(1))
    def test_zero_blockers_on_approved_day(self):
        self.assertFalse([x for x in checks(self.src) if x['level']=='BLOCKER'])
    def test_half_up_cash_rounding(self):
        self.assertEqual(money('1.005'),1.01);self.assertEqual(money('-1.005'),-1.01)
    def test_close_requires_independent_daily(self):
        self.s.set_status(self.d,'Pending Review')
        self.s.db.execute("DELETE FROM sources WHERE day=? AND kind='Daily Sales'",(self.d,));self.s.db.commit()
        self.assertIn('Daily Sales',self.s.close_eligibility(self.d)['missing'])
        with self.assertRaises(ValueError):self.s.approve_day(self.d,comsys_closed=True)
    def test_bad_room_pax_blocked(self):
        bad=copy.deepcopy(self.src)
        bad['Guest In House']['guests'][0]['adults']=0
        self.assertIn('UNCLASSIFIED_OCCUPANCY', {x['code'] for x in checks(bad) if x['level']=='BLOCKER'})
    def test_missing_comp_source_is_blocker(self):
        bad=copy.deepcopy(self.src);bad.pop('Complimentary Report')
        self.s.set_status(self.d,'Pending Review')
        self.s.db.execute("DELETE FROM sources WHERE day=? AND kind='Complimentary Report'",(self.d,));self.s.db.commit()
        self.assertIn('Complimentary Report', self.s.close_eligibility(self.d)['missing'])
    def test_missing_paid_rooms_is_blocker(self):
        bad=copy.deepcopy(self.src);bad['Guest In House']['guests'].pop()
        self.assertIn('COMPANY_ROOM_MIX_INCOMPLETE', {x['code'] for x in checks(bad) if x['level']=='BLOCKER'})
    def test_paid_room_ids_checked_not_just_count(self):
        bad=copy.deepcopy(self.src)
        bad['Rooms Situation']['paid_room_ids']=[g['room'] for g in bad['Guest In House']['guests']]
        bad['Rooms Situation']['paid_room_ids'][0]='9999'
        self.assertIn('GUEST_ROOM_ID_MISMATCH',
            {x['code'] for x in checks(bad) if x['level']=='BLOCKER'})
    def test_company_pax_crosscheck(self):
        bad=copy.deepcopy(self.src)
        bad['Company Revenue']['companies'][0]['pax']='999/0/0'
        self.assertIn('COMPANY_ADULT_COUNT',
            {x['code'] for x in checks(bad) if x['level']=='BLOCKER'})
    def test_paid_company_room_revenue_crosscheck(self):
        bad=copy.deepcopy(self.src)
        bad['Company Revenue']['totals']['room_revenue']+=10
        self.assertIn('COMPANY_ROOMS',
            {x['code'] for x in checks(bad) if x['level']=='BLOCKER'})
    def test_wrong_business_date_rejected(self):
        with self.assertRaises(BusinessDateMismatch):
            validate_date({'filename':'Fake.xls','date':'2026-10-09','kind':'Daily Sales'},'2026-10-11')
    def test_closed_day_blocks_import_and_reopen_required(self):
        source={'date':self.d,'kind':'Daily Sales','sha256':'new','filename':'changed.xls','payload':{}}
        with self.assertRaises(ValueError):self.s.save_sources_batch([source],overwrite_kinds=['Daily Sales'])
        self.assertEqual(self.s.status(self.d),'Closed')
    def test_batch_atomic_mixed_dates(self):
        items=[{'date':'2026-10-11','kind':'Daily Sales','sha256':'1','filename':'A','payload':{}},
               {'date':'2026-10-12','kind':'Cashier Summary','sha256':'2','filename':'B','payload':{}}]
        with self.assertRaises(ValueError):self.s.save_sources_batch(items)
        self.assertEqual(self.s.day('2026-10-11'),{})
    def test_batch_atomic_duplicate_kinds(self):
        items=[{'date':'2026-10-11','kind':'Daily Sales','sha256':x,'filename':x,'payload':{}}
               for x in ('1','2')]
        with self.assertRaises(ValueError):self.s.save_sources_batch(items)
        self.assertEqual(self.s.day('2026-10-11'),{})
    def test_date_setting_change_audited(self):
        self.s.set_setting('reporting_start_date','2026-10-09')
        self.assertTrue(self.s.db.execute("SELECT 1 FROM events WHERE action='MTD_START_CHANGED'").fetchone())
    def test_two_day_synthetic_cumulative(self):
        next_data=self.next_day(changed=True);m=metrics(next_data);mt=detail(self.s,'2026-10-11')
        self.assertAlmostEqual(m['revenue'],228075.11,places=2)
        self.assertEqual(mt['expected'],2);self.assertEqual(mt['closed_days'],2)
        self.assertEqual(mt['financial']['revenue'],456100.22)
        self.assertEqual(mt['financial']['rooms'],319248.46)
        self.assertEqual(mt['rooms']['revenue_occupied'],326)
        self.assertEqual(mt['rooms']['available_for_sale'],350)
        self.assertEqual(mt['rooms']['occupancy'],93.14)
        self.assertEqual(mt['rooms']['revpar'],round(319248.46/350,2))
        mix=company_mix(self.s,'2026-10-11')
        t=mix['rows'][-1]['mtd']
        self.assertEqual((t['rooms'],t['quad'],t['adults']), (338,2,430))
    def test_today_is_not_ever_sum_of_mtd_reference(self):
        self.next_day(changed=True)
        mt=detail(self.s,'2026-10-11')
        self.assertNotEqual(mt['financial']['revenue'],self.src['Daily Sales']['comsys_mtd_reference'])
        self.assertEqual(mt['financial']['revenue'],228025.11+228075.11)
    def test_missing_intermediate_day_has_incomplete_mtd(self):
        self.next_day(close=False)
        q=detail(self.s,'2026-10-11')
        self.assertFalse(q['coverage_complete']['Department Summary']);self.assertEqual(q['closed_days'],1)
        self.assertEqual(q['missing_dates'],['2026-10-11'])
    def test_month_transition_resets_mtd(self):
        self.assertEqual(self.s.reporting_start('2026-11-03').isoformat(),'2026-11-01')
    def test_backup_and_restore(self):
        backup=Path(self.tmp.name)/'backup.sqlite';self.s.create_backup(backup)
        self.s.update_audit_case(1,'Under Review','Auditor','Independent investigation remains open')
        self.s.restore_backup(backup)
        self.assertEqual(self.s.list_audit_cases(self.d)[0]['status'],'Open')
        self.assertEqual(self.s.db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
    def test_reject_corrupt_backup(self):
        bad=Path(self.tmp.name)/'invalid.sqlite';bad.write_bytes(b'not a database')
        with self.assertRaises((ValueError,sqlite3.DatabaseError)):self.s.restore_backup(bad)
        self.assertEqual(self.s.status(self.d),'Closed')
    def test_pdf_one_page_content_and_privacy(self):
        try:import fitz
        except ImportError:self.skipTest('PyMuPDF optional for PDF test')
        destination=Path(self.tmp.name)/'report.pdf';pdf_export(self.s,self.d,destination)
        with fitz.open(destination) as pdf:
            self.assertEqual(len(pdf),1)
            page=pdf[0];self.assertAlmostEqual(page.rect.width,842,delta=2)
            text=page.get_text()
            for term in ('PAYMENT','Soft All Inc','Hard All Inc','Quad','14% Sales Tax','12% Service Charge',
                         '1% Municipality Tax','Adult Occupied','Adult Comp','Adult House Use','228,025.11'):
                self.assertIn(term,text)
            self.assertNotIn('113,165.45',text);self.assertNotIn('16298',text)
    def test_xlsx_room_and_company_agreement(self):
        try:from artifact_tool import Blob,SpreadsheetFile
        except ImportError:self.skipTest('artifact_tool optional for external XLSX QA')
        destination=Path(self.tmp.name)/'report.xlsx';native_excel_export(self.s,self.d,destination)
        w=SpreadsheetFile.import_xlsx(Blob.load(str(destination)))
        def cells(sheet,region):return w.worksheets.get_item(sheet).get_range(region).values
        room=cells('Rooms Breakdown MTD','A5:C8')
        self.assertEqual([(x[0],x[1],x[2]) for x in room],
                          [('Single',127,127),('Double',39,39),('Triple',2,2),('Quadruple',1,1)])
        com=cells('Management Companies','A1:U14')
        compl=next(r for r in com if r[0]=='Complimentary Rooms')
        self.assertEqual((compl[1],compl[5],compl[6],compl[11],compl[15]), (5,1,11,5,1))
        self.assertFalse(any('FOLIO_GUEST_LEDGER' in str(c) or 'VOID_PAIR' in str(c)
                             for sheet in [w.worksheets.get_item_at(i) for i in range(9)]
                             for row in sheet.get_range('A1:D35').values for c in row))
    def test_zip_path_traversal_rejected(self):
        zfile=Path(self.tmp.name)/'malice.zip'
        with zipfile.ZipFile(zfile,'w') as z:z.writestr('../danger.xls',b'data')
        with self.assertRaises(ValueError):
            with stage_reports([zfile]):pass
    def test_zip_bad_extension_rejected(self):
        zfile=Path(self.tmp.name)/'bad.zip'
        with zipfile.ZipFile(zfile,'w') as z:z.writestr('malware.exe',b'data')
        with self.assertRaises(ValueError):
            with stage_reports([zfile]):pass
    def test_soft_hard_codes(self):
        self.assertEqual(normalize_meal_pattern('AN'),'AN')
        self.assertEqual(normalize_meal_pattern('HN'),'HAN')
        self.assertEqual(normalize_meal_pattern('HAN'),'HAN')

class RawComsysImportQA(unittest.TestCase):
    def test_actual_zip_16_correct_dates_and_types(self):
        if not CORRECTED.exists():self.skipTest('Private Comsys original zip not part of standalone program')
        with stage_reports([CORRECTED]) as paths:
            self.assertEqual(len(paths),16)
            result=[]
            for p in paths:
                try:source=parse_source(p)
                except ValueError as ex:
                    if p.name.casefold()=='night report.xls' and 'No readable business date' in str(ex):
                        source=parse_source(p,date_override='2026-10-10')
                    else:raise
                result.append(validate_date(source,'2026-10-10'))
            self.assertEqual(len({r['kind'] for r in result}),16)
            self.assertEqual(len([r for r in result if r['date_origin']=='manually_verified']),1)
            dept=next(r for r in result if r['kind']=='Department Summary')
            self.assertEqual(dept['payload']['totals']['Total Hotel']['today'],228025.11) if 'Total Hotel' in dept['payload']['totals'] else self.assertTrue(dept['payload']['codes'])

if __name__=='__main__':unittest.main()
