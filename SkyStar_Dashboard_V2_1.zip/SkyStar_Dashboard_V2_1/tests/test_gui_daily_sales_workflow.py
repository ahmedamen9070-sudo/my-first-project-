"""Exercise real UI import/approval/export callbacks using synthetic raw files."""
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from app import App
from test_daily_sales_workflow import DAY, make_bundle


@unittest.skipUnless(os.environ.get('DISPLAY') or os.name=='nt','A Tk display is required for UI integration')
class GuiDailySalesWorkflow(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.app=App(self.root/'test.sqlite',demo=True)
        self.app.withdraw();self.app.date_var.set(DAY)
        self.callbacks=[];self.app.report_callback_exception=lambda *error:self.callbacks.append(error)
        self.patches=[patch('app.messagebox.showerror'),patch('app.messagebox.showwarning'),
                      patch('app.messagebox.showinfo'),patch('app.messagebox.askyesno',return_value=True)]
        self.messages=[p.start() for p in self.patches]
    def tearDown(self):
        self.app.quit_app()
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()
    def import_reports(self,omit=()):
        bundle=make_bundle(self.root/'reports',DAY,omit)
        with patch('app.filedialog.askopenfilenames',return_value=(str(bundle),)):
            self.app.import_files()
        self.app.update()
    def test_ui_raw_zip_to_daily_sales_exports(self):
        self.import_reports()
        self.assertEqual(len(self.app.store.day(DAY)),16)
        self.assertFalse(self.app.can_export_management())  # Still pending.
        self.app.approve()
        self.assertEqual(self.app.store.status(DAY),'Closed')
        self.assertTrue(self.app.can_export_management())
        xlsx=self.root/'synthetic_daily.xlsx';pdf=self.root/'synthetic_daily.pdf'
        with patch('app.filedialog.asksaveasfilename',return_value=str(xlsx)):
            self.app.export_excel()
        with patch('app.filedialog.asksaveasfilename',return_value=str(pdf)):
            self.app.export_management()
        self.assertTrue(xlsx.is_file());self.assertTrue(pdf.read_bytes().startswith(b'%PDF-'))
        self.messages[0].assert_not_called()
        self.assertEqual(self.callbacks,[])
        self.app.show('Overview');self.app.update()
        self.assertEqual(self.app.dashboard_summary['revenue'],1275)
    def test_ui_missing_fnb_keeps_day_open_and_blocks_export(self):
        self.import_reports(omit={'F____B_Report'})
        self.assertEqual(len(self.app.store.day(DAY)),15)
        self.app.approve()
        self.assertNotEqual(self.app.store.status(DAY),'Closed')
        self.assertIn('F&B Report',self.app.store.close_eligibility(DAY)['missing'])
        with patch('app.filedialog.asksaveasfilename') as chooser:
            self.app.export_excel();self.app.export_management()
        chooser.assert_not_called()
        self.app.show('Overview');self.app.update()
        self.assertEqual(self.app.dashboard_summary['revenue'],1275)
        self.assertEqual(self.app.dashboard_summary['imported_reports'],15)
        self.assertEqual(self.callbacks,[])

if __name__=='__main__':unittest.main()
