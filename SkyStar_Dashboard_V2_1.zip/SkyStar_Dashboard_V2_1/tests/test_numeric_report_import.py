"""Import actual XLSX cells with numeric identifiers; fixtures contain no hotel data."""
import copy
import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from engine import parse_source

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG_REL='http://schemas.openxmlformats.org/package/2006/relationships'
CONTENT='http://schemas.openxmlformats.org/package/2006/content-types'


def _column(index):
    result=''
    index+=1
    while index:
        index,remainder=divmod(index-1,26)
        result=chr(65+remainder)+result
    return result


def write_xlsx(path,sheet_name,rows):
    """Write a minimal OOXML workbook, preserving numeric vs text cell types."""
    root=ET.Element(f'{{{NS}}}worksheet')
    data=ET.SubElement(root,f'{{{NS}}}sheetData')
    for ri,columns in sorted(rows.items()):
        row=ET.SubElement(data,f'{{{NS}}}row',r=str(ri+1))
        for ci,value in sorted(columns.items()):
            cell=ET.SubElement(row,f'{{{NS}}}c',r=f'{_column(ci)}{ri+1}')
            if isinstance(value,(int,float)):
                ET.SubElement(cell,f'{{{NS}}}v').text=str(value)
            else:
                cell.set('t','inlineStr')
                ET.SubElement(ET.SubElement(cell,f'{{{NS}}}is'),f'{{{NS}}}t').text=str(value)
    workbook=ET.Element(f'{{{NS}}}workbook')
    sheets=ET.SubElement(workbook,f'{{{NS}}}sheets')
    ET.SubElement(sheets,f'{{{NS}}}sheet',{'name':sheet_name,'sheetId':'1',f'{{{REL}}}id':'rId1'})
    root_rels=ET.Element(f'{{{PKG_REL}}}Relationships')
    ET.SubElement(root_rels,f'{{{PKG_REL}}}Relationship',Id='rId1',Type=REL+'/officeDocument',Target='xl/workbook.xml')
    workbook_rels=ET.Element(f'{{{PKG_REL}}}Relationships')
    ET.SubElement(workbook_rels,f'{{{PKG_REL}}}Relationship',Id='rId1',Type=REL+'/worksheet',Target='worksheets/sheet1.xml')
    types=ET.Element(f'{{{CONTENT}}}Types')
    ET.SubElement(types,f'{{{CONTENT}}}Default',Extension='rels',ContentType='application/vnd.openxmlformats-package.relationships+xml')
    ET.SubElement(types,f'{{{CONTENT}}}Default',Extension='xml',ContentType='application/xml')
    ET.SubElement(types,f'{{{CONTENT}}}Override',PartName='/xl/workbook.xml',ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml')
    ET.SubElement(types,f'{{{CONTENT}}}Override',PartName='/xl/worksheets/sheet1.xml',ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,element in [('[Content_Types].xml',types),('_rels/.rels',root_rels),
                             ('xl/workbook.xml',workbook),('xl/_rels/workbook.xml.rels',workbook_rels),
                             ('xl/worksheets/sheet1.xml',root)]:
            archive.writestr(name,ET.tostring(element,encoding='utf-8',xml_declaration=True))


class NumericReportImport(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.sequence=0

    def tearDown(self):
        self.tmp.cleanup()

    def payload(self,sheet,rows):
        self.sequence+=1
        path=Path(self.tmp.name)/f'{self.sequence}.xlsx'
        source={0:{0:'Date: 11/10/2026'},**rows}
        write_xlsx(path,sheet,source)
        report=parse_source(path)
        self.assertEqual(report['date'],'2026-10-11')
        self.assertEqual(report['date_origin'],'report_header')
        return report['payload']

    def test_numeric_room_register_matches_text_cells(self):
        rows={4:{0:101,1:'DBL',2:'Y',3:'Occupied'},
              5:{0:102,1:'DBL',2:'Y',3:'Vacant'},
              6:{0:103,1:'DBL',2:'N',3:'OOO'}}
        numeric=self.payload('Rooms_Situation_Report',rows)
        text=copy.deepcopy(rows)
        for row in text.values():row[0]=str(row[0])
        self.assertEqual(numeric,self.payload('Rooms_Situation_Report',text))
        self.assertEqual((numeric['physical_count'],numeric['revenue_occupied'],numeric['vacant'],numeric['ooo_in_rooms']),(3,1,1,1))
        self.assertEqual(numeric['paid_room_ids'],['101'])

    def test_numeric_guest_rooms_and_zero_flags_are_retained(self):
        rows={4:{0:'Room',2:'Pax/Chi/Inf',7:'Company',11:'H/U',12:'Comp'},
              5:{0:101,2:'2/0/0',7:'TEST ACCOUNT',11:0,12:0},
              6:{0:102,2:'1/0/0',7:'TEST ACCOUNT',12:1},
              7:{0:1301,2:'1/0/0',7:'DUMMY'}}
        result=self.payload('Guest_In_House',rows)
        self.assertEqual(result['rooms'],2)
        self.assertEqual((result['paid'],result['complimentary']),(1,1))
        self.assertEqual(result['unknown_flags'],[])
        self.assertEqual(result['excluded_dummy'],['1301'])
        self.assertEqual([x['room'] for x in result['guests']],['101','102'])

    def test_numeric_special_room_registers(self):
        for sheet in ['Complimentary_Report','House_Use_Report']:
            with self.subTest(sheet=sheet):
                result=self.payload(sheet,{4:{0:101,2:'2/0/0',4:'BB',9:'TEST',10:'QA'}})
                self.assertEqual(result['count'],1)
                self.assertEqual(result['rooms'][0]['room'],'101')
                self.assertEqual(result['rooms'][0]['pax'],'2/0/0')

    def test_numeric_fnb_room_is_counted_with_meals_and_people(self):
        result=self.payload('F____B_Report',{4:{0:101,3:'2/1/0',6:'BB',7:'B'},5:{0:102,3:'1/0/0',6:'HB',7:'B,D'}})
        self.assertEqual(result['rooms_listed'],2)
        self.assertEqual(result['pax'],4)
        self.assertEqual(result['patterns'],{'BB':1,'HB':1})
        self.assertEqual(result['services_rooms'],{'B':2,'D':1})

    def test_numeric_out_of_order_room_is_not_dropped(self):
        result=self.payload('Out_of_Order_Rooms',{4:{0:101,1:'11/10/2026',2:'11/10/2026',3:'TEST'}})
        self.assertEqual(result['count'],1)
        self.assertEqual(result['rooms'][0]['room'],'101')

    def test_numeric_posting_item_retains_decimal_amounts(self):
        result=self.payload('Posting_Summary',{4:{0:101,1:'TEST',2:125.75,3:0,4:0,5:0,6:125.75}})
        self.assertEqual(len(result['items']),1)
        self.assertEqual(result['items'][0]['posting_item'],'101')
        self.assertEqual(result['items'][0]['net'],125.75)
        self.assertEqual(result['items'][0]['gross'],125.75)

    def test_numeric_voucher_and_room_retain_void_amounts(self):
        result=self.payload('Voided_Transactions',{4:{0:'Item',5:'TEST ITEM'},5:{0:16298,2:'QA',4:101,6:'VOID',7:-12.25,8:12.25}})
        self.assertEqual(len(result['entries']),1)
        self.assertEqual(result['entries'][0]['voucher'],'16298')
        self.assertEqual(result['entries'][0]['room'],'101')
        self.assertEqual(result['void_sales_value'],12.25)
        self.assertEqual(result['void_settlement_value'],-12.25)

    def test_numeric_dummy_room_evidence_and_audit_identifiers(self):
        detail=self.payload('Department_Details',{4:{0:'Department',5:'301 TEST BEVERAGE'},5:{4:1301,9:12.25}})
        self.assertEqual(detail['dummy_revenue_total'],12.25)
        audit=self.payload('Cashier_Audit',{4:{0:16298}})
        self.assertEqual(audit['original_id_rows'],1)

    def test_numeric_zero_folio_amounts_are_values_not_missing(self):
        labels=['Total Pre-Arrivals','Total Inhouse Guests','Total Guests Checked Out Today','Total Dummy Rooms','Grand Total']
        rows={i+4:{2:label,3:0,8:0,9:0,10:0} for i,label in enumerate(labels)}
        result=self.payload('Rooms_Summary',rows)
        self.assertTrue(result['validated'])
        self.assertEqual(result['computed_balance'],0)

    def test_fractional_identifiers_remain_invalid(self):
        for identifier in [101.5,'101.0']:
            with self.subTest(identifier=identifier),self.assertRaisesRegex(ValueError,'no physical room records'):
                self.payload('Rooms_Situation_Report',{4:{0:identifier,1:'DBL',2:'Y',3:'Occupied'}})


if __name__=='__main__':unittest.main()
