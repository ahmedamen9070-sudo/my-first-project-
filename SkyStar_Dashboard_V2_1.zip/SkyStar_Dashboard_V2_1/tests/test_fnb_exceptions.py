"""Documented F&B unavailability preserves financial controls and source truth."""
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from engine import Store, parse_source, metrics
from import_bundle import stage_reports
from test_daily_sales_workflow import DAY, make_bundle, synthetic_reports, write_xlsx

REASON='F&B Report cannot be regenerated after Comsys Night Run.'


class FnbUnavailableExceptions(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.store=Store(self.root/'qa.sqlite')
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def import_reports(self,omit=('F____B_Report',)):
        bundle=make_bundle(self.root/'reports',DAY,omit)
        with stage_reports([bundle]) as files:
            self.store.save_sources_batch([parse_source(path) for path in files])
    def waive(self):
        return self.store.set_report_unavailable(DAY,'F&B Report',REASON)
    def fnb_source(self):
        path=self.root/'F____B_Report.xlsx'
        write_xlsx(path,'F____B_Report',synthetic_reports()['F____B_Report'])
        return parse_source(path)
    def test_missing_report_stays_required_until_explicit_exception(self):
        self.import_reports()
        before=metrics(self.store.day(DAY))
        self.assertIn('F&B Report',self.store.close_eligibility(DAY)['missing'])
        self.assertEqual(self.waive(),REASON)
        state=self.store.close_eligibility(DAY)
        self.assertNotIn('F&B Report',state['missing'])
        self.assertEqual(state['unavailable'],{'F&B Report':REASON})
        self.assertEqual(state['blockers'],[])
        self.assertTrue(any('F&B Report unavailable' in w for w in state['warnings']))
        self.assertEqual(metrics(self.store.day(DAY)),before)
        self.assertNotIn('F&B Report',self.store.day(DAY))
        self.assertEqual(self.store.status(DAY),'Pending Review')
        self.assertIsNone(self.store.report_unavailable_reason('2026-11-02','F&B Report'))
    def test_exception_requires_review_note_and_explicit_night_audit_confirmation(self):
        self.import_reports();self.waive()
        with self.assertRaisesRegex(ValueError,'auditor note'):
            self.store.approve_day(DAY,comsys_closed=True)
        self.store.save_notes(DAY,auditor_note='Reviewed unavailable F&B source; meal counts remain unavailable.')
        with self.assertRaisesRegex(ValueError,'Night Audit'):
            self.store.approve_day(DAY)
        self.assertNotEqual(self.store.status(DAY),'Closed')
        self.store.approve_day(DAY,comsys_closed=True)
        self.assertEqual(self.store.status(DAY),'Closed')
        cases=self.store.list_audit_cases(DAY)
        case=next(row for row in cases if row['code']=='FNB_SOURCE_UNAVAILABLE')
        self.assertIn(REASON,case['observation'])
        self.assertTrue(self.store.audit_case_history(case['id']))
    def test_only_fnb_can_be_waived_and_reason_is_mandatory(self):
        for kind,reason in [('Daily Sales',REASON),('Department Summary',REASON),('F&B Report','short'),('F&B Report','   ')]:
            with self.subTest(kind=kind,reason=reason):
                with self.assertRaises(ValueError):self.store.set_report_unavailable(DAY,kind,reason)
        self.assertEqual(self.store.day(DAY),{})
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM report_exceptions').fetchone()[0],0)
    def test_closed_days_and_existing_fnb_source_cannot_be_changed(self):
        self.import_reports(omit=())
        with self.assertRaisesRegex(ValueError,'already imported'):self.waive()
        self.store.approve_day(DAY,comsys_closed=True)
        with self.assertRaisesRegex(ValueError,'Closed'):self.waive()
        self.assertEqual(self.store.status(DAY),'Closed')
        self.assertIn('F&B Report',self.store.day(DAY))
    def test_other_missing_reports_and_financial_blockers_stay_blocking(self):
        self.import_reports(omit=('F____B_Report','Daily_Sales'));self.waive()
        state=self.store.close_eligibility(DAY)
        self.assertIn('Daily Sales',state['missing'])
        self.assertTrue(any('Daily Sales' in b for b in state['blockers']))
        with self.assertRaisesRegex(ValueError,'Approval blocked'):
            self.store.approve_day(DAY,comsys_closed=True)
        path=self.root/'Daily_Sales.xlsx'
        rows=synthetic_reports()['Daily_Sales'];rows[4][1]=1276
        write_xlsx(path,'Daily_Sales',rows)
        self.store.save_source(parse_source(path))
        self.assertEqual(self.store.close_eligibility(DAY)['missing'],[])
        self.assertTrue(any('Daily Sales' in b for b in self.store.close_eligibility(DAY)['blockers']))
        with self.assertRaisesRegex(ValueError,'Approval blocked'):
            self.store.approve_day(DAY,comsys_closed=True)
    def test_importing_actual_fnb_clears_exception_without_fabrication(self):
        self.import_reports();self.waive()
        self.assertIsNotNone(self.store.report_unavailable_reason(DAY,'F&B Report'))
        self.store.save_source(self.fnb_source())
        self.assertIsNone(self.store.report_unavailable_reason(DAY,'F&B Report'))
        self.assertEqual(self.store.day(DAY)['F&B Report']['pax'],2)
        self.assertEqual(self.store.close_eligibility(DAY)['warnings'],[])
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM events WHERE action='REPORT_AVAILABLE'").fetchone()[0],1)
        self.assertEqual(self.store.save_source(self.fnb_source()),'skipped')
    def test_failed_batch_rolls_back_exception_clear_and_source_import(self):
        self.import_reports();self.waive()
        bad={'date':DAY,'kind':'Night Report','filename':'broken.xlsx','sha256':'new',
             'payload':{'unsupported':set([1])}}
        with self.assertRaises(TypeError):
            self.store.save_sources_batch([self.fnb_source(),bad],overwrite_kinds=['Night Report'])
        self.assertEqual(self.store.report_unavailable_reason(DAY,'F&B Report'),REASON)
        self.assertNotIn('F&B Report',self.store.day(DAY))
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM events WHERE action='REPORT_AVAILABLE'").fetchone()[0],0)
    def test_repeating_same_exception_is_idempotent_and_updates_are_logged(self):
        self.import_reports();self.waive();self.waive()
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM events WHERE action='REPORT_UNAVAILABLE'").fetchone()[0],1)
        revised=REASON+' Verified by reviewer.'
        self.store.set_report_unavailable(DAY,'F&B Report',revised)
        self.assertEqual(self.store.report_unavailable_reason(DAY,'F&B Report'),revised)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM report_exceptions').fetchone()[0],1)
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM events WHERE action='REPORT_UNAVAILABLE'").fetchone()[0],2)
    def test_backup_restore_retains_exception_and_migrates_older_backups(self):
        self.import_reports();self.waive()
        backup=self.root/'backup.sqlite';self.store.create_backup(backup)
        self.store.set_report_unavailable(DAY,'F&B Report',REASON+' Revised later.')
        self.store.restore_backup(backup)
        self.assertEqual(self.store.report_unavailable_reason(DAY,'F&B Report'),REASON)
        legacy=self.root/'legacy.sqlite';self.store.create_backup(legacy)
        with sqlite3.connect(legacy) as db:db.execute('DROP TABLE report_exceptions')
        before=self.store.restore_backup(legacy)
        self.assertTrue(before.exists())
        self.assertIsNone(self.store.report_unavailable_reason(DAY,'F&B Report'))
        self.assertIn('F&B Report',self.store.close_eligibility(DAY)['missing'])
        self.waive()
        self.assertEqual(self.store.report_unavailable_reason(DAY,'F&B Report'),REASON)

if __name__=='__main__':unittest.main()
