"""Synthetic raw Excel -> ZIP import -> approval -> PDF/XLSX integration.

Generated figures are fictitious. No private reports or production DB are used.
"""
import copy
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from engine import Store, parse_source, metrics, checks
from import_bundle import stage_reports
from report_guard import validate_date
from mtd_detail import detail
from native_xlsx import native_excel_export
from exports_pdf_v9 import pdf_export

DAY='2026-11-01'
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'


def write_xlsx(path,sheet_name,rows):
    def address(col):
        name=''
        while col>=0:
            col,rem=divmod(col,26);name=chr(65+rem)+name;col-=1
        return name
    body=[]
    for row,columns in sorted(rows.items()):
        cells=[]
        for col,value in sorted(columns.items()):
            ref=f'{address(col)}{row+1}'
            if isinstance(value,(int,float)):
                cells.append(f'<c r="{ref}"><v>{value}</v></c>')
            else:
                cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>')
        body.append(f'<row r="{row+1}">'+''.join(cells)+'</row>')
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml',f'<workbook xmlns="{NS}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="{sheet_name}" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{NS}"><sheetData>'+''.join(body)+'</sheetData></worksheet>')


def synthetic_reports(day=DAY):
    # Fictitious 179-room hotel: 4 OOO, 1 paid double, 174 vacant.
    d='/'.join(reversed(day.split('-')))
    header={0:{0:f'SYNTHETIC QA ONLY | Date: {d}'}}
    sheets={}
    dep=copy.deepcopy(header)
    for r,(code,label,amount) in enumerate([(101,'Room Revenue',1000),(201,'Food',200),(301,'Beverage',50),(501,'Laundry',25),
                                          (801,'Cash',-100),(811,'Cards',-200),(821,'City Ledger',-300)],4):
        dep[r]={0:f'{code} {label}',1:amount,2:amount,3:amount}
    dep[12]={0:'Grand Total',1:675,2:675,3:675}
    dep[13]={0:'Total Balance',3:675}
    sheets['Department_Summary']=dep
    cashier=copy.deepcopy(header);cashier[4]={0:'Synthetic cashier',1:100,2:300,3:200,4:0,5:0}
    sheets['Cashier_Summary']=cashier
    rooms=copy.deepcopy(header)
    for i in range(179):
        rooms[i+4]={0:101+i,1:'DBL',2:'Y',3:'OOO' if i>=175 else 'Occupied' if i==0 else 'Vacant',7:''}
    sheets['Rooms_Situation_Report']=rooms
    ooo=copy.deepcopy(header)
    for i in range(4):ooo[4+i]={0:276+i,1:day,2:day,3:'Synthetic maintenance',4:'QA'}
    sheets['Out_of_Order_Rooms']=ooo
    guests=copy.deepcopy(header)
    guests[4]={0:'Room',2:'Pax/Chi/Inf',3:'Meal Pattern',7:'Company',11:'H/U',12:'Comp'}
    guests[5]={0:101,2:'2/0/0',3:'BB',7:'Synthetic QA',11:'N',12:'N'}
    sheets['Guest_In_House']=guests
    company=copy.deepcopy(header)
    company[5]={0:'Synthetic QA',1:'2/0/0',2:0,3:1,4:0,5:0,6:0,7:0,8:1,9:1000,12:250,13:25,14:1275}
    company[6]={**company[5],0:'Total'}
    sheets['Company_Revenue']=company
    fnb=copy.deepcopy(header);fnb[4]={0:101,3:'2/0',6:'BB',7:'BFST'}
    sheets['F____B_Report']=fnb
    posting=copy.deepcopy(header)
    for r,(code,label,amount) in enumerate([(101,'Rooms',1000),(201,'Food',200),(301,'Beverage',50),(501,'Other',25),
                                          (801,'Cash',-100),(811,'Cards',-200),(821,'City Ledger',-300)],4):
        posting[r]={0:code,1:label,2:amount,3:0,4:0,5:0,6:amount}
    posting[12]={1:'Grand Total',2:675,3:0,4:0,5:0,6:675}
    sheets['Posting_Summary']=posting
    for name in ['Complimentary_Report','House_Use_Report']:
        sheets[name]={**copy.deepcopy(header),4:{1:'Total Rooms 0'}}
    night=copy.deepcopy(header);night[4]={0:'Occupied',1:1,2:'2/0'};night[5]={0:'Revenue',2:1000}
    night[6]={0:'Avr. Room Rate',2:1000};night[7]={0:'% Occupancy',2:'0.57%'}
    sheets['Night_Report']=night
    sheets['Voided_Transactions']=copy.deepcopy(header)
    folios=copy.deepcopy(header)
    for r,(label,amount) in enumerate([('Total Pre-Arrivals',0),('Total Inhouse Guests',675),('Total Guests Checked Out Today',0),('Total Dummy Rooms',0),('Grand Total',675)],4):
        folios[r]={2:label,3:amount,8:amount,9:0,10:0}
    sheets['Rooms_Summary']=folios
    sheets['Department_Details']=copy.deepcopy(header)
    sheets['Cashier_Audit']=copy.deepcopy(header)
    daily=copy.deepcopy(header)
    for r,(label,amount) in enumerate([('Total Hotel',1275),('Total Room Rate',1000),('Total Food',200),('Total Bevarage',50),('Total Other',25),('Rooms Occupied',1),('Rooms Available',175)],4):
        daily[r]={0:label,1:amount,4:999999}  # Source MTD reference must never become approved MTD.
    sheets['Daily_Sales']=daily
    return sheets


def make_bundle(directory,day=DAY,omit=()):
    directory.mkdir(parents=True,exist_ok=True)
    reports=synthetic_reports(day)
    bundle=directory/'SYNTHETIC_REPORTS.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        for name,rows in reports.items():
            if name in omit:continue
            path=directory/f'{name}.xlsx';write_xlsx(path,name,rows)
            z.write(path,path.name)
    return bundle


class DailySalesWorkflow(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.store=Store(self.root/'test.sqlite')
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def import_bundle(self,day=DAY,omit=()):
        bundle=make_bundle(self.root/day,day,omit)
        with stage_reports([bundle]) as paths:
            reports=[validate_date(parse_source(path),day) for path in paths]
            return self.store.save_sources_batch(reports)
    def test_raw_16_reports_to_approved_pdf_and_excel(self):
        result=self.import_bundle()
        self.assertEqual(len(result),16)
        self.assertEqual({action for _,action in result},{'imported'})
        src=self.store.day(DAY);value=metrics(src)
        self.assertEqual([value[k] for k in ('rooms','food','beverage','other','revenue')],[1000,200,50,25,1275])
        self.assertEqual([value[k] for k in ('cash','card','city_ledger','grand_total')],[100,200,300,675])
        self.assertEqual([value[k] for k in ('available_for_sale','revenue_occupied','occupancy','adr','revpar')],[175,1,0.57,1000,5.71])
        self.assertFalse([x for x in checks(src) if x['level'] in ('BLOCKER','WARNING')])
        self.assertEqual(self.store.status(DAY),'Pending Review')
        self.assertFalse(self.store.close_eligibility(DAY)['blockers'])
        self.store.approve_day(DAY,comsys_closed=True)
        self.assertEqual(self.store.status(DAY),'Closed')
        pdf=self.root/'daily.pdf';xlsx=self.root/'daily.xlsx'
        pdf_export(self.store,DAY,pdf);native_excel_export(self.store,DAY,xlsx)
        self.assertTrue(pdf.read_bytes().startswith(b'%PDF-'))
        try:import fitz
        except ImportError:fitz=None
        if fitz:
            with fitz.open(pdf) as doc:
                self.assertEqual(len(doc),1)
                self.assertIn('1,275.00',doc[0].get_text())
                self.assertIn('2026-11-01',doc[0].get_text())
        with zipfile.ZipFile(xlsx) as z:
            self.assertIsNone(z.testzip())
            root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            cells={cell.attrib['r']:cell for cell in root.iter(f'{{{NS}}}c')}
            for address,expected in [('B5',1000),('B6',200),('B7',50),('B8',25),('B9',1275)]:
                self.assertEqual(float(cells[address].find(f'{{{NS}}}v').text),expected)
    def test_missing_fnb_keeps_revenue_but_blocks_approval(self):
        self.import_bundle(omit={'F____B_Report'})
        self.assertEqual(len(self.store.day(DAY)),15)
        self.assertEqual(metrics(self.store.day(DAY))['revenue'],1275)
        self.assertIn('F&B Report',self.store.close_eligibility(DAY)['missing'])
        with self.assertRaises(ValueError):self.store.approve_day(DAY,comsys_closed=True)
        self.assertEqual(self.store.status(DAY),'Pending Review')
        path=self.root/DAY/'F____B_Report.xlsx'
        write_xlsx(path,'F____B_Report',synthetic_reports()['F____B_Report'])
        self.store.save_source(parse_source(path))
        self.store.approve_day(DAY,comsys_closed=True)
        self.assertEqual(detail(self.store,DAY)['meal_total'],{'rooms':1,'pax':2})
    def test_raw_reimport_is_idempotent_and_closed_day_protected(self):
        self.import_bundle()
        self.assertEqual({action for _,action in self.import_bundle()},{'skipped'})
        self.store.approve_day(DAY,comsys_closed=True)
        with self.assertRaises(ValueError):self.import_bundle()
        self.assertEqual(self.store.status(DAY),'Closed')
    def test_raw_two_days_use_approved_totals_not_source_mtd(self):
        self.import_bundle();self.store.approve_day(DAY,comsys_closed=True)
        self.import_bundle('2026-11-02')
        self.assertEqual(detail(self.store,'2026-11-02')['financial']['revenue'],1275)
        self.store.approve_day('2026-11-02',comsys_closed=True)
        result=detail(self.store,'2026-11-02')
        self.assertEqual(result['financial']['revenue'],2550)
        self.assertEqual(result['meal_total'],{'rooms':2,'pax':4})
        self.assertTrue(result['coverage_complete']['F&B Report'])
    def test_night_audit_confirmation_is_required(self):
        self.import_bundle()
        with self.assertRaises(ValueError):self.store.approve_day(DAY)
        self.assertEqual(self.store.status(DAY),'Pending Review')

if __name__=='__main__':unittest.main()
