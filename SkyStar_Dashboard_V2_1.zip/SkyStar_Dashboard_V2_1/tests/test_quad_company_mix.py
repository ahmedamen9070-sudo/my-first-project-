"""Regression tests for Quad and PAYMENT change; run python -m unittest discover -s tests -v."""
import pathlib,sys,tempfile,unittest,zipfile,xml.etree.ElementTree as ET
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
from engine import Store,metrics
from company_mix import company_mix
from inhouse_company import occupancy_from_guests,complete_guest_payload
from exports_pdf_v9 import pdf_export
from native_xlsx import native_excel_export

ROOT=pathlib.Path(__file__).resolve().parents[1]
DAY='2026-10-10'
DB=ROOT/'initial_data'/'approved_oct10.sqlite'

class QuadCompanyTests(unittest.TestCase):
    def setUp(self):self.store=Store(DB)
    def tearDown(self):self.store.close()
    def test_approved_comps(self):
        mix=company_mix(self.store,DAY)
        comp=next(row['today'] for row in mix['rows'] if row['name']=='Complimentary Rooms')
        self.assertEqual(tuple(comp.get(k) for k in ('rooms','single','double','triple','quad','adults')),(5,2,1,1,1,11))
        self.assertEqual(mix['today_gap'],0)
        self.assertEqual(mix['mtd_gap'],0)
    def test_totals_match_room_and_adults(self):
        rows=company_mix(self.store,DAY)['rows'];total=rows[-1]
        for key in ('today','mtd'):
            row=total[key]
            self.assertEqual(row['rooms'],169)
            self.assertEqual(row['quad'],1)
            self.assertEqual(row['adults'],215)
            self.assertEqual(sum(row[t] for t in ('single','double','triple','quad')),169)
            self.assertEqual(sum(row[t]*i for i,t in enumerate(('single','double','triple','quad'),1)),215)
        self.assertAlmostEqual(metrics(self.store.day(DAY))['revenue'],228025.11,2)
        self.assertEqual(self.store.status(DAY),'Closed')
    def test_room_432(self):
        rooms=complete_guest_payload(self.store.day(DAY))['guests']
        self.assertEqual([(z['room'],z['kind'],z['adults']) for z in rooms if z['room']=='432'],[('432','comp',4)])
    def test_future_quad_and_overoccupancy(self):
        grouped,errors=occupancy_from_guests({'guests':[
            {'room':'500','company':'Future','kind':'paid','adults':4},
            {'room':'501','company':'Future','kind':'paid','adults':5},
            {'room':'1301','company':'Future','kind':'paid','adults':4},
        ]},['Future'])
        self.assertEqual(grouped['Future']['rooms'],2)
        self.assertEqual(grouped['Future']['quad'],1)
        self.assertEqual(grouped['Future']['adults'],9)
        self.assertTrue(any('501' in x for x in errors))
    def test_pdf_layout(self):
        try:import fitz
        except ImportError:self.skipTest('PyMuPDF optional for PDF text validation')
        with tempfile.TemporaryDirectory() as tmp:
            path=pathlib.Path(tmp)/'test.pdf'
            pdf_export(self.store,DAY,path)
            document=fitz.open(path)
            self.assertEqual(len(document),1)
            page=document[0]
            self.assertGreater(page.rect.width,page.rect.height)
            words=[w[4] for w in page.get_text('words')]
            self.assertIn('PAYMENT',words)
            self.assertEqual(words.count('Quad'),2)
            self.assertIn('Complimentary',words)
            self.assertIn('228,025.11',words)
            self.assertNotIn('VOID_PAIR',words)
            self.assertNotIn('FOLIO_GUEST_LEDGER',words)
    def test_excel_today_and_mtd_quad(self):
        ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        with tempfile.TemporaryDirectory() as tmp:
            path=pathlib.Path(tmp)/'test.xlsx'
            native_excel_export(self.store,DAY,path)
            with zipfile.ZipFile(path) as z:
                index=ET.fromstring(z.read('xl/workbook.xml'))
                names=[sheet.get('name') for sheet in index.findall('x:sheets/x:sheet',ns)]
                sheet_num=names.index('Management Companies')+1
                root=ET.fromstring(z.read(f'xl/worksheets/sheet{sheet_num}.xml'))
                cells={cell.get('r'):cell for cell in root.findall('.//x:c',ns)}
                def get(cell):
                    c=cells.get(cell)
                    if c is None:return None
                    return c.findtext('x:v',namespaces=ns) or ''.join(n.text or '' for n in c.findall('.//x:t',ns))
                self.assertEqual(get('F3'),'TODAY Quad')
                self.assertEqual(get('P3'),'MTD Quad')
                # Comp row and Total row are at the end of the management grid.
                self.assertEqual(get('A10'),'Complimentary Rooms')
                self.assertEqual(get('F10'),'1.0')
                self.assertEqual(get('P10'),'1.0')
                self.assertEqual(get('A12'),'TOTAL OCCUPIED MIX')
                self.assertEqual(get('F12'),'1.0')
                self.assertEqual(get('P12'),'1.0')
                self.assertNotIn('Audit & Sources',names)

if __name__=='__main__':unittest.main()
