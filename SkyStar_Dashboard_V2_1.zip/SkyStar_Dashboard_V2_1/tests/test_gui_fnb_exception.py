"""Operator workflow for one unavailable F&B source after Comsys Night Run."""
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from app import App
from test_daily_sales_workflow import DAY,make_bundle

REASON='PRIVATE QA: Comsys cannot regenerate this F&B report after Night Run.'

@unittest.skipUnless(os.environ.get('DISPLAY') or os.name=='nt','A Tk display is required')
class GuiFnbException(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.app=App(self.root/'test.sqlite',demo=True);self.app.withdraw();self.app.date_var.set(DAY)
        self.patches=[patch('app.messagebox.showerror'),patch('app.messagebox.showwarning'),
                      patch('app.messagebox.showinfo'),patch('app.messagebox.askyesno',return_value=True)]
        self.messages=[p.start() for p in self.patches]
    def tearDown(self):
        self.app.quit_app()
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()
    def import_reports(self,day=DAY,omit=('F____B_Report',)):
        bundle=make_bundle(self.root/day,day,omit)
        self.app.date_var.set(day)
        with patch('app.filedialog.askopenfilenames',return_value=(str(bundle),)):
            self.app.import_files()
    def record_exception(self,reason=REASON):
        with patch('app.simpledialog.askstring',return_value=reason):
            self.app.record_fnb_unavailable()
    def test_documented_exception_still_needs_signoff_and_manual_approval(self):
        self.import_reports();self.record_exception()
        self.assertEqual(self.app.store.report_unavailable_reason(DAY,'F&B Report'),REASON)
        self.assertNotEqual(self.app.store.status(DAY),'Closed')
        self.app.approve()
        self.assertNotEqual(self.app.store.status(DAY),'Closed')
        self.app.store.save_notes(DAY,auditor_note='QA reviewer confirms unavailable F&B; meal counts must remain unavailable.')
        self.app.approve()
        self.assertEqual(self.app.store.status(DAY),'Closed')
        self.assertTrue(self.app.can_export_management())
        xlsx=self.root/'daily.xlsx';pdf=self.root/'daily.pdf'
        with patch('app.filedialog.asksaveasfilename',return_value=str(xlsx)):self.app.export_excel()
        with patch('app.filedialog.asksaveasfilename',return_value=str(pdf)):self.app.export_management()
        self.assertTrue(xlsx.is_file());self.assertTrue(pdf.is_file())
        self.messages[0].assert_not_called()
    def test_cancel_does_not_create_exception(self):
        self.import_reports();self.record_exception(None)
        self.assertIsNone(self.app.store.report_unavailable_reason(DAY,'F&B Report'))
        self.assertIn('F&B Report',self.app.store.close_eligibility(DAY)['missing'])
    def test_short_explanation_is_rejected(self):
        self.import_reports();self.record_exception('missing')
        self.assertIsNone(self.app.store.report_unavailable_reason(DAY,'F&B Report'))
        self.messages[0].assert_called_once()
    def test_exception_does_not_waive_financial_source(self):
        self.import_reports(omit=('F____B_Report','Daily_Sales'));self.record_exception()
        self.app.store.save_notes(DAY,auditor_note='QA reason for unavailable F&B, not other reports.')
        self.app.approve()
        self.assertNotEqual(self.app.store.status(DAY),'Closed')
        self.assertIn('Daily Sales',self.app.store.close_eligibility(DAY)['missing'])
    def test_previous_documented_day_does_not_block_financial_mtd(self):
        self.import_reports();self.record_exception()
        self.app.store.save_notes(DAY,auditor_note='QA reviewer confirms source unavailable after Night Run.')
        self.app.approve()
        self.import_reports('2026-11-02',omit=())
        self.app.approve()
        self.assertEqual(self.app.store.status('2026-11-02'),'Closed')
        self.assertTrue(self.app.can_export_management())
    def test_missing_fnb_still_blocks_standalone_meal_plan(self):
        self.import_reports();self.record_exception()
        self.app.store.save_notes(DAY,auditor_note='QA reviewer: source unavailable; meal plan cannot be issued.')
        self.app.approve()
        with patch('app.filedialog.asksaveasfilename') as chooser:self.app.export_meal_plan()
        chooser.assert_not_called()
        self.assertEqual(self.messages[1].call_args[0][0],'Meal Plan source missing')

if __name__=='__main__':unittest.main()
