"""Regression tests for v8.7: no hotel PII, no real day approval."""
import copy,json,sqlite3,sys,tempfile,unittest,struct
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from comsys_reader import _decode_sst
from engine import Store,checks,parse_folios,parse_guest_inhouse,parse_evidence

class ReaderFixes(unittest.TestCase):
    def test_sst_continue_marker_not_string_data(self):
        # BIFF SST total/unique and a string 'ABCD' broken by encoding marker
        header=struct.pack('<IIHB',1,1,4,0)
        blocks=[header+b'AB',b'\x00CD']
        self.assertEqual(_decode_sst(blocks),['ABCD'])
    def test_folio_no_missing_grand_total_is_ever_zero(self):
        rows={1:{2:'Total Pre-Arrivals',8:'10',9:'(1)',10:'(2)'},
              2:{2:'Total Inhouse Guests',8:'20',9:'(3)',10:'(4)'},
              3:{2:'Total Guests Checked Out Today',8:'30',9:'(5)',10:'(6)'},
              4:{2:'Total Dummy Rooms',8:'40',9:'(7)',10:'(8)'}}
        with self.assertRaisesRegex(ValueError,'Grand Total'):
            parse_folios(rows)
        rows[5]={2:'Grand Total',8:'100',9:'(16)',10:'(20)'}
        self.assertEqual(parse_folios(rows)['computed_balance'],64)
        rows[5][8]='101'
        with self.assertRaisesRegex(ValueError,'differs'):
            parse_folios(rows)
    def test_classifies_gm_and_mgmt_only_in_explicit_flag_columns(self):
        rows={1:{0:'Date: 11/10/2026'},
              4:{0:'Room',2:'Pax/Chi/Inf',7:'Company',11:'H/U',12:'Comp'},
              5:{0:'101',2:'2/0/0',7:'Dmc Mena',12:'GM'},
              6:{0:'116',2:'1/0/0',7:'Manager',11:'MGMT'},
              7:{0:'102',2:'1/0/0',7:'Comp'}}
        x=parse_guest_inhouse(rows)
        self.assertEqual((x['paid'],x['complimentary'],x['house_use']),(1,1,1))
        self.assertEqual(x['unknown_flags'],[])
    def test_unknown_status_blocks(self):
        rows={1:{0:'Date: 11/10/2026'},4:{0:'Room',2:'Pax/Chi/Inf',7:'Company',11:'H/U',12:'Comp'},
              5:{0:'101',2:'1/0/0',7:'A',12:'SOME-UNRECOGNIZED-CODE'}}
        x=parse_guest_inhouse(rows)
        self.assertEqual(len(x['unknown_flags']),1)
    def test_dummy1301_financial_trace(self):
        rows={1:{0:'Department',5:'301 Pool Bar Beverage'},2:{4:'1301',9:'100.00'},
              3:{0:'Department',5:'501 Laundry'},4:{4:'1301',9:'20.00'},
              5:{0:'Department',5:'701 Tax'},6:{4:'1301',9:'140.00'},
              7:{0:'Department',5:'601 Transfer'},8:{4:'1301',9:'90.00'},
              9:{4:'205',9:'50.00'}}
        x=parse_evidence(rows,'Department Details')
        self.assertEqual(x['dummy_revenue_total'],120.00)
        self.assertEqual(x['dummy_revenue_by_department'],{'Pool Bar Beverage':100.0,'Laundry':20.0})

class ReparseSafety(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.tmp.name)/'local.sqlite')
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    @staticmethod
    def report(payload):
        return {'date':'2026-10-11','kind':'Guest In House','filename':'same.xls',
                'sha256':'unchanged original file hash','payload':payload,'date_origin':'report_header'}
    def test_same_sha_reprocesses_and_records_history(self):
        self.assertEqual(self.store.save_source(self.report({'paid':161})),'imported')
        self.assertEqual(self.store.save_source(self.report({'paid':156})),'reprocessed')
        self.assertEqual(self.store.day('2026-10-11')['Guest In House']['paid'],156)
        hist=self.store.db.execute('SELECT payload FROM source_versions').fetchall()
        self.assertEqual(len(hist),1)
        self.assertEqual(json.loads(hist[0][0])['paid'],161)
        self.assertEqual(self.store.save_source(self.report({'paid':156})),'skipped')
    def test_closed_day_remains_immutable(self):
        self.store.save_source(self.report({'paid':161}))
        self.store.set_status('2026-10-11','Closed')
        with self.assertRaisesRegex(ValueError,'Closed'):
            self.store.save_source(self.report({'paid':156}))
        self.assertEqual(self.store.day('2026-10-11')['Guest In House']['paid'],161)
    def test_all_16_required_for_new_day(self):
        result=self.store.close_eligibility('2026-10-11')
        self.assertEqual(len(result['missing']),16)

if __name__=='__main__':unittest.main()
