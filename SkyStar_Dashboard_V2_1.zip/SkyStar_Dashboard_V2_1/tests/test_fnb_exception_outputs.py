"""Missing F&B remains an explicit output limitation, never invented meal counts."""
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from engine import Store,parse_source
from import_bundle import stage_reports
from native_xlsx import native_excel_export
from exports_pdf_v9 import pdf_export
from mtd_detail import detail
from test_daily_sales_workflow import make_bundle,DAY,NS

PRIVATE_REASON='PRIVATE REVIEWER REASON: Night Run already completed; no historical F&B export.'


def workbook_cells(path):
    with zipfile.ZipFile(path) as archive:
        result={}
        workbook=ET.fromstring(archive.read('xl/workbook.xml'))
        for i,sheet in enumerate(workbook.findall(f'.//{{{NS}}}sheet'),1):
            root=ET.fromstring(archive.read(f'xl/worksheets/sheet{i}.xml'))
            cells={}
            for cell in root.iter(f'{{{NS}}}c'):
                inline=cell.find(f'.//{{{NS}}}t')
                numeric=cell.find(f'{{{NS}}}v')
                cells[cell.attrib['r']]=inline.text if inline is not None else float(numeric.text) if numeric is not None else None
            result[sheet.attrib['name']]=cells
        raw='\n'.join(archive.read(n).decode('utf-8') for n in archive.namelist() if n.endswith('.xml'))
        return result,raw


class FnbExceptionOutputs(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.store=Store(self.root/'test.sqlite')
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def import_day(self,day=DAY,missing=False):
        bundle=make_bundle(self.root/day,day,{'F____B_Report'} if missing else ())
        with stage_reports([bundle]) as paths:
            self.store.save_sources_batch([parse_source(p) for p in paths])
        if missing:
            self.store.set_report_unavailable(day,'F&B Report',PRIVATE_REASON)
            self.store.save_notes(day,auditor_note='Synthetic reviewer approves the documented source limitation.')
        self.store.approve_day(day,comsys_closed=True)
    def export_excel(self,day=DAY):
        output=self.root/'daily.xlsx';native_excel_export(self.store,day,output)
        return workbook_cells(output)
    def test_missing_today_meals_blank_and_revenue_unchanged(self):
        self.import_day(missing=True)
        sheets,raw=self.export_excel()
        self.assertEqual(sheets['Daily Sales']['B9'],1275)
        self.assertEqual(sheets['Daily Sales']['B6'],200)
        self.assertEqual(sheets['Daily Sales']['B7'],50)
        self.assertIn('F&amp;B source unavailable today; meal statistics incomplete.',raw)
        self.assertNotIn(PRIVATE_REASON,raw)
        meal=sheets['Meal Plans Today MTD']
        for row in range(5,12):
            for column in 'BCDE':self.assertIsNone(meal.get(f'{column}{row}'))
        package=sheets['Package Averages']
        for row in range(5,9):
            for column in 'CDFG':self.assertIsNone(package.get(f'{column}{row}'))
    def test_partial_mtd_is_not_released_as_a_complete_count(self):
        self.import_day(missing=True)
        next_day='2026-11-02';self.import_day(next_day)
        monthly=detail(self.store,next_day)
        self.assertEqual(monthly['financial']['revenue'],2550)
        self.assertEqual(monthly['fnb_missing_dates'],[DAY])
        self.assertEqual(monthly['meal_total'],{'rooms':1,'pax':2})  # Observed partial data, not released as total.
        self.assertFalse(monthly['coverage_complete']['F&B Report'])
        sheets,raw=self.export_excel(next_day)
        meal=sheets['Meal Plans Today MTD']
        self.assertEqual((meal['B5'],meal['C5']),(1,2))
        for row in range(5,12):
            for column in 'DE':self.assertIsNone(meal.get(f'{column}{row}'))
        for row in range(5,9):
            for column in 'FG':self.assertIsNone(sheets['Package Averages'].get(f'{column}{row}'))
        self.assertIn('F&amp;B source unavailable in MTD; meal statistics incomplete.',raw)
    def test_missing_fnb_pdf_has_public_limitation_without_private_reason(self):
        try:import fitz
        except ImportError:self.skipTest('PyMuPDF optional for PDF content validation')
        self.import_day(missing=True)
        path=self.root/'daily.pdf';pdf_export(self.store,DAY,path)
        with fitz.open(path) as pdf:
            self.assertEqual(len(pdf),1)
            text=pdf[0].get_text()
            self.assertIn('F&B source unavailable today; meal statistics incomplete.',text)
            self.assertIn('1,275.00',text)
            self.assertNotIn(PRIVATE_REASON,text)
    def test_complete_fnb_outputs_keep_existing_counts(self):
        self.import_day()
        sheets,raw=self.export_excel()
        meal=sheets['Meal Plans Today MTD']
        self.assertEqual(tuple(meal[f'{column}5'] for column in 'BCDE'),(1,2,1,2))
        self.assertNotIn('source unavailable',raw)
        self.assertEqual(detail(self.store,DAY)['fnb_missing_dates'],[])
    def test_standalone_meal_plan_cannot_be_fabricated(self):
        self.import_day(missing=True)
        with self.assertRaisesRegex(ValueError,'F&B Report'):
            pdf_export(self.store,DAY,self.root/'meals.pdf',mode='meal_plan')
        self.assertFalse((self.root/'meals.pdf').exists())

if __name__=='__main__':unittest.main()
