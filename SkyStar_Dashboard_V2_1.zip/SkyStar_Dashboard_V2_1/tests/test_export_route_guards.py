"""Exercise real export entry points without writing reports or production data."""
import copy
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
from app import App, company_mix


@unittest.skipUnless(os.environ.get('DISPLAY'), 'GUI route checks require a display')
class ExportRouteGuards(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        database=Path(self.tmp.name)/'isolated.sqlite'
        shutil.copyfile(HERE/'initial_data'/'approved_oct10.sqlite',database)
        self.app=App(database,demo=True)
        self.addCleanup(self.app.quit_app)
        self.app.update()
        self.day=self.app.date_var.get()
        # Keep real source/financial state and real row structure. Only raise the
        # presented company count beyond the fixed one-page PDF capacity.
        over_limit=copy.deepcopy(company_mix(self.app.store,self.day))
        while len(over_limit['rows'])<16:
            over_limit['rows'].insert(-1,copy.deepcopy(over_limit['rows'][0]))
        self.mix=self.enter_patch(patch('app.company_mix',return_value=over_limit))
        self.chooser=self.enter_patch(patch('app.filedialog.asksaveasfilename',return_value=''))
        self.warning=self.enter_patch(patch('app.messagebox.showwarning'))

    def enter_patch(self, patcher):
        result=patcher.start()
        self.addCleanup(patcher.stop)
        return result

    def test_excel_ignores_pdf_page_capacity(self):
        self.app.export_excel()
        self.chooser.assert_called_once()
        self.warning.assert_not_called()

    def test_meal_plan_ignores_company_pdf_capacity(self):
        self.app.export_meal_plan()
        self.chooser.assert_called_once()
        self.warning.assert_not_called()

    def test_management_pdf_retains_company_capacity_guard(self):
        self.app.export_management()
        self.chooser.assert_not_called()
        self.warning.assert_called_once()
        self.assertEqual(self.warning.call_args.args[0],'Company table exceeds A4')

    def test_print_preview_retains_company_capacity_guard(self):
        self.app.print_preview()
        self.chooser.assert_not_called()
        self.warning.assert_called_once()
        self.assertEqual(self.warning.call_args.args[0],'Company table exceeds A4')
        self.assertFalse((Path(self.tmp.name)/'print_previews').exists())

    def test_excel_still_requires_day_approval(self):
        self.app.store.set_status(self.day,'Pending Review')
        self.app.export_excel()
        self.chooser.assert_not_called()
        self.assertEqual(self.warning.call_args.args[0],'Day is not approved')

    def test_excel_still_rejects_unresolved_import_alert(self):
        self.app.store.add_import_alert(self.day,'wrong-date.xls','Synthetic wrong-date alert')
        self.app.export_excel()
        self.chooser.assert_not_called()
        self.assertEqual(self.warning.call_args.args[0],'Private date verification')

    def test_excel_still_rejects_financial_blockers(self):
        # Simulate an inconsistent historical Closed snapshot in this copied DB.
        # This deliberately changes one side of the posting reconciliation.
        department=self.app.store.day(self.day)['Department Summary']
        department['codes'][0]['today']+=10
        self.app.store.db.execute(
            "UPDATE sources SET payload=? WHERE day=? AND kind='Department Summary'",
            (json.dumps(department),self.day))
        self.app.store.db.commit()
        self.app.export_excel()
        self.chooser.assert_not_called()
        self.assertEqual(self.warning.call_args.args[0],'Private audit blockers')

    def test_excel_still_requires_complete_mtd_dates(self):
        self.app.store.set_setting('reporting_start_date','2026-10-09')
        self.app.export_excel()
        self.chooser.assert_not_called()
        self.assertEqual(self.warning.call_args.args[0],'Private MTD source coverage')


if __name__=='__main__':unittest.main()
