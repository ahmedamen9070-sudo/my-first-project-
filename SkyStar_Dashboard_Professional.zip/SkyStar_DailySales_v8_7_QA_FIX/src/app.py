"""Sky Star Daily Sales v8.3: closed-day Comsys management & private audit case follow-up."""
from __future__ import annotations
import argparse, shutil, os, subprocess
from pathlib import Path
from datetime import date,timedelta
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
from engine import Store,parse_source,metrics,checks,monthly,generate_commentary,normalize_meal_pattern
from native_xlsx import native_excel_export as workbook_export
from exports_pdf_v9 import pdf_export
from exports_pdf_v4 import generate_compact_commentary
from mtd_detail import detail as mtd_detail, values_for_fnb
from company_mix import company_mix
from report_guard import validate_date, import_batch_guard
from import_bundle import stage_reports

NAVY='#13263F'; DEEP='#0C1C31'; BLUE='#225B9B'; CYAN='#247DAD'; BG='#EFF3F8'; WHITE='#FFFFFF'
TEXT='#142B45'; MUTED='#677B91'; LINE='#DCE5EE'; GREEN='#087F70'; AMBER='#C47C2B'; RED='#B94A4A'
FONT='Segoe UI' if os.name=='nt' else 'Noto Sans'
MODULES=[('Overview','Dashboard', 'Executive KPIs, daily position & close status'),('Revenue','Revenue', 'Revenue codes, daily and cumulative'),
         ('Rooms','Rooms & Occupancy','179 rooms, operating capacity & statistics'),('Company & F&B','Company & F&B','Account contribution and meal entitlement'),
         ('Settlements','Cashier & Ledger','Cash, cards, city ledger and balances'),('Audit','Audit & Exceptions','Differences, control findings and explanations'),
         ('Commentary','Management Commentary','Review and edit the written management report'),('MTD','MTD & Coverage','Closed-day monthly totals and missing dates'),
         ('Import','Import & Day Close','Load Comsys sources and approve a day')]

def money(n):return f'{float(n or 0):,.2f}'

def clear(frame):
    for x in frame.winfo_children():x.destroy()

class App(tk.Tk):
    def __init__(self,path,demo=False):
        super().__init__();self.store=Store(path);self.demo=demo;self.screen='Overview'
        self.title('Sky Star Hotel  |  Daily Sales & Revenue Control  v8.7 QA FIX — DAILY SALES'+(' [DEMO]' if demo else ''))
        self.geometry('1400x865');self.minsize(1130,725);self.configure(bg=BG)
        self.date_var=tk.StringVar(value='2026-10-09' if demo else (self.store.days()[0] if self.store.days() else '2026-10-10'))
        self.start_var=tk.StringVar(value=self.store.get_setting('reporting_start_date','2026-10-10'))
        self.bottom_text=tk.StringVar(value='Ready  •  Local, separate database  •  Reports are not automatically emailed')
        st=ttk.Style();st.theme_use('clam')
        st.configure('Report.Treeview',font=(FONT,10),rowheight=30,background=WHITE,fieldbackground=WHITE,foreground=TEXT,borderwidth=0)
        st.configure('Report.Treeview.Heading',font=(FONT,10,'bold'),background='#EAF0F7',foreground=NAVY,relief='flat',padding=9)
        st.map('Report.Treeview',background=[('selected',BLUE)],foreground=[('selected','white')])
        st.configure('TCombobox',padding=6)
        self.nav_buttons={}
        self.build_shell();self.show('Overview')
        self.protocol('WM_DELETE_WINDOW',self.quit_app)

    def quit_app(self):self.store.close();self.destroy()
    def label(self,parent,text,size=10,bold=False,color=TEXT,bg=None,**kw):
        return tk.Label(parent,text=text,font=(FONT,size,'bold' if bold else 'normal'),fg=color,bg=bg or parent.cget('bg'),**kw)
    def button(self,parent,text,command,primary=False,fg=None,padx=16):
        return tk.Button(parent,text=text,command=command,bg=BLUE if primary else WHITE,fg=fg or (WHITE if primary else NAVY),
            activebackground='#164D82' if primary else '#EDF3F9',activeforeground=WHITE if primary else NAVY,
            font=(FONT,9,'bold'),relief='flat',bd=0,cursor='hand2',padx=padx,pady=10,
            highlightbackground=LINE,highlightthickness=0)
    def panel(self,parent,fill='both',expand=False,pad=18):
        f=tk.Frame(parent,bg=WHITE,highlightbackground=LINE,highlightthickness=1)
        f.pack(fill=fill,expand=expand,padx=1,pady=1)
        inner=tk.Frame(f,bg=WHITE,padx=pad,pady=pad);inner.pack(fill='both',expand=True)
        return inner
    def heading(self,parent,title,subtitle=None):
        self.label(parent,title,14,True).pack(anchor='w',pady=(0,3))
        if subtitle:self.label(parent,subtitle,9,color=MUTED).pack(anchor='w',pady=(0,15))
    def colheader(self,parent,title):self.label(parent,title,10,True,color=NAVY).pack(anchor='w',pady=(0,10))

    def build_shell(self):
        main=tk.Frame(self,bg=BG);main.pack(fill='both',expand=True)
        self.sidebar=tk.Frame(main,bg=NAVY,width=246);self.sidebar.pack(side='left',fill='y');self.sidebar.pack_propagate(False)
        brand=tk.Frame(self.sidebar,bg=DEEP,height=120);brand.pack(fill='x');brand.pack_propagate(False)
        self.label(brand,'SKY STAR',20,True,WHITE,DEEP).pack(anchor='w',padx=22,pady=(25,0))
        self.label(brand,'HOTEL  /  FINANCE & CONTROL',8,True,'#AFC3DC',DEEP).pack(anchor='w',padx=23,pady=5)
        self.label(self.sidebar,'WORKSPACE',8,True,'#7FA1C8',NAVY).pack(anchor='w',padx=20,pady=(23,11))
        for key,title,_ in MODULES:
            row=tk.Frame(self.sidebar,bg=NAVY,height=46);row.pack(fill='x',padx=9,pady=1);row.pack_propagate(False)
            text=tk.Label(row,text=title,font=(FONT,10,'bold'),fg='#C8D7E7',bg=NAVY,anchor='w',padx=17,cursor='hand2')
            text.pack(fill='both',expand=True);text.bind('<Button-1>',lambda e,n=key:self.show(n))
            self.nav_buttons[key]=(row,text)
        self.label(self.sidebar,'COMSYS  4.8.17',9,True,'#7296BD',NAVY).pack(side='bottom',anchor='w',padx=23,pady=(0,22))
        self.root_body=tk.Frame(main,bg=BG);self.root_body.pack(side='left',fill='both',expand=True)
        self.header=tk.Frame(self.root_body,bg=WHITE,height=88,highlightbackground=LINE,highlightthickness=1)
        self.header.pack(fill='x');self.header.pack_propagate(False)
        names=tk.Frame(self.header,bg=WHITE);names.pack(side='left',padx=24,pady=12)
        self.current_title=self.label(names,'Executive Overview',19,True,NAVY,WHITE);self.current_title.pack(anchor='w')
        self.current_desc=self.label(names,'Daily sales performance & financial control',9,color=MUTED,bg=WHITE);self.current_desc.pack(anchor='w',pady=(2,0))
        actions=tk.Frame(self.header,bg=WHITE);actions.pack(side='right',padx=22,pady=14)
        self.label(actions,'BUSINESS DATE',8,True,MUTED,WHITE).pack(side='left',padx=(0,6))
        self.dbox=ttk.Combobox(actions,textvariable=self.date_var,state='normal',width=11,font=(FONT,10))
        self.dbox.pack(side='left');self.dbox.bind('<<ComboboxSelected>>',lambda e:self.show(self.screen));self.dbox.bind('<Return>',lambda e:self.show(self.screen))
        self.button(actions,'Load',lambda:self.show(self.screen),padx=12).pack(side='left',padx=(5,8))
        self.button(actions,'Excel',self.export_excel).pack(side='left',padx=4)
        self.button(actions,'Management PDF',self.export_management,True).pack(side='left',padx=4)
        self.button(actions,'Print Preview',self.print_preview,padx=11).pack(side='left',padx=4)
        self.meta=tk.Frame(self.root_body,bg=BG,height=48);self.meta.pack(fill='x',padx=23);self.meta.pack_propagate(False)
        self.date_badge=self.label(self.meta,'',9,True,BLUE,BG);self.date_badge.pack(side='left',pady=14)
        self.data_badge=self.label(self.meta,'',9,color=MUTED,bg=BG);self.data_badge.pack(side='right',pady=14)
        self.content=tk.Frame(self.root_body,bg=BG);self.content.pack(fill='both',expand=True,padx=22,pady=(0,13))
        foot=tk.Frame(self.root_body,bg=DEEP,height=32);foot.pack(side='bottom',fill='x');foot.pack_propagate(False)
        tk.Label(foot,textvariable=self.bottom_text,bg=DEEP,fg='#C4D7EA',font=(FONT,8)).pack(side='left',padx=20,pady=7)

    def state(self):
        d=self.date_var.get().strip()
        try:date.fromisoformat(d)
        except ValueError:raise ValueError('Business Date must follow YYYY-MM-DD')
        src=self.store.day(d);return d,src,metrics(src),checks(src),monthly(self.store,d),self.store.status(d)
    def show(self,key):
        try:d,src,m,ex,mt,status=self.state()
        except ValueError as e:messagebox.showerror('Date format',str(e));return
        if key=='Commentary' and self.screen=='Commentary' and hasattr(self,'comment_text') and self.comment_text.winfo_exists():
            pass # Commentary is saved using explicit Save; no silent mutation.
        self.screen=key;clear(self.content)
        self.dbox['values']=self.store.days();self.date_badge.configure(text=f'{status.upper()}  •  {d}',fg=GREEN if status=='Closed' else AMBER)
        self.data_badge.configure(text=f'{len(src)} imported sources   •   {len([x for x in ex if x["level"]=="BLOCKER"])} blockers   •   {len([x for x in ex if x["level"]=="WARNING"])} warnings   •   {len(self.store.list_audit_cases(day=d,include_resolved=False))} open audit cases')
        for k,(row,t) in self.nav_buttons.items():
            active=k==key;row.configure(bg=BLUE if active else NAVY);t.configure(bg=BLUE if active else NAVY,fg=WHITE if active else '#C8D7E7')
        title,desc=next((title,desc) for k,title,desc in MODULES if k==key)
        self.current_title.configure(text=title);self.current_desc.configure(text=desc)
        getattr(self,'page_'+__import__('re').sub(r'[^a-z0-9]+','_',key.lower()).strip('_'))(d,src,m,ex,mt,status)
        self.bottom_text.set(f'{"DEMO • sample reports only" if self.demo else "LOCAL WORKSPACE"}   |   {status}   |   Closed-day MTD only   |   Data folder: {self.store.path.parent}')

    def statcard(self,parent,label,value,sub='',accent=BLUE):
        outer=tk.Frame(parent,bg=WHITE,highlightbackground=LINE,highlightthickness=1);outer.pack(side='left',fill='both',expand=True,padx=5,pady=4)
        tk.Frame(outer,bg=accent,height=4).pack(fill='x')
        self.label(outer,label.upper(),9,True,MUTED,WHITE).pack(anchor='w',padx=15,pady=(11,5))
        self.label(outer,value,19,True,NAVY,WHITE).pack(anchor='w',padx=15)
        self.label(outer,sub,8,color=MUTED,bg=WHITE).pack(anchor='w',padx=15,pady=(1,10))
    def data_table(self,parent,columns,rows,widths=None,height=10):
        container=tk.Frame(parent,bg=WHITE);container.pack(fill='both',expand=True)
        needs_scroll=len(columns)>9
        stage=tk.Frame(container,bg=WHITE);stage.pack(fill='both',expand=True)
        tree=ttk.Treeview(stage,columns=[f'c{i}' for i in range(len(columns))],
                          show='headings',style='Report.Treeview',height=height)
        sb=ttk.Scrollbar(stage,command=tree.yview);tree.configure(yscrollcommand=sb.set)
        for i,name in enumerate(columns):
            key=f'c{i}';tree.heading(key,text=name)
            tree.column(key,width=(widths[i] if widths else 140),minwidth=64,
                        stretch=not needs_scroll,anchor='w' if i==0 else 'e')
        for idx,row in enumerate(rows):tree.insert('','end',values=row,tags=('stripe',) if idx%2 else ())
        tree.tag_configure('stripe',background='#F6F9FC')
        tree.pack(side='left',fill='both',expand=True);sb.pack(side='right',fill='y')
        if needs_scroll:
            xbar=ttk.Scrollbar(container,orient='horizontal',command=tree.xview)
            tree.configure(xscrollcommand=xbar.set)
            xbar.pack(side='bottom',fill='x')
        tree.bind('<Double-1>',lambda event:self._view_full_row(tree,columns))
        return tree
    def _view_full_row(self,tree,columns):
        chosen=tree.selection()
        if chosen:
            vals=tree.item(chosen[0],'values')
            messagebox.showinfo('Full source detail','\n\n'.join(str(k)+':  '+str(v) for k,v in zip(columns,vals)))

    def note(self,parent,text,kind='info'):
        color={'info':BLUE,'warn':AMBER,'error':RED,'ok':GREEN}[kind]
        block=tk.Frame(parent,bg='#F7FAFD',highlightbackground=LINE,highlightthickness=1)
        block.pack(fill='x',pady=(9,0));tk.Frame(block,bg=color,width=5).pack(side='left',fill='y')
        self.label(block,text,9,color=NAVY,bg='#F7FAFD',justify='left',wraplength=850).pack(anchor='w',padx=14,pady=11)
        return block

    def page_overview(self,d,src,m,ex,mt,status):
        detail=mtd_detail(self.store,d);fd=detail['financial'];rr=detail['rooms'];cov=detail['coverage']
        has_revenue='Department Summary' in src
        has_rooms='Rooms Situation' in src
        blockers=sum(x['level']=='BLOCKER' for x in ex)
        warnings=sum(x['level']=='WARNING' for x in ex)
        hero=tk.Frame(self.content,bg=DEEP,padx=22,pady=16);hero.pack(fill='x',pady=(0,12))
        text=tk.Frame(hero,bg=DEEP);text.pack(side='left')
        self.label(text,'YOUR DAILY PERFORMANCE',8,True,'#8AB7D8',DEEP).pack(anchor='w')
        self.label(text,'A clear view of your hotel.',20,True,WHITE,DEEP).pack(anchor='w',pady=(4,2))
        self.label(text,f'{d}  /  Today and approved month-to-date',9,color='#B7C9DD',bg=DEEP).pack(anchor='w')
        self.button(hero,'Review day  →',lambda:self.show('Import'),True).pack(side='right',padx=(12,0))
        self.label(hero,'CLOSED' if status=='Closed' else 'PENDING REVIEW',9,True,
                   '#80DEC5' if status=='Closed' else '#F5CD90',DEEP).pack(side='right')
        cards=tk.Frame(self.content,bg=BG);cards.pack(fill='x',pady=(0,8))
        values=[('Hotel revenue',money(m['revenue']) if has_revenue else '—',
                 'MTD  '+money(fd['revenue']) if cov['Department Summary'] else 'Awaiting approved MTD',BLUE),
                ('Paid occupancy',f"{m['occupancy']:.2f}%" if has_rooms and 'occupancy' in m else '—',
                 f"{m.get('revenue_occupied',0)} paid / {m.get('available_for_sale',0)} operating rooms" if has_rooms else 'Room report needed',GREEN),
                ('Average daily rate',money(m['adr']) if has_rooms and 'adr' in m else '—',
                 'MTD  '+money(rr['adr']) if cov['Rooms Situation'] and rr.get('adr') is not None else 'Per paid occupied room',CYAN),
                ('Revenue / available room',money(m['revpar']) if has_rooms and 'revpar' in m else '—',
                 'MTD  '+money(rr['revpar']) if cov['Rooms Situation'] and rr.get('revpar') is not None else 'Based on operating rooms',BLUE)]
        for label,value,sub,color in values:self.statcard(cards,label,value,sub,color)
        strip=tk.Frame(self.content,bg=WHITE,padx=16,pady=10,highlightbackground=LINE,highlightthickness=1)
        strip.pack(fill='x',pady=(0,12))
        for label,value in [('Cash + cards',money(m['cash']+m['card']) if has_revenue else '—'),
                            ('City ledger',money(m['city_ledger']) if has_revenue else '—'),
                            ('Reports imported',str(len(src))),('Open audit cases',str(len(self.store.list_audit_cases(day=d,include_resolved=False))))]:
            cell=tk.Frame(strip,bg=WHITE);cell.pack(side='left',fill='x',expand=True)
            self.label(cell,label,8,color=MUTED,bg=WHITE).pack(anchor='w')
            self.label(cell,value,12,True,NAVY,WHITE).pack(anchor='w',pady=(3,0))
        body=tk.Frame(self.content,bg=BG);body.pack(fill='both',expand=True)
        body.columnconfigure(0,weight=3,uniform='dashboard');body.columnconfigure(1,weight=2,uniform='dashboard');body.rowconfigure(0,weight=1)
        left=tk.Frame(body,bg=BG);left.grid(row=0,column=0,sticky='nsew',padx=(0,6))
        right=tk.Frame(body,bg=BG);right.grid(row=0,column=1,sticky='nsew',padx=(6,0))
        panel=self.panel(left,expand=True,pad=16)
        self.colheader(panel,'REVENUE BREAKDOWN')
        self.label(panel,'Today  /  Approved MTD',8,color=MUTED,bg=WHITE).pack(anchor='w',pady=(0,10))
        colors=[BLUE,CYAN,GREEN,'#A18AC7']
        largest=max([abs(m[k]) for k in ['rooms','food','beverage','other']]+[1])
        for (label,key),color in zip([('Rooms','rooms'),('Food','food'),('Beverage','beverage'),('Other income','other')],colors):
            row=tk.Frame(panel,bg=WHITE);row.pack(fill='x',pady=(0,9))
            self.label(row,label,9,True,bg=WHITE).pack(side='left')
            self.label(row,(money(m[key]) if has_revenue else '—')+'  /  '+(money(fd[key]) if cov['Department Summary'] else '—'),9,color=MUTED,bg=WHITE).pack(side='right')
            bar=tk.Canvas(panel,height=5,bg='#EDF2F7',highlightthickness=0);bar.pack(fill='x',pady=(0,10))
            fraction=min(abs(m[key])/largest,1) if has_revenue else 0
            def draw(event,canvas=bar,ratio=fraction,fill=color):
                canvas.delete('all');canvas.create_rectangle(0,0,event.width*ratio,5,fill=fill,outline='')
            bar.bind('<Configure>',draw)
        footer=tk.Frame(panel,bg='#F0F5FB',padx=10,pady=9);footer.pack(fill='x',side='bottom')
        self.label(footer,'TOTAL HOTEL REVENUE',8,True,BLUE,'#F0F5FB').pack(side='left')
        self.label(footer,money(m['revenue']) if has_revenue else '—',13,True,NAVY,'#F0F5FB').pack(side='right')
        panel=self.panel(right,expand=True,pad=16)
        self.colheader(panel,'DAILY CONTROL')
        if not src:headline='Start with your daily reports';hint='Import the Comsys reports for this business date.';color=BLUE
        elif blockers:headline=f'{blockers} blocker(s) to resolve';hint='Review controls before approving this day.';color=RED
        elif warnings:headline=f'{warnings} warning(s) to review';hint='Check supporting evidence and reviewer notes.';color=AMBER
        else:headline='No major differences detected';hint='Review source completeness before approval.';color=GREEN
        self.label(panel,headline,12,True,color,WHITE,wraplength=280,justify='left').pack(anchor='w',pady=(4,6))
        self.label(panel,hint,9,color=MUTED,bg=WHITE,wraplength=280,justify='left').pack(anchor='w',pady=(0,12))
        for label,value in [('Day status',status),('Blockers',str(blockers)),('Warnings',str(warnings))]:
            row=tk.Frame(panel,bg=WHITE);row.pack(fill='x',pady=5)
            self.label(row,label,9,color=MUTED,bg=WHITE).pack(side='left')
            self.label(row,value,9,True,bg=WHITE).pack(side='right')
        actions=tk.Frame(panel,bg=WHITE);actions.pack(side='bottom',fill='x',pady=(12,0))
        self.button(actions,'Open audit & exceptions  →',lambda:self.show('Audit'),padx=10).pack(fill='x')
        self.button(actions,'Import & day close  →',lambda:self.show('Import'),True,padx=10).pack(fill='x',pady=(6,0))
        self.note(self.content,'Approved MTD: '+('COMPLETE — all covered dates are Closed.' if mt['complete'] else f'INCOMPLETE — {len(mt["missing"])} date(s) missing or not Closed. Only approved days contribute.'),'ok' if mt['complete'] else 'warn')

    def page_revenue(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Revenue Performance','Operating revenue is separate from adjustments, taxes, settlement movements and ledger balances.')
        box=self.panel(self.content,expand=True,pad=15)
        self.data_table(box,['Category','Today','Approved MTD','Comsys MTD ref','Comsys YTD ref','Basis'],self.revenue_rows(src,mtd_detail(self.store,d)),[210,115,125,128,128,260],16)
        self.note(self.content,'* Comsys MTD / YTD are reference figures, not independently reconstructed totals. Only Closed days from October form approved MTD. Transportation 904 and code 599 adjustments are separately classified.','warn' if not mt['complete'] else 'info')
    def revenue_rows(self,src,mtd=None):
        dep=src.get('Department Summary',{});codes=dep.get('codes',[])
        mapping=[('Rooms',set([101,102,103,104,105,199,903]),'Room charges; 904 separate'),('Food',set([201,202,203,204,205,250,251,252,299]),'Restaurants and meal packages'),
                 ('Beverage',set([253,301,302,303,304,305,399]),'Includes AI allocations'),('Other Income',set([350,401,402,403,499,501,502,503,550,590]),'Excludes revenue adjustments'),
                 ('Other Adjustment',{599},'Income adjustment'),('Transportation',{904},'Separate from room revenue'),('Service Charge + Taxes',set([701,702,703,704,705]),'Not additional hotel revenue')]
        rows=[]
        for name,grp,note in mapping:
            data=[round(sum(x[k] for x in codes if x['code'] in grp),2) for k in ('today','mtd','ytd')]
            keymap={'Rooms':'rooms','Food':'food','Beverage':'beverage','Other Income':'other','Other Adjustment':'adjustment','Transportation':'transportation','Service Charge + Taxes':'taxes'}
            mtval=mtd['financial'].get(keymap.get(name)) if mtd and mtd['coverage']['Department Summary'] else None
            rows.append((name,money(data[0]) if codes else '—',money(mtval) if mtval is not None else '—',*[money(x) if codes else '—' for x in data[1:]],note))
        if codes:
            n=4; totals=[round(sum(sum(x[k] for x in codes if x['code'] in g) for g in [mapping[i][1] for i in range(n)]),2) for k in ('today','mtd','ytd')]
            rows.insert(4,('TOTAL HOTEL REVENUE',money(totals[0]),money(mtd['financial']['revenue']) if mtd and mtd['coverage']['Department Summary'] else '—',money(totals[1]),money(totals[2]),'Not increased by company classifications'))
        # Expand the detailed Department Code register directly below the summary.
        if codes:
            dc=mtd.get('department_codes',{}) if mtd else {}
            covered=bool(mtd and mtd['coverage']['Department Summary'])
            detail=sorted(codes,key=lambda item:int(item['code']))
            for x in detail:
                if x.get('code') in (599,904,701,702,703,704,705,801,802,803,811,812,813,814,821,822,601):
                    continue  # Settlements and taxes already have their own groups.
                rows.append((f'    {x["code"]}  {x["label"]}',money(x['today']),
                     money(dc.get(x['code'],0)) if covered else '—',money(x['mtd']),money(x['ytd']),'Comsys detailed department code'))
        return rows

    def page_rooms(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Rooms & Occupancy','Physical vs operating rooms • Complimentary and house-use rooms tracked separately')
        a=tk.Frame(self.content,bg=BG);a.pack(fill='x',pady=(0,12))
        for label,v,note in [('PHYSICAL ROOMS',str(m.get('physical_count','—')),'179 confirmed hotel inventory'),
                ('OUT OF ORDER',str(m.get('ooo_in_rooms','—')),'Already excluded'),('OPERATING ROOMS',str(m.get('available_for_sale','—')),'No second OOO deduction'),
                ('PAID OCCUPANCY',f'{m["occupancy"]:.2f}%' if 'occupancy' in m else '—','Paid occupied / operating')]:self.statcard(a,label,v,note)
        blocks=tk.Frame(self.content,bg=BG);blocks.pack(fill='both',expand=True)
        left=tk.Frame(blocks,bg=BG);left.pack(side='left',fill='both',expand=True,padx=(0,10));p=self.panel(left,expand=True)
        self.colheader(p,'ROOM MOVEMENT & PRICE')
        month=mtd_detail(self.store,d);rm=month['rooms']
        month_cov=month['coverage']
        certified_mix=company_mix(self.store,d)
        real_today=certified_mix['rows'][-1]['today'] or {}
        real_mtd=certified_mix['rows'][-1]['mtd'] or {}
        rows=[]
        for label,key in [('Physical Rooms','physical_count'),('O.O.O.','ooo_in_rooms'),
            ('Rooms Occupied','revenue_occupied'),('Rooms Available','available_for_sale'),
            ('Rooms Vacant','vacant'),('Rooms Comp.','comp'),('House Use','house_use'),
            ('% Occupancy','occupancy'),('Avr. Room Rate','adr'),('RevPAR','revpar')]:
            dval=m.get(key,'—') if 'Rooms Situation' in src else '—'
            mon=rm.get(key,'—') if month_cov['Rooms Situation'] else '—'
            rows.append((label,dval,mon))
        for label,key in [('Rooms Single','single'),('Rooms Double','double'),('Rooms Triple','triple'),('Rooms Quadruple','quad'),
                          ('Rooms Above 4 Pax','other_type'),('Suite','suite')]:
            rows.append((label,real_today.get(key,'—') if key in ('single','double','triple','quad') else '—',
                         real_mtd.get(key,'—') if key in ('single','double','triple','quad') and certified_mix['mtd_complete'] else '—'))
        self.data_table(p,['Statistic','Today','Approved MTD'],rows,[250,118,130],height=17)
        right=tk.Frame(blocks,bg=BG);right.pack(side='left',fill='both',expand=True,padx=(10,0));p=self.panel(right,expand=True)
        self.colheader(p,'ROOM TYPE ANALYSIS')
        breakdown=src.get('Rooms Situation',{}).get('room_type_counts',{})
        type_mtd={}
        from datetime import timedelta
        if month_cov['Rooms Situation']:
            first=self.store.reporting_start(d)
            for idx in range((date.fromisoformat(d)-first).days+1):
                other_day=(first+timedelta(days=idx)).isoformat()
                if self.store.status(other_day)!='Closed':continue
                report=self.store.day(other_day).get('Rooms Situation',{})
                for name,value in report.get('room_type_counts',{}).items():
                    type_mtd[name]=type_mtd.get(name,0)+value
        self.data_table(p,['Room Type (Comsys)','Operating Today','MTD Room-nights'],
            [(key,breakdown.get(key,0) if 'Rooms Situation' in src else '—',
            type_mtd.get(key,0) if month_cov['Rooms Situation'] else '—')
            for key in sorted(set(breakdown)|set(type_mtd))],[190,115,115],height=16)
        oos=src.get('Rooms Situation',{}).get('oos_occupied',[])
        self.note(self.content,f'Control: {"Occupied OOS rooms to review: "+", ".join(oos) if oos else "No Occupied OOS exception in uploaded register."}  •  Paid occupancy excludes Complimentary and House Use.', 'warn' if oos else 'info')

    def page_company_f_b(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Company Revenue / Meal Plan / Package Average',
            'Guest In House counts and adults + Company Revenue amounts • Today then approved MTD • Dummy 1301 excluded')
        details=mtd_detail(self.store,d);cov=details['coverage']
        mix=company_mix(self.store,d)
        def fmt_count(v):return '—' if v is None else f'{v:,.0f}'
        def fmt_money(v):return '—' if v is None else money(v)
        def fmt_pct(v):return '—' if v is None else f'{v:,.2f}%'
        section=tk.Frame(self.content,bg=BG);section.pack(fill='both',expand=True)
        p=self.panel(section,expand=True,pad=10)
        self.colheader(p,'COMPANY & OCCUPANCY MIX  |  GUEST IN HOUSE + REVENUE  •  TODAY THEN MTD')
        headers=['Company']+['D '+x for x in ('Rooms','SGL','DBL','TPL','Quad','Adults','Mix %','Room Rev','F&B Rev','Total Rev')]+[
                                 'MTD '+x for x in ('Rooms','SGL','DBL','TPL','Quad','Adults','Mix %','Room Rev','F&B Rev','Total Rev')]
        vals=[]
        for record in mix['rows']:
            def group(data,pct):
                if data is None:return ['—']*10
                return [fmt_count(data.get(k)) for k in ('rooms','single','double','triple','quad','adults')]+[
                    fmt_pct(pct)]+[fmt_money(data.get(k)) for k in ('room_revenue','fnb_revenue','total_revenue')]
            vals.append([record['name']]+group(record['today'],record['today_mix'])+group(record['mtd'],record['mtd_mix']))
        widths=[170]+[77,54,54,54,54,70,68,110,110,110]*2
        self.data_table(p,headers,vals,widths,height=min(14,max(8,len(vals)+2)))
        bottom=tk.Frame(self.content,bg=BG);bottom.pack(fill='both',expand=True,pady=(8,0))
        p=self.panel(bottom,expand=True,pad=11);self.colheader(p,'MEAL PLAN  •  ROOM / PAX NIGHTS')
        fnb=src.get('F&B Report',{});pd=values_for_fnb(fnb)
        plans=[]
        for code in ('BB','HB','FB','AN','HAN','BED'):
            dv=pd.get(code,{});mv=details['meal_plans'].get(code,{})
            plans.append(({'AN':'Soft All Inc','HAN':'Hard All Inc'}.get(code,code),dv.get('rooms',0) if fnb else '—',dv.get('pax',0) if fnb else '—',
                mv.get('rooms',0) if cov['F&B Report'] else '—',mv.get('pax',0) if cov['F&B Report'] else '—'))
        self.data_table(p,['Plan','Rooms Today','Pax Today','Rooms MTD','Pax MTD'],plans,[125,92,92,92,92],height=6)
        p2=self.panel(bottom,expand=True,pad=11);self.colheader(p2,'PACKAGE AVERAGE  •  REVENUE / ENTITLED PAX')
        source={int(r['code']):r.get('today',0) for r in src.get('Department Summary',{}).get('codes',[])}
        srcm=details['department_codes']
        def entitled(code,groups):
            if not fnb:return None
            expected=sum(pd.get(z,{}).get('rooms',0) for z in groups)
            if expected!=fnb.get('services_rooms',{}).get(code):return None
            return sum(pd.get(z,{}).get('pax',0) for z in groups)
        spec=[(250,'Breakfast','BFST',('BB','HB','FB','AN','HAN')),(252,'Lunch','LNCH',('FB','AN','HAN')),
              (251,'Dinner','DNNR',('HB','FB','AN','HAN')),(253,'AI Beverage','ANB',('AN','HAN'))]
        vals=[]
        valid_pairs=[]
        first=self.store.reporting_start(d)
        for i in range((date.fromisoformat(d)-first).days+1):
            day=(first+timedelta(days=i)).isoformat()
            if self.store.status(day)=='Closed':
                ss=self.store.day(day)
                if 'Department Summary' in ss and 'F&B Report' in ss:valid_pairs.append(ss)
        for code,name,svc,groups in spec:
            amount=source.get(code,0) if 'Department Summary' in src else None;pax=entitled(svc,groups)
            month_pax=0;month_rev=0
            matched=bool(valid_pairs) and len(valid_pairs)==cov['Department Summary']==cov['F&B Report']
            for obj in valid_pairs:
                f=obj['F&B Report'];parts=values_for_fnb(f)
                persons=sum(parts.get(g,{}).get('pax',0) for g in groups)
                rooms=sum(parts.get(g,{}).get('rooms',0) for g in groups)
                if rooms!=f.get('services_rooms',{}).get(svc):matched=False;break
                month_pax+=persons
                month_rev+=sum(x['today'] for x in obj['Department Summary']['codes'] if int(x['code'])==code)
            vals.append((name,money(amount) if amount is not None else '—',money(amount/pax) if pax and amount is not None and (amount!=0 or status=='Closed') else '—',
                money(srcm.get(code,0)) if cov['Department Summary'] else '—',money(month_rev/month_pax) if matched and month_pax else '—'))
        self.data_table(p2,['Package','Rev D','Avg/Pax D','Rev MTD','Avg/Pax MTD'],vals,[130,94,94,102,104],height=6)

    def page_settlements(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Cashier & Guest Ledger','Cash collections, card receipts and City Ledger transfers are three distinct concepts.')
        a=tk.Frame(self.content,bg=BG);a.pack(fill='x',pady=(0,13))
        for k,val,sub in [('CASH',m['cash'],'Actual recorded cash'),('CREDIT CARDS',m['card'],'Card settlements'),('CITY LEDGER',m['city_ledger'],'Credit to receivables'),('GUEST LEDGER',m.get('guest_ledger_closing'),'Closing balance, not daily revenue')]:
            self.statcard(a,k,money(val) if val is not None and src else '—',sub)
        frame=tk.Frame(self.content,bg=BG);frame.pack(fill='both',expand=True)
        left=tk.Frame(frame,bg=BG);left.pack(side='left',fill='both',expand=True,padx=(0,8));p=self.panel(left,expand=True)
        self.colheader(p,'CASHIER REGISTER')
        people=src.get('Cashier Summary',{}).get('people',[])
        self.data_table(p,['Cashier','Cash','Card','City Ledger','Transfers'],[(x['cashier'],money(x['cash']),money(x['card']),money(x['city_ledger']),money(x['transfer_activity'])) for x in people],height=9)
        right=tk.Frame(frame,bg=BG);right.pack(side='left',fill='both',expand=True,padx=(8,0));p=self.panel(right,expand=True)
        self.colheader(p,'FINANCIAL BRIDGE')
        month=mtd_detail(self.store,d); fm=month['financial']
        self.data_table(p,['Movement','Today','Approved MTD'],[(label,money(m[key]),money(fm[key]) if month['coverage']['Department Summary'] else '—') for label,key in
           [('Net Posted Revenue','net_revenue'),('Service Charge + Taxes','taxes'),('Cash','cash'),('Cards','card'),('City Ledger','city_ledger'),('Net Posting Movement','grand_total')]] + [('Guest Ledger closing (snapshot)',money(m.get('guest_ledger_closing')) if m.get('guest_ledger_closing') is not None else '—',money(month['guest_ledger_last_balance']) if month['guest_ledger_last_balance'] is not None else '—')],height=9)
        self.note(self.content,'Guest Ledger closing balance is a dated snapshot and must not be added across days. Comsys Grand Total is a net posting movement, not profit or sales.','info')

    def page_audit(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Audit & Exceptions — Private Follow-up',
                     'Audit cases remain open after Daily Sales closing, without changing exported management numbers.')
        self._alerts_panel(d,self.content)
        tabs=ttk.Notebook(self.content)
        self.audit_tabs=tabs
        tabs.pack(fill='both',expand=True,pady=(7,0))
        cases_tab=tk.Frame(tabs,bg=BG);control_tab=tk.Frame(tabs,bg=BG)
        tabs.add(cases_tab,text='Investigation Register')
        tabs.add(control_tab,text='Live Controls & Sign-off')
        toolbar=tk.Frame(cases_tab,bg=BG);toolbar.pack(fill='x',pady=(10,5))
        self.audit_all_dates=getattr(self,'audit_all_dates',False)
        self.label(toolbar,'CLOSED-DAY FOLLOW-UP  •  OUTSTANDING / RESOLVED',10,True).pack(side='left')
        self.button(toolbar,'Show All Dates' if not self.audit_all_dates else 'Selected Date Only',
                    self.toggle_audit_dates).pack(side='right')
        selected_date=None if self.audit_all_dates else d
        items=self.store.list_audit_cases(day=selected_date)
        table_frame=self.panel(cases_tab,fill='x',pad=8)
        self.audit_case_tree=ttk.Treeview(table_frame,columns=('Date','Control','Priority','Status','Owner'),
                                        show='headings',height=5,style='Report.Treeview',selectmode='browse')
        for key,wide in [('Date',110),('Control',195),('Priority',90),('Status',125),('Owner',190)]:
            self.audit_case_tree.heading(key,text=key)
            self.audit_case_tree.column(key,width=wide,minwidth=70,stretch=key in ('Control','Owner'))
        for item in items:
            self.audit_case_tree.insert('', 'end',iid=str(item['id']),
                                        values=(item['day'],item['code'],item['severity'],item['status'],item['owner']))
        self.audit_case_tree.pack(fill='x')
        self.audit_case_tree.bind('<<TreeviewSelect>>',self.select_audit_case)
        self.audit_cases_by_id={str(item['id']):item for item in items}
        if not items:
            self.label(cases_tab,'No registered warning cases in this view. Other notices appear under Live Controls.',
                       9,color=MUTED).pack(anchor='w',pady=(4,7))
        review=self.panel(cases_tab,expand=True,pad=11)
        self.audit_case_detail=self.label(review,'Select a case to inspect its findings and audit history.',
                                          9,color=TEXT,wraplength=970,justify='left')
        self.audit_case_detail.pack(anchor='w',pady=(0,7))
        form=tk.Frame(review,bg=WHITE);form.pack(fill='x',pady=(0,4))
        self.label(form,'Status:',9,True,bg=WHITE).pack(side='left')
        self.audit_case_status=tk.StringVar(value='Open')
        self.audit_status_select=ttk.Combobox(form,textvariable=self.audit_case_status,
            values=('Open','Under Review','Resolved'),state='readonly',width=14)
        self.audit_status_select.pack(side='left',padx=(6,17))
        self.label(form,'Revenue auditor / owner:',9,True,bg=WHITE).pack(side='left')
        self.audit_case_owner=tk.StringVar()
        tk.Entry(form,textvariable=self.audit_case_owner,width=29,font=(FONT,10)).pack(side='left',padx=(5,12))
        self.button(form,'Save Follow-up',self.save_audit_case,True).pack(side='right')
        self.label(review,'Investigation comment (required, retained permanently):',9,True,bg=WHITE).pack(anchor='w')
        self.audit_case_comment=tk.Text(review,height=3,wrap='word',font=(FONT,9),fg=TEXT,bg='#F9FBFD',relief='solid',bd=1)
        self.audit_case_comment.pack(fill='x',pady=(2,7))
        self.label(review,'CASE HISTORY — audit trail:',9,True,bg=WHITE).pack(anchor='w')
        hist_frame=tk.Frame(review,bg=WHITE);hist_frame.pack(fill='both',expand=True)
        self.audit_case_history_view=tk.Text(hist_frame,height=4,wrap='word',font=(FONT,9),fg=TEXT,
                                             bg='#F4F8FB',relief='flat',state='disabled')
        self.audit_case_history_view.pack(fill='both',expand=True)
        # Original findings and general sign-off remain available without mixing into management output.
        live_top=self.panel(control_tab,expand=True,pad=10)
        self.colheader(live_top,'CURRENT REPORT CONTROLS / NOTICES')
        self.data_table(live_top,['Severity','Control','Observation'],
            [(x['level'],x['code'],x['message']) for x in ex],[110,190,670],7)
        sign=self.panel(control_tab,expand=True,pad=11)
        head=tk.Frame(sign,bg=WHITE);head.pack(fill='x')
        self.colheader(head,'PRIVATE AUDITOR SIGN-OFF NOTES')
        self.button(head,'Save sign-off note',self.save_auditor,True).pack(side='right')
        self.auditor=tk.Text(sign,height=4,wrap='word',font=(FONT,10),fg=TEXT,
                             bg='#F9FBFD',relief='flat',padx=10,pady=9)
        self.auditor.pack(fill='both',expand=True)
        self.auditor.insert('1.0',self.store.notes(d)[1])
        if items:
            self.audit_case_tree.selection_set(str(items[0]['id']))
            self.select_audit_case()

    def toggle_audit_dates(self):
        self.audit_all_dates=not getattr(self,'audit_all_dates',False)
        self.show('Audit')

    def select_audit_case(self,event=None):
        chosen=self.audit_case_tree.selection() if hasattr(self,'audit_case_tree') else ()
        if not chosen:return
        item=self.audit_cases_by_id.get(chosen[0])
        if item is None:return
        self.audit_case_detail.configure(text=f'Case #{item["id"]}  |  {item["day"]}  |  '
              f'{item["code"]}  |  {item["observation"]}')
        self.audit_case_status.set(item['status']);self.audit_case_owner.set(item['owner'])
        history=self.store.audit_case_history(item['id'])
        lines=[f'{x["at"]}  {x["old_status"] or "Created"} → {x["status"]}  '
                f'{x["owner"] or "(not assigned)"}\n{x["note"]}' for x in history]
        self.audit_case_history_view.configure(state='normal')
        self.audit_case_history_view.delete('1.0','end')
        self.audit_case_history_view.insert('1.0','\n\n'.join(lines))
        self.audit_case_history_view.configure(state='disabled')
        self.audit_case_comment.delete('1.0','end')

    def save_audit_case(self):
        selection=self.audit_case_tree.selection()
        if not selection:
            messagebox.showwarning('Choose a case','Select an audit case first.');return
        try:
            self.store.update_audit_case(int(selection[0]),self.audit_case_status.get(),
                  self.audit_case_owner.get(),self.audit_case_comment.get('1.0','end'))
        except Exception as e:
            messagebox.showerror('Follow-up not saved',str(e));return
        self.show('Audit')
        messagebox.showinfo('Follow-up saved','The investigation update is saved independently of Daily Sales close.')

    def page_commentary(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Commentary for separate Audit use','Commentary is excluded from the single-page Management Daily Sales.')
        panel=self.panel(self.content,expand=True,pad=15)
        head=tk.Frame(panel,bg=WHITE);head.pack(fill='x',pady=(0,10))
        self.label(head,'MANAGEMENT ACTION POINTS  /  3 SHORT LINES  /  EDITABLE',11,True,bg=WHITE).pack(side='left')
        self.button(head,'Save draft',self.save_commentary,True).pack(side='right',padx=(6,0))
        self.button(head,'Regenerate from sources',self.regenerate).pack(side='right')
        body=tk.Frame(panel,bg=WHITE);body.pack(fill='both',expand=True)
        self.comment_text=tk.Text(body,wrap='word',font=(FONT,11),fg=TEXT,bg='#FBFCFE',relief='flat',padx=22,pady=17,undo=True,spacing1=3,spacing3=6)
        scr=ttk.Scrollbar(body,command=self.comment_text.yview);self.comment_text.configure(yscrollcommand=scr.set)
        self.comment_text.pack(side='left',fill='both',expand=True);scr.pack(side='right',fill='y')
        self.comment_text.insert('1.0',self.store.notes(d)[0] or generate_compact_commentary(self.store,d))
        self.note(self.content,'The narrative is for management review. Save edits before exporting. The report is marked PREVIEW until the day is manually Closed; PDF export never emails automatically.','info')

    def page_mtd(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Month-to-Date & Coverage','Only stored, manually Closed business dates are included in the approved monthly roll-up.')
        self.note(self.content,('COMPLETE THROUGH '+d if mt['complete'] else f'INCOMPLETE — {len(mt["missing"])} missing / open dates within configured reporting window. Review inside app.'),'ok' if mt['complete'] else 'warn')
        p=self.panel(self.content,expand=True,pad=12);self.colheader(p,'DAY-BY-DAY CLOSED DATE REGISTER')
        first=self.store.reporting_start(d);end=date.fromisoformat(d);rows=[];x=first
        while x<=end:
            day=x.isoformat();closed=self.store.status(day)=='Closed' and 'Department Summary' in self.store.day(day);z=metrics(self.store.day(day)) if closed else None
            rows.append((day,'Closed' if closed else 'Missing / Open',*([money(z[v]) for v in ('rooms','food','beverage','other','revenue')] if z else ['—']*5)))
            x+=timedelta(days=1)
        self.data_table(p,['Business Date','Close Status','Rooms','Food','Beverage','Other','Total Revenue'],rows,[150,160,140,140,140,140,150],15)
        month=mtd_detail(self.store,d)
        cover='  |  '.join(f'{k}: {n}/{month["expected"]}' for k,n in month['coverage'].items())
        self.label(self.content,cover,9,True,color=AMBER if not all(month['coverage_complete'].values()) else GREEN).pack(anchor='w',pady=(12,0))

    def page_import(self,d,src,m,ex,mt,status):
        self.heading(self.content,'Comsys Report Import & Day Close','Selected Business Date controls ALL imports. Wrong-day files are rejected before saving.')
        bar=tk.Frame(self.content,bg=BG);bar.pack(fill='x',pady=(0,14))
        for label,action,primary in [('Import Excel / ZIP',self.import_files,True),('Pending Review',self.mark_pending,False),('Approve / Close Day',self.approve,False),('Reopen Closed Day',self.reopen,False),('Backup Data',self.backup_database,False),('Restore Backup',self.restore_database,False)]:
            self.button(bar,label,action,primary).pack(side='left',padx=(0,8))
        review_bar=tk.Frame(self.content,bg=BG);review_bar.pack(fill='x',pady=(0,8))
        self.button(review_bar,'Run Daily QA / Check before Close',self.review_daily_qa,True,padx=14).pack(side='left',padx=(0,10))
        self.label(review_bar,
                   '16/16 source reports required. Fix blockers; investigate/sign off warnings. Only then approve.',
                   9,color=MUTED).pack(side='left')
        setting=tk.Frame(self.content,bg=BG);setting.pack(fill='x',pady=(0,8))
        self.label(setting,'MTD coverage starts:',10,True,NAVY).pack(side='left',padx=(0,8))
        tk.Entry(setting,textvariable=self.start_var,width=13,font=(FONT,10),relief='solid',bd=1).pack(side='left')
        self.button(setting,'Save start date',self.save_reporting_start).pack(side='left',padx=(6,12))
        self.label(setting,'Only reviewed Closed days from this date count in MTD (inside-app setting).',9,color=MUTED).pack(side='left')
        source_grid=self.panel(self.content,pad=9)
        self.colheader(source_grid,'REQUIRED DAILY FILE CHECKLIST')
        essential=['Department Summary','Rooms Situation','Guest In House',
                   'Company Revenue','F&B Report','Cashier Summary','Daily Sales',
                   'Cashier Audit','Complimentary Report','Department Details',
                   'House Use Report','Night Report','Out of Order Rooms',
                   'Posting Summary','Rooms Summary','Voided Transactions']
        checklist=[(name,'RECEIVED' if name in src else 'MISSING',
                    next((f for kind,f,_ in self.store.sources(d) if kind==name),'—')) for name in essential]
        self.data_table(source_grid,['Comsys report','Status','Source file'],checklist,[210,100,450],height=8)
        p=self.panel(self.content,expand=True,pad=15);self.colheader(p,'IMPORTED COMSYS SOURCES')
        self._alerts_panel(d,p)
        self.data_table(p,['Report type','Uploaded filename','Imported / Updated'],self.store.sources(d),[235,420,185],5 if len(essential)>6 else 7)
        old=self.store.source_history(d)
        if old:
            self.label(self.content,f'Previous replaced file versions retained: {len(old)} (audit history)',
                       9,color=MUTED).pack(anchor='w')

        self.note(self.content,'Closing a day is a manual approval in this local program, NOT proof that Comsys Night Audit has completed. Trial data and production storage remain separated.','warn')

    def review_daily_qa(self):
        """A self-contained, safe operator action: shows private findings, never closes."""
        d=self.date_var.get().strip()
        try:
            normal= date.fromisoformat(d).isoformat()
            src=self.store.day(normal)
            gate=self.store.close_eligibility(normal)
            issues=checks(src)
        except Exception as exc:
            messagebox.showerror('Daily QA',str(exc));return
        blockers=[z for z in issues if z['level']=='BLOCKER']
        warnings=[z for z in issues if z['level']=='WARNING']
        covered=len(src)
        if gate['blockers']:
            status='NOT READY — DO NOT CLOSE'
        elif warnings:
            status='AUDITOR SIGN-OFF REQUIRED'
        else:
            status='QA READY — final management approval still required'
        facts=(f'Business Date: {normal}\nComsys sources: {covered}/16\n'
               f'Blockers: {len(gate["blockers"])}\nWarnings: {len(warnings)}\n\n'
               f'{status}\n\n'
               'Top findings:\n'+ '\n'.join('• '+e for e in gate['blockers'][:5]+gate['warnings'][:3])+
               '\n\nOpen Live Controls & Sign-off to see every observation and leave an auditor note.')
        messagebox.showinfo('Daily QA — private review',facts)
        self.show('Audit')
        if hasattr(self,'audit_tabs'):
            self.audit_tabs.select(1)

    def backup_database(self):
        name='SkyStar_DailySales_'+('DEMO_' if self.demo else '')+'BACKUP_'+date.today().isoformat()+'.sqlite'
        file=filedialog.asksaveasfilename(title='Back up ALL saved days (SQLite)',initialfile=name,filetypes=[('SQLite backup','*.sqlite')],defaultextension='.sqlite')
        if not file:return
        try:
            self.store.create_backup(file)
            messagebox.showinfo('Backup completed','Verified data backup saved to:\n'+file+'\n\nKeep a copy on another drive.')
        except Exception as e:messagebox.showerror('Backup error',str(e))

    def restore_database(self):
        file=filedialog.askopenfilename(title='Restore a Sky Star SQLite backup',filetypes=[('SQLite backup','*.sqlite'),('All files','*.*')])
        if not file:return
        if not messagebox.askyesno('RESTORE BACKUP - CONFIRM',
            'This will REPLACE the current saved days with the selected backup.\n'
            'A safety backup of the current database will be saved automatically.\n\nProceed?'):
            return
        try:
            previous=self.store.restore_backup(file)
            self.start_var.set(self.store.get_setting('reporting_start_date','2026-10-10'))
            self.show('Import')
            messagebox.showinfo('Database restored', 'Restore successful.\nOriginal database safety backup:\n'+str(previous))
        except Exception as exc:messagebox.showerror('Restore rejected',str(exc))

    def save_auditor(self,silent=False):
        self.store.save_notes(self.date_var.get(),auditor_note=self.auditor.get('1.0','end').strip())
        if not silent:messagebox.showinfo('Saved','Auditor notes saved successfully.')
    def save_commentary(self,silent=False):
        self.store.save_notes(self.date_var.get(),commentary=self.comment_text.get('1.0','end').strip())
        if not silent:messagebox.showinfo('Saved','Management commentary saved.')
    def regenerate(self):
        if not messagebox.askyesno('Regenerate','Replace the text in this editor with a new automatically drafted commentary?'):return
        self.comment_text.delete('1.0','end');self.comment_text.insert('1.0',generate_compact_commentary(self.store,self.date_var.get()))
    def _alerts_panel(self,d,parent):
        items=self.store.active_import_alerts(d)
        if not items:return
        self.label(parent,'PRIVATE IMPORT / DATE ALERTS  •  NOT PRINTED IN MANAGEMENT REPORT',10,True,color='#A9492A').pack(anchor='w',pady=(11,4))
        for alert in items[:5]:
            self.label(parent,'• '+alert[4],9,color='#8E3925',wraplength=900,justify='left').pack(anchor='w',pady=2)
        self.button(parent,'Reviewed / Clear rejected-file alerts',self.dismiss_import_alerts).pack(anchor='w',pady=7)
    def dismiss_import_alerts(self):
        d=self.date_var.get().strip()
        if messagebox.askyesno('Audit confirmation',
                'Only clear alerts after verifying that rejected wrong-date files were NOT imported.\n'
                'Any missing correct-day source will still block approval.\n\nClear private rejected-file alerts?'):
            self.store.dismiss_import_alerts(d);self.show('Import')
    def save_reporting_start(self):
        d=self.start_var.get().strip()
        previous=self.store.get_setting('reporting_start_date','2026-10-10')
        closed=self.store.db.execute("SELECT COUNT(*) FROM days WHERE status='Closed'").fetchone()[0]
        if d!=previous and closed and not messagebox.askyesno('MTD reporting start change',
                f'{closed} approved day(s) exist. Changing MTD start changes the cumulative period shown in future reports.\n'
                'A private event will be recorded; approved daily amounts remain unchanged.\n\nProceed?'):
            self.start_var.set(previous);return
        try:self.store.set_setting('reporting_start_date',d)
        except Exception as e:messagebox.showerror('Reporting start date',str(e));return
        self.show('Import')
    def import_files(self):
        selected=self.date_var.get().strip()
        try:date.fromisoformat(selected)
        except ValueError:messagebox.showerror('Invalid day','Choose a valid YYYY-MM-DD date first.');return
        files=filedialog.askopenfilenames(title=f'Comsys files for {selected} ONLY',
                         filetypes=[('Comsys Excel or ZIP','*.xls *.xlsx *.zip')]);
        if not files:return
        parsed=[];errors=[]
        try:
            with stage_reports(files) as staged:
                self._import_staged_files(staged,selected)
        except Exception as exc:
            messagebox.showerror('Report upload rejected',str(exc))
            self.show('Import')

    def _import_staged_files(self,files,selected):
        parsed=[];errors=[]
        for filename in files:
            try:
                try:source=parse_source(filename)
                except ValueError as exc:
                    # The only supported manual-date exception is Comsys Night Report.
                    if ('No readable business date' in str(exc) and
                            'NIGHT REPORT' in Path(filename).name.upper() and
                            messagebox.askyesno('Undated Night Report — manual verification',
                              f'{Path(filename).name} has no readable report date.\n\n'
                              f'After checking the report in Comsys, do you certify it belongs to {selected}?\n'
                              'This certification is recorded privately.')):
                        source=parse_source(filename,date_override=selected)
                    else:raise
                parsed.append(validate_date(source,selected))
            except Exception as exc:
                errors.append((filename,exc))
        if errors:
            # Whole batch rejected; no valid source is silently saved to a different day.
            for filename,exc in errors:
                self.store.add_import_alert(selected,Path(filename).name,str(exc),
                    getattr(exc,'report_kind',None),getattr(exc,'reported',None))
            self.show('Import')
            messagebox.showerror('Wrong date / import halted',
               f'Expected Business Date: {selected}\nNO FILES FROM THIS BATCH WERE SAVED.\n\n'+
               '\n'.join(str(exc) for _,exc in errors[:6])+ '\n\nSee private alerts on the Import screen.')
            return
        # Review conflicts *before* any data are saved; one atomic SQL batch.
        existing={kind:sha for kind,sha in self.store.db.execute('SELECT kind,sha FROM sources WHERE day=?',(selected,))}
        changed=[s for s in parsed if s['kind'] in existing and existing[s['kind']]!=s['sha256']]
        if changed and not messagebox.askyesno('Replace previous report versions',
             'The following report types are already saved for '+selected+':\n'+
             '\n'.join('• '+s['kind'] for s in changed)+
             '\n\nReplace these together? Older versions are kept in the audit history.'):
            self.show('Import');return
        try:
            result=self.store.save_sources_batch(parsed,overwrite_kinds=[x['kind'] for x in changed])
        except Exception as exc:
            messagebox.showerror('Nothing imported / batch rolled back',str(exc));self.show('Import');return
        self.show('Import')
        messagebox.showinfo('Import complete',f'Business Date: {selected}\n'+
               '\n'.join(f'{kind}: {action}' for kind,action in result)+
               '\n\nReview the private checks before closing.')

    def mark_pending(self):
        d=self.date_var.get()
        if self.store.status(d)=='Closed':messagebox.showwarning('Protected','Reopen this date first.');return
        self.store.set_status(d,'Pending Review');self.show(self.screen)
    def approve(self):
        d,src,m,ex,mt,status=self.state()
        eligibility=self.store.close_eligibility(d)
        if eligibility['blockers']:
            messagebox.showerror('Cannot close day',
                 'Fix these issues for '+d+' first:\n'+'\n'.join(eligibility['blockers'][:10]))
            self.show('Import');return
        if eligibility['warnings'] and len(self.store.notes(d)[1])<12:
            messagebox.showwarning('Auditor sign-off required',
                'Open Audit & Exceptions and save a private explanatory note for outstanding warnings.')
            self.show('Audit');return
        if not messagebox.askyesno('Close business date',
            'Has Comsys completed its Night Audit for '+d+'?\n\n'
            'Confirm the source files are FINAL and approve the day for Daily/MTD reporting.'):
            return
        try:self.store.approve_day(d,comsys_closed=True)
        except Exception as e:messagebox.showerror('Close rejected',str(e));return
        self.show('Import')

    def reopen(self):
        d=self.date_var.get()
        if self.store.status(d)!='Closed':return
        if len(self.store.notes(d)[1])<12:
            messagebox.showwarning('Reason required','Save an auditor explanation of at least 12 characters before reopening.');return
        if messagebox.askyesno('Reopen date',f'Reopen {d}? The event will be logged.'):
            self.store.set_status(d,'Pending Review');self.show(self.screen)
    def has_data(self):
        d=self.date_var.get()
        if self.store.day(d):return True
        messagebox.showwarning('No imported data',f'No imported Comsys data for {d}.\nOpen Import & Day Close first.\nTo test the UI choose START_DEMO_WINDOWS.bat.')
        self.show('Import');return False
    def can_export_management(self):
        if not self.has_data():return False
        d,src,m,ex,mt,status=self.state()
        if self.store.active_import_alerts(d):
            messagebox.showwarning('Private date verification',
              'Unresolved import/date alerts. Review them in Import & Day Close before exporting.')
            self.show('Import');return False
        if status!='Closed':
            messagebox.showwarning('Day is not approved',
              'Approve / Close the selected business day inside the app before management export.\n'
              'Review financial blockers and sign off relevant exceptions privately.')
            self.show('Import');return False
        if any(x['level']=='BLOCKER' for x in ex):
            messagebox.showwarning('Private audit blockers','The selected day has unresolved financial/source blockers.')
            self.show('Audit');return False
        # Never silently clip companies from the fixed single-page PDF layout.
        if len(company_mix(self.store,d)['rows'])>15:
            messagebox.showwarning('Company table exceeds A4',
                'More than 15 company/category lines for this date. Do not issue a cropped report. '
                'Review company grouping before export.')
            self.show('Company & F&B');return False
        # All mandatory management blocks must have source data on each MTD day.
        # Do not silently distribute a partial cumulative statement as final.
        from datetime import timedelta
        mandatory={'Department Summary','Rooms Situation','Guest In House',
                   'Company Revenue','F&B Report','Cashier Summary','Daily Sales'}
        cursor=self.store.reporting_start(d);end=date.fromisoformat(d)
        incomplete=[]
        while cursor<=end:
            key=cursor.isoformat();received=set(self.store.day(key))
            if self.store.status(key)!='Closed' or not mandatory.issubset(received):
                incomplete.append(key+' ('+', '.join(sorted(mandatory-received))[:110]+')')
            cursor+=timedelta(days=1)
        if incomplete:
            messagebox.showwarning('Private MTD source coverage',
                 'Cannot export a complete Daily Sales / MTD report. Resolve these dates inside the system:\n'+
                 '\n'.join(incomplete[:8]))
            self.show('MTD');return False
        return True
    def export_excel(self):
        if not self.can_export_management():return
        d=self.date_var.get()
        if self.screen=='Commentary':self.save_commentary(True)
        path=filedialog.asksaveasfilename(title='Export Daily Sales Workbook',initialfile=f'SkyStar_Daily_Sales_{d}.xlsx',filetypes=[('Excel Workbook','*.xlsx')],defaultextension='.xlsx')
        if not path:return
        try:workbook_export(self.store,d,path);messagebox.showinfo('Excel exported','Saved to:\n'+path)
        except Exception as e:messagebox.showerror('Excel export',str(e))
    def print_preview(self):
        """Generate an approved, A4-landscape printable PDF; open viewer for user Print.

        Never silently send hotel finance documents to a physical printer.
        """
        if not self.can_export_management():return
        d=self.date_var.get().strip()
        destination=self.store.path.parent/'print_previews'/f'SkyStar_Daily_Sales_{d}_PRINT.pdf'
        try:
            destination.parent.mkdir(parents=True,exist_ok=True)
            pdf_export(self.store,d,destination,mode='management')
            if os.name=='nt':os.startfile(str(destination))
            else:subprocess.Popen(['xdg-open',str(destination)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            messagebox.showinfo('Print preview ready',
                'Approved A4 Landscape PDF opened in your PDF viewer.\n'
                'Review the page, then press Ctrl+P to choose the printer.\n\n'+str(destination))
        except Exception as exc:messagebox.showerror('Print preview failed',str(exc))

    def export_management(self):self._export_pdf('management')
    def export_meal_plan(self):
        if not self.can_export_management():return
        d=self.date_var.get()
        if 'F&B Report' not in self.store.day(d):
            messagebox.showwarning('Meal Plan source missing','Import F&B Report for '+d+' first.\nDo not use a report from another date.');return
        p=filedialog.asksaveasfilename(title='Export Meal Plan PDF',initialfile=f'SkyStar_Meal_Plan_{d}.pdf',filetypes=[('PDF','*.pdf')],defaultextension='.pdf')
        if p:
            try:pdf_export(self.store,d,p,mode='meal_plan');messagebox.showinfo('Meal Plan exported','Saved to:\n'+p)
            except Exception as e:messagebox.showerror('Meal Plan export',str(e))
    def export_audit(self):self._export_pdf('audit')
    def _export_pdf(self,report_type):
        if report_type=='management' and not self.can_export_management():return
        if report_type!='management' and not self.has_data():return
        d=self.date_var.get()
        if self.screen=='Commentary':self.save_commentary(True)
        if self.screen=='Audit':self.save_auditor(True)
        filename=f'SkyStar_{"Management" if report_type=="management" else "Audit"}_Report_{d}.pdf'
        path=filedialog.asksaveasfilename(title='Export '+report_type.title()+' PDF',initialfile=filename,filetypes=[('PDF','*.pdf')],defaultextension='.pdf')
        if not path:return
        try:pdf_export(self.store,d,path,mode=report_type);messagebox.showinfo('PDF exported','Saved to:\n'+path)
        except ImportError:messagebox.showerror('PDF export','ReportLab missing. Run FIX_PDF_EXPORT_WINDOWS.bat and restart.')
        except Exception as e:messagebox.showerror('PDF export',str(e))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--demo',action='store_true');p.add_argument('--db',default='');a=p.parse_args()
    base=Path.home()/'.sky_star_daily_sales_v8_3';db=Path(a.db) if a.db else base/('demo_preview.sqlite' if a.demo else 'production.sqlite')
    # First-run bootstrap ONLY for a fresh v8.3 workspace: user-approved 10 Oct 2026.
    # Existing databases are never overwritten or changed automatically.
    initial=Path(__file__).resolve().parent.parent/'initial_data'/'approved_oct10.sqlite'
    if not a.demo and not a.db and not db.exists() and initial.exists():
        db.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(initial,db)
    sample=Path(__file__).resolve().parent.parent/'sample_outputs'/'demo_preview.sqlite'
    if a.demo and not db.exists() and sample.exists():db.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(sample,db)
    App(db,a.demo).mainloop()
